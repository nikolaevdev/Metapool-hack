# deploy-dev-advanced-plus

Расширенный комплект для локальной разработки и QA:
- **hot-reload** бэкенда и воркера через `watchfiles`;
- **healthchecks**;
- **dev-proxy** на настраиваемом домене/порту;
- **профили** `dev` и `qa` в одном compose;
- **TLS для QA**: публичный (Let's Encrypt) и локальный self-signed;
- цели `init`/`seed` и простая GitHub Actions-проверка.

## Dev
```bash
cd deploy-dev-advanced-plus
make dev-up
make dev-init        # миграции + суперпользователь (из .env.dev)
open http://dev.localhost:8081/spa/   # или http://localhost:8081/spa/
```
Переменные dev-прокси: `DEV_PROXY_PORT`, `DEV_SERVER_NAME` в `.env.dev`.

## QA (локально)
```bash
make qa-up
make qa-init
open http://localhost:9080/spa/
```

### QA + публичный TLS (домен должен указывать на вашу машину)
```bash
# В .env.qa: QA_DOMAIN, QA_LETSENCRYPT_EMAIL
make qa-up
make qa-up-tls
# доступ по https://$QA_DOMAIN/
```

### QA + локальный self-signed TLS (без публичного домена)
```bash
make cert-selfsigned
make qa-up
make qa-up-tls-selfsigned
# доступ по https://$QA_SERVER_NAME:9443/ (см. .env.qa)
```

## Дополнительно
- **Seed**: положите `backend/fixtures/seed.json` и выполните `make dev-seed` либо `make qa-seed`.
- **SSE**: `make sse` — быстрый тест стрима.
- **Очистка**: `make clean` — остановка и удаление томов (осторожно).
