from __future__ import annotations
import asyncio, json
from app.connectors.telegram import telegram_connector
from app.utils.queue import get_redis, ESCALATIONS_STREAM

GROUP = "op_notify_group"; NAME = "op_notify_1"
async def ensure_group(r, stream):
    try: await r.xgroup_create(stream, GROUP, id="$", mkstream=True)
    except Exception: pass

def build_text(ev: dict) -> str:
    conv = ev.get("conversation_id",""); esc = ev.get("escalation_id",""); reason = ev.get("reason","")
    return (f"🚨 Новая эскалация\n• Escalation ID: {esc}\n• Conversation ID: {conv}\n• Причина: {reason}")

async def main():
    r = get_redis(); await ensure_group(r, ESCALATIONS_STREAM)
    while True:
        resp = await r.xreadgroup(groupname=GROUP, consumername=NAME, streams={ESCALATIONS_STREAM: ">"}, count=10, block=5000)
        if not resp: continue
        for stream, messages in resp:
            for msg_id, fields in messages:
                try:
                    payload = json.loads(fields["payload"]); await telegram_connector.send_to_operators(build_text(payload))
                    await r.xack(ESCALATIONS_STREAM, GROUP, msg_id)
                except Exception:
                    await r.xack(ESCALATIONS_STREAM, GROUP, msg_id)
        await asyncio.sleep(0.1)

if __name__ == "__main__":
    asyncio.run(main())