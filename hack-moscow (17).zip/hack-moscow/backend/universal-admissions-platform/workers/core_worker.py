from __future__ import annotations
import asyncio, json
from app.db import SessionLocal
from app.services.core import auto_answer, ensure_user_and_conversation, escalate
from app.utils.queue import get_redis, INBOUND_STREAM

CONSUMER_GROUP = "core_group"
CONSUMER_NAME = "core_1"

async def ensure_group(r, stream):
    try:
        await r.xgroup_create(stream, CONSUMER_GROUP, id="$", mkstream=True)
    except Exception:
        pass

async def process_event(payload: dict):
    async with SessionLocal() as session:
        # простая эвристика: прямой запрос оператора -> эскалация
        txt = (payload.get("text") or "").lower()
        if any(k in txt for k in ["оператор","человек","human"]):
            conv = await ensure_user_and_conversation(session, payload["channel"], payload["channel_user_id"], payload.get("conversation_id"))
            await escalate(session, conv, reason="User requested operator")
            return
        await auto_answer(session, payload)

async def main():
    r = get_redis()
    await ensure_group(r, INBOUND_STREAM)
    while True:
        resp = await r.xreadgroup(groupname=CONSUMER_GROUP, consumername=CONSUMER_NAME, streams={INBOUND_STREAM: ">"}, count=10, block=5000)
        if not resp: continue
        for stream, messages in resp:
            for msg_id, fields in messages:
                try:
                    payload = json.loads(fields["payload"])
                    await process_event(payload)
                    await r.xack(INBOUND_STREAM, CONSUMER_GROUP, msg_id)
                except Exception:
                    await r.xack(INBOUND_STREAM, CONSUMER_GROUP, msg_id)
        await asyncio.sleep(0.02)

if __name__ == "__main__":
    asyncio.run(main())
