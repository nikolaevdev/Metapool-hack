from __future__ import annotations
import asyncio, json
from sqlalchemy import select
from app.db import SessionLocal
from app.models import Message
from app.connectors.onec import onec_connector
from app.utils.queue import get_redis, OUTBOUND_ONEC_STREAM

GROUP = "onec_group"
NAME = "onec_1"

async def ensure_group(r, stream):
    try:
        await r.xgroup_create(stream, GROUP, id="$", mkstream=True)
    except Exception:
        pass

async def deliver(payload: dict):
    async with SessionLocal() as session:
        result = await onec_connector.send_message(payload)
        q = await session.execute(select(Message).where(Message.id == payload["message_id"]))
        msg = q.scalar_one_or_none()
        if msg:
            msg.status = "sent"
            await session.commit()

async def main():
    r = get_redis()
    await ensure_group(r, OUTBOUND_ONEC_STREAM)
    while True:
        resp = await r.xreadgroup(groupname=GROUP, consumername=NAME, streams={OUTBOUND_ONEC_STREAM: ">"}, count=10, block=5000)
        if not resp: continue
        for stream, messages in resp:
            for msg_id, fields in messages:
                try:
                    payload = json.loads(fields["payload"])
                    await deliver(payload)
                    await r.xack(OUTBOUND_ONEC_STREAM, GROUP, msg_id)
                except Exception:
                    await r.xack(OUTBOUND_ONEC_STREAM, GROUP, msg_id)
        await asyncio.sleep(0.05)

if __name__ == "__main__":
    asyncio.run(main())
