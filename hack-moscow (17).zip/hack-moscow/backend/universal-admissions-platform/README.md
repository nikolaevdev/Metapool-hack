# Universal Admissions Messaging Platform — v4 (LLM+Search интеграция + VK + WebChat + 1C)

**Что нового в v4:**  
- Интегрирована Ваша логика **поиска и переформулирования**:  
  Core-воркер вызывает поиск (`search_adapter.get_top_attachments`) и затем сглаживает ответ через
  **YandexGPT** или **LM Studio** (используются Ваши модули `yandexgpt_sdk_async.py` / `LMStudio_gpt_sdk_async.py`).  
  Если модулей или SDK нет — корректные фоллбэки.
- Добавлены коннекторы **VK** (Callback API) и **WebChat** (HTTP-пуллинг).  
- Сохранены коннекторы **Telegram** и **1C**, а также эскалации/уведомления операторов.

## Каналы и стримы
- inbound
- outbound:telegram
- outbound:onec
- outbound:vk
- outbound:webchat
- escalations

## ENV (добавлено/актуально)
```env
# Telegram (пользователь и операторы)
TELEGRAM_BOT_TOKEN=
TELEGRAM_WEBHOOK_SECRET=change-me
TELEGRAM_OPERATOR_TOKEN=
TELEGRAM_OPERATOR_WEBHOOK_SECRET=op-change-me
OPERATORS_CHAT_ID=0

# 1C
ONEC_OUTBOUND_URL=
ONEC_OUTBOUND_TOKEN=
ONEC_INBOUND_TOKEN=

# VK
VK_GROUP_TOKEN=
VK_API_VERSION=5.199
VK_CONFIRMATION_RESPONSE=
VK_SECRET=   # secret из настроек Callback API

# WebChat
WEBCHAT_OUTBOX_TTL_SEC=86400

# LLM / Search (Ваши модули)
YC_FOLDER_ID=
YC_API_KEY=
YC_MODEL=yandexgpt-lite
YC_MAX_TOKENS=400
YC_TEMPERATURE=0.2

LM_STUDIO_URL=http://localhost:1234
LM_MODEL=gemma-3-4b-it-qat
LM_MAX_TOKENS=300
LM_TEMPERATURE=0.2

SEARCH_RESULT_LIMIT=3
```

## WebChat API
- `POST /webchat/inbound` — имитация клиентского сообщения: `{"session_id","user_id","text"}`.  
- `GET /webchat/outbox/{session_id}` — забрать сообщения, отправленные пользователю платформой.  
  (Работает поверх Redis списков, TTL настраивается).

## Как запускается
```bash
cp .env.sample .env
docker compose up --build
```
Далее настройте вебхуки Telegram/VK и интеграцию 1С по примерам из README прошлых версий.
