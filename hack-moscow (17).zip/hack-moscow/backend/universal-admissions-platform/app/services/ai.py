from __future__ import annotations
import asyncio
from typing import List
from ..config import settings

# optional imports of user's modules
try:
    from app.integrations.search_adapter import get_top_attachments  # type: ignore
except Exception:
    get_top_attachments = None  # type: ignore

# import rewriters
_y_rewrite = None
_lm_rewrite = None
try:
    from app.integrations.yandexgpt_sdk_async import rewrite_answer as _y_rewrite
except Exception:
    pass
try:
    from app.integrations.LMStudio_gpt_sdk_async import rewrite_answer as _lm_rewrite
except Exception:
    pass

async def build_context(question: str) -> str:
    if not get_top_attachments:
        return ""
    try:
        items = await get_top_attachments(question, settings)
        # Попробуем собрать краткий контекст
        chunks = []
        for it in items:
            # универсально: берём str(it) или поля title/text если есть
            txt = getattr(it, "text", None) or getattr(it, "content", None) or str(it)
            title = getattr(it, "title", None) or getattr(it, "name", None)
            if title:
                chunks.append(f"{title}\n{txt}")
            else:
                chunks.append(str(txt))
        return "\n\n".join([c for c in chunks if c])[:4000]
    except Exception:
        return ""

async def rewrite_with_llm(context: str, question: str, raw_answer: str) -> str:
    """Try Yandex first, then LM Studio, otherwise return raw."""
    loop = asyncio.get_running_loop()
    if _y_rewrite:
        try:
            return await loop.run_in_executor(None, _y_rewrite, context, question, raw_answer)
        except Exception:
            pass
    if _lm_rewrite:
        try:
            return await loop.run_in_executor(None, _lm_rewrite, context, question, raw_answer)
        except Exception:
            pass
    return raw_answer

async def generate_answer(question: str) -> str:
    """Simple pipeline: (search) -> draft -> rewrite."""
    ctx = await build_context(question)
    # черновой ответ (на базе простого эвристического эхо)
    draft = f"На ваш вопрос: '{question}'\nВот что мне удалось найти: {('есть контекст' if ctx else 'контекст не найден')}"
    final = await rewrite_with_llm(ctx, question, draft)
    return final
