from __future__ import annotations
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..models import User, Conversation, Message, Escalation
from ..schemas import OutboundMessageIn
from ..utils.queue import push_inbound, push_outbound, ESCALATIONS_STREAM, OUTBOUND_TG_STREAM, OUTBOUND_ONEC_STREAM, OUTBOUND_VK_STREAM, OUTBOUND_WEBCHAT_STREAM
from .ai import generate_answer

async def ensure_user_and_conversation(session: AsyncSession, channel: str, channel_user_id: str, conv_id: Optional[str]) -> Conversation:
    q = await session.execute(select(User).where(User.channel==channel, User.channel_user_id==channel_user_id))
    user = q.scalar_one_or_none()
    if not user:
        user = User(channel=channel, channel_user_id=channel_user_id)
        session.add(user); await session.commit(); await session.refresh(user)
    if conv_id:
        q = await session.execute(select(Conversation).where(Conversation.id==conv_id))
        conv = q.scalar_one_or_none()
        if conv: return conv
    q = await session.execute(select(Conversation).where(Conversation.user_id==user.id, Conversation.status!="closed"))
    conv = q.scalar_one_or_none()
    if not conv:
        conv = Conversation(user_id=user.id, status="active", meta={"unknown_count":0})
        session.add(conv); await session.commit(); await session.refresh(conv)
    return conv

async def save_message(session: AsyncSession, conv_id: str, direction: str, mtype: str, text: Optional[str], attachments: dict, status: str = "queued", provider_msg_id: Optional[str] = None) -> Message:
    msg = Message(conversation_id=conv_id, direction=direction, type=mtype, text=text, attachments=attachments or {}, status=status, provider_msg_id=provider_msg_id)
    session.add(msg); await session.commit(); await session.refresh(msg); return msg

# входящее → запись → inbound
async def store_inbound_and_enqueue(session: AsyncSession, ev: dict):
    conv = await ensure_user_and_conversation(session, ev["channel"], ev["channel_user_id"], ev.get("conversation_id"))
    await save_message(session, conv.id, "inbound", ev["type"], ev.get("text"), ev.get("attachments", {}), status="ok")
    await push_inbound({"conversation_id": conv.id, **ev})

# исходящее → запись outbound(queued) → очередь по каналу
async def enqueue_outbound_and_record(session: AsyncSession, payload: OutboundMessageIn) -> Message:
    conv = await ensure_user_and_conversation(session, payload.channel, payload.channel_user_id, payload.conversation_id)
    rec = await save_message(session, conv.id, "outbound", payload.type, payload.text, {"file_id": payload.file_id} if payload.file_id else {}, status="queued")
    data = {"conversation_id": conv.id, "message_id": rec.id, **(payload.model_dump() if hasattr(payload, "model_dump") else payload)}
    ch = data.get("channel")
    stream = OUTBOUND_TG_STREAM if ch=="telegram" else OUTBOUND_ONEC_STREAM if ch=="onec" else OUTBOUND_VK_STREAM if ch=="vk" else OUTBOUND_WEBCHAT_STREAM
    await push_outbound(stream, data)
    return rec

# Эскалация
async def escalate(session: AsyncSession, conv: Conversation, reason: str) -> Escalation:
    conv.status = "escalated"
    esc = Escalation(conversation_id=conv.id, reason=reason, status="queued")
    session.add(esc); await session.commit(); await session.refresh(esc)
    await push_outbound(ESCALATIONS_STREAM, {"conversation_id": conv.id, "escalation_id": esc.id, "reason": reason})
    return esc

# Ответ через LLM+Search
async def auto_answer(session: AsyncSession, payload: dict):
    conv = await ensure_user_and_conversation(session, payload["channel"], payload["channel_user_id"], payload.get("conversation_id"))
    answer = await generate_answer(payload.get("text") or "")
    out = OutboundMessageIn(channel=payload["channel"], channel_user_id=payload["channel_user_id"], conversation_id=conv.id, type="text", text=answer)
    await enqueue_outbound_and_record(session, out)
