from __future__ import annotations
import os
from pydantic import BaseModel

class Settings(BaseModel):
    app_name: str = os.getenv("APP_NAME", "Admissions Messaging API")
    base_url: str = os.getenv("BASE_URL", "http://localhost:8080")
    database_url: str | None = os.getenv("DATABASE_URL")
    redis_url: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    # Telegram
    telegram_bot_token: str | None = os.getenv("TELEGRAM_BOT_TOKEN")
    telegram_webhook_secret: str = os.getenv("TELEGRAM_WEBHOOK_SECRET", "change-me")
    telegram_operator_token: str | None = os.getenv("TELEGRAM_OPERATOR_TOKEN")
    telegram_operator_webhook_secret: str = os.getenv("TELEGRAM_OPERATOR_WEBHOOK_SECRET", "op-change-me")
    operators_chat_id: int = int(os.getenv("OPERATORS_CHAT_ID", "0"))

    # 1C
    onec_outbound_url: str = os.getenv("ONEC_OUTBOUND_URL", "")
    onec_outbound_token: str = os.getenv("ONEC_OUTBOUND_TOKEN", "")
    onec_inbound_token: str = os.getenv("ONEC_INBOUND_TOKEN", "")

    # VK
    vk_group_token: str | None = os.getenv("VK_GROUP_TOKEN")
    vk_api_version: str = os.getenv("VK_API_VERSION", "5.199")
    vk_confirmation_response: str | None = os.getenv("VK_CONFIRMATION_RESPONSE")
    vk_secret: str | None = os.getenv("VK_SECRET")

    # WebChat
    webchat_outbox_ttl: int = int(os.getenv("WEBCHAT_OUTBOX_TTL_SEC", "86400"))

    # LLM / Search
    yc_folder_id: str | None = os.getenv("YC_FOLDER_ID")
    yc_api_key: str | None = os.getenv("YC_API_KEY")
    yc_model: str = os.getenv("YC_MODEL", "yandexgpt-lite")
    yc_max_tokens: int = int(os.getenv("YC_MAX_TOKENS", "400"))
    yc_temperature: float = float(os.getenv("YC_TEMPERATURE", "0.2"))

    lm_studio_url: str | None = os.getenv("LM_STUDIO_URL")
    lm_model: str = os.getenv("LM_MODEL", "gemma-3-4b-it-qat")
    lm_max_tokens: int = int(os.getenv("LM_MAX_TOKENS", "300"))
    lm_temperature: float = float(os.getenv("LM_TEMPERATURE", "0.2"))

    search_result_limit: int = int(os.getenv("SEARCH_RESULT_LIMIT", "3"))

    upload_dir: str = os.getenv("UPLOAD_DIR", "data/uploads")

settings = Settings()
