from __future__ import annotations
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .db import init_models
from .routes import health, files, messages, webhooks, escalations, conversations, webchat

app = FastAPI(title=settings.app_name)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

app.include_router(health.router)
app.include_router(files.router)
app.include_router(messages.router)
app.include_router(webhooks.router)
app.include_router(escalations.router)
app.include_router(conversations.router)
app.include_router(webchat.router)

@app.on_event("startup")
async def _startup():
    os.makedirs(settings.upload_dir, exist_ok=True)
    await init_models()
