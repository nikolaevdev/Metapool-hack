from __future__ import annotations
import os, uuid, shutil
from fastapi import UploadFile
from starlette.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from .config import settings
from .models import StoredFile

UPLOAD_DIR = settings.upload_dir

def ensure_upload_dir():
    os.makedirs(UPLOAD_DIR, exist_ok=True)

async def save_upload(session: AsyncSession, file: UploadFile) -> StoredFile:
    ensure_upload_dir()
    _, ext = os.path.splitext(file.filename or "")
    stored_name = f"{uuid.uuid4()}{ext}"
    stored_path = os.path.join(UPLOAD_DIR, stored_name)
    with open(stored_path, "wb") as out:
        shutil.copyfileobj(file.file, out)
    size = os.path.getsize(stored_path)
    rec = StoredFile(original_name=file.filename or stored_name, stored_path=stored_path, mime=file.content_type, size=size)
    session.add(rec)
    await session.commit()
    await session.refresh(rec)
    return rec

async def get_file(session: AsyncSession, file_id: str) -> StoredFile | None:
    q = await session.execute(select(StoredFile).where(StoredFile.id == file_id))
    return q.scalar_one_or_none()

def as_file_response(rec: StoredFile) -> FileResponse:
    return FileResponse(rec.stored_path, filename=rec.original_name, media_type=rec.mime)
