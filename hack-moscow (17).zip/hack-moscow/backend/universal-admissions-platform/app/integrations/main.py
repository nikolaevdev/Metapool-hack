#!/usr/bin/env python3
"""
Запуск FastAPI-сервиса + Telegram-бота (long-polling).
"""

import os
import asyncio

from fastapi import FastAPI
from aiogram import Bot, Dispatcher

# 1) Сначала подтягиваем настройки, включая DJANGO_SETTINGS_MODULE
from tg_admission_bot.config import Settings
settings = Settings()

# 2) Устанавливаем переменную окружения и инициализируем Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", settings.DJANGO_SETTINGS_MODULE)
import django
django.setup()

# 3) Только теперь импортируем обработчики, зависящие от ORM
from tg_admission_bot.bot_handlers import register_handlers


def create_app() -> FastAPI:
    """
    Создаёт FastAPI-приложение и запускает aiogram long-polling.
    """
    # Telegram Bot
    bot = Bot(
        token=settings.TELEGRAM_TOKEN.get_secret_value(),
        parse_mode="HTML",
    )
    dp = Dispatcher()
    register_handlers(dp, settings)

    app = FastAPI(
        title="Admissions TG Bot",
        docs_url=None,
        redoc_url=None,
    )

    @app.on_event("startup")
    async def on_startup() -> None:
        """
        Запускаем long-polling в фоне.
        """
        loop = asyncio.get_running_loop()
        loop.create_task(dp.start_polling(bot))

    @app.on_event("shutdown")
    async def on_shutdown() -> None:
        """
        Закрываем сессию Bot.
        """
        await bot.session.close()

    @app.get("/health", tags=["service"])
    async def health() -> dict:
        return {"status": "ok"}

    return app


# Экземпляр приложения для Uvicorn/Gunicorn
app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "tg_admission_bot.main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
    )
