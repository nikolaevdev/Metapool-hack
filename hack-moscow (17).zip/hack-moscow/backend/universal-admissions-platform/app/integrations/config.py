from pydantic_settings import BaseSettings
from pydantic import Field, SecretStr, ConfigDict


class Settings(BaseSettings):
    """
    Глобальные настройки Telegram-сервиса.

    Читает только те переменные окружения, которые здесь описаны,
    а все прочие (например, SECRET_KEY, DEBUG, DATABASE_* и т.д.) игнорирует.
    """

    # Отключаем валидацию «лишних» переменных и указываем .env
    model_config = ConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Telegram Bot API
    TELEGRAM_TOKEN: SecretStr = Field(..., env="TELEGRAM_TOKEN")

    # Бот операторов
    TELEGRAM_OPERATOR_TOKEN: SecretStr = Field(..., env="TELEGRAM_OPERATOR_TOKEN")
    # ID группового чата или канала, где операторы будут видеть новые заявки
    OPERATORS_CHAT_ID: int = Field(..., env="OPERATORS_CHAT_ID")

    # Yandex GPT
    YC_FOLDER_ID: str        = Field(..., env="YC_FOLDER_ID")
    YC_API_KEY: SecretStr    = Field(..., env="YC_API_KEY")
    YC_MODEL: str            = Field("yandexgpt", env="YC_MODEL")
    YC_MAX_TOKENS: int       = Field(300, env="YC_MAX_TOKENS")
    YC_TEMPERATURE: float    = Field(0.2, env="YC_TEMPERATURE")

    # Поиск
    SEARCH_RESULT_LIMIT: int = Field(3, env="SEARCH_RESULT_LIMIT")

    LM_STUDIO_URL: str        = Field(..., env="LM_STUDIO_URL")
    LM_MODEL: str            = Field("gemma-3-4b-it-qat", env="LM_MODEL")
    LM_MAX_TOKENS: int       = Field(300, env="LM_MAX_TOKENS")
    LM_TEMPERATURE: float    = Field(0.2, env="LM_TEMPERATURE")

    # Redis
    REDIS_URL: str = Field("redis://localhost:6379/0", env="REDIS_URL")
    REDIS_QUEUE_NAME: str = Field("tg_admission_queue", env="REDIS_QUEUE_NAME")

    # Лимиты
    PER_USER_RATE_LIMIT: int = Field(3, env="PER_USER_RATE_LIMIT")          # сообщений в минуту
    MAX_CONCURRENT_REQUESTS: int = Field(5, env="MAX_CONCURRENT_REQUESTS")  # одновременных вызовов LLM