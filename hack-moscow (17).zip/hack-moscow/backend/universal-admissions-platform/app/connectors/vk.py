from __future__ import annotations
import httpx, time, random
from ..config import settings

API = "https://api.vk.com/method"

class VKConnector:
    name = "vk"

    async def send_message(self, msg: dict) -> dict:
        token = settings.vk_group_token
        v = settings.vk_api_version
        if not token:
            raise RuntimeError("VK_GROUP_TOKEN not set")
        params = {
            "access_token": token,
            "v": v,
            "peer_id": msg.get("channel_user_id"),
            "random_id": random.randint(1, 2_147_483_647),
            "message": msg.get("text",""),
        }
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(f"{API}/messages.send", data=params)
            r.raise_for_status()
            return r.json()

vk_connector = VKConnector()
