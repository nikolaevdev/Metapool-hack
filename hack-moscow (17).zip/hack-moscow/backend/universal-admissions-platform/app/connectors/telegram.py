from __future__ import annotations
from typing import Dict, Any, List
import httpx
from fastapi import HTTPException
from ..config import settings

API_BASE = "https://api.telegram.org"

class TelegramConnector:
    name = "telegram"

    def verify_signature(self, headers: Dict[str,str]) -> bool:
        expected = settings.telegram_webhook_secret
        got = headers.get("x-telegram-bot-api-secret-token") or headers.get("X-Telegram-Bot-Api-Secret-Token")
        return bool(expected) and got == expected

    async def normalize_inbound(self, payload: Dict[str,Any]) -> List[Dict[str,Any]]:
        events: List[Dict[str,Any]] = []
        msg = payload.get("message") or payload.get("edited_message")
        if msg:
            chat = msg.get("chat", {})
            user = msg.get("from", {})
            base = {
                "channel": "telegram",
                "channel_user_id": str(chat.get("id")),
                "user_name": f"{user.get('first_name','')} {user.get('last_name','')}".strip(),
                "timestamp": msg.get("date"),
                "direction": "inbound",
                "conversation_id": str(chat.get("id")),
            }
            if "text" in msg:
                events.append({**base, "type":"text", "text": msg["text"], "attachments": []})
            elif "photo" in msg:
                photos = msg["photo"]
                file_id = photos[-1]["file_id"]
                events.append({**base, "type":"image", "text": None, "attachments":[{"type":"image","provider_file_id":file_id}]})
            elif "document" in msg:
                file_id = msg["document"]["file_id"]
                events.append({**base, "type":"file", "text": None, "attachments":[{"type":"file","provider_file_id":file_id}]})
        return events

    def _url(self, method: str, operator: bool=False) -> str:
        token = settings.telegram_operator_token if operator else settings.telegram_bot_token
        if not token:
            raise HTTPException(status_code=500, detail="TELEGRAM_*_TOKEN is not configured")
        return f"{API_BASE}/bot{token}/{method}"

    async def send_message(self, msg: Dict[str,Any]) -> Dict[str,Any]:
        chat_id = msg["channel_user_id"]
        mtype = msg["type"]
        async with httpx.AsyncClient(timeout=20) as client:
            if mtype == "text":
                payload = {"chat_id": chat_id, "text": msg.get("text","")}
                r = await client.post(self._url("sendMessage"), json=payload)
                r.raise_for_status()
                return r.json()
            elif mtype in ("image","file"):
                files = {"photo" if mtype=="image" else "document": (msg.get("_file_name","file"), msg.get("_file_bytes"))}
                data = {"chat_id": chat_id}
                method = "sendPhoto" if mtype == "image" else "sendDocument"
                r = await client.post(self._url(method), data=data, files=files)
                r.raise_for_status()
                return r.json()
            elif mtype == "typing":
                payload = {"chat_id": chat_id, "action":"typing"}
                r = await client.post(self._url("sendChatAction"), json=payload)
                r.raise_for_status()
                return r.json()
            else:
                raise HTTPException(status_code=400, detail=f"Unsupported type: {mtype}")

    async def send_to_operators(self, text: str) -> Dict[str,Any]:
        chat_id = settings.operators_chat_id
        if not chat_id:
            raise HTTPException(status_code=500, detail="OPERATORS_CHAT_ID not set")
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(self._url("sendMessage", operator=True), json={"chat_id": chat_id, "text": text})
            r.raise_for_status()
            return r.json()

telegram_connector = TelegramConnector()
