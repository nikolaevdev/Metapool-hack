from __future__ import annotations
from ..config import settings
from ..utils.queue import get_redis

class WebChatConnector:
    name = "webchat"

    async def send_message(self, msg: dict) -> dict:
        # кладём в outbox лист по ключу с TTL
        r = get_redis()
        key = f"webchat:outbox:{msg.get('channel_user_id')}"
        await r.rpush(key, msg.get("text",""))
        await r.expire(key, settings.webchat_outbox_ttl)
        return {"ok": True}

webchat_connector = WebChatConnector()
