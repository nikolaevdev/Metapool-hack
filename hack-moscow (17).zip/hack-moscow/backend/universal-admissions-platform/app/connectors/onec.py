from __future__ import annotations
import httpx
from fastapi import HTTPException
from ..config import settings

class OneCConnector:
    name = "onec"
    async def send_message(self, msg: dict) -> dict:
        url = settings.onec_outbound_url
        token = settings.onec_outbound_token
        if not url or not token:
            raise HTTPException(status_code=500, detail="ONEC_* not configured")
        payload = {
            "conversation_id": msg.get("conversation_id"),
            "message_id": msg.get("message_id"),
            "event": "message.outbound",
            "payload": {
                "type": msg.get("type"),
                "text": msg.get("text"),
                "channel_user_id": msg.get("channel_user_id"),
                "attachments": msg.get("attachments", [])
            }
        }
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(url, json=payload, headers={"X-API-Key": token})
            r.raise_for_status()
            return r.json() if r.content else {"ok": True}

onec_connector = OneCConnector()
