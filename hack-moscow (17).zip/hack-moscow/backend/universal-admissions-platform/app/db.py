from __future__ import annotations
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase
from .config import settings

class Base(DeclarativeBase): pass

def _dsn() -> str:
    return settings.database_url or "sqlite+aiosqlite:///data/app.db"

engine = create_async_engine(_dsn(), echo=False, future=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def init_models():
    from . import models  # noqa
    async with engine.begin() as conn:
        await conn.run_sync(models.Base.metadata.create_all)

async def get_session() -> AsyncSession:
    async with SessionLocal() as s:
        yield s
