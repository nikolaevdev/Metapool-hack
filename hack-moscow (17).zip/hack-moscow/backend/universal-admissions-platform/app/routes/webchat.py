from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import get_session
from ..services.core import store_inbound_and_enqueue
from ..utils.queue import get_redis

router = APIRouter(prefix="/webchat", tags=["webchat"])

class WebChatInbound(BaseModel):
    session_id: str
    user_id: str
    text: str

@router.post("/inbound")
async def webchat_inbound(payload: WebChatInbound, session: AsyncSession = Depends(get_session)):
    ev = {"channel":"webchat", "channel_user_id": payload.session_id, "type":"text", "text": payload.text, "attachments": [], "direction":"inbound"}
    await store_inbound_and_enqueue(session, ev)
    return {"ok": True}

@router.get("/outbox/{session_id}")
async def webchat_outbox(session_id: str):
    r = get_redis()
    key = f"webchat:outbox:{session_id}"
    items = []
    while True:
        v = await r.lpop(key)
        if v is None: break
        items.append(v)
    return {"items": items}
