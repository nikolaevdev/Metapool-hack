from __future__ import annotations
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import get_session
from ..schemas import OutboundMessageIn
from ..services.core import enqueue_outbound_and_record

router = APIRouter(prefix="/messages", tags=["messages"])

@router.post("")
async def send_message_api(payload: OutboundMessageIn, session: AsyncSession = Depends(get_session)):
    rec = await enqueue_outbound_and_record(session, payload)
    return {"status":"queued", "message_id": rec.id}
