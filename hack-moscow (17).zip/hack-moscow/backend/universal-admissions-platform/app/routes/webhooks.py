from __future__ import annotations
from fastapi import APIRouter, Request, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import get_session
from ..connectors.telegram import telegram_connector
from ..services.core import store_inbound_and_enqueue
from ..config import settings

router = APIRouter(prefix="/webhooks", tags=["webhooks"])

@router.post("/telegram")
async def telegram_webhook(request: Request, session: AsyncSession = Depends(get_session)):
    if not telegram_connector.verify_signature(dict(request.headers)):
        raise HTTPException(status_code=401, detail="bad signature")
    payload = await request.json()
    events = await telegram_connector.normalize_inbound(payload)
    for ev in events: await store_inbound_and_enqueue(session, ev)
    return {"ok": True}

@router.post("/vk")
async def vk_webhook(request: Request, session: AsyncSession = Depends(get_session)):
    data = await request.json()
    t = data.get("type")
    secret_ok = (settings.vk_secret is None) or (data.get("secret") == settings.vk_secret)
    if t == "confirmation":
        return settings.vk_confirmation_response or "ok"
    if not secret_ok:
        raise HTTPException(status_code=401, detail="bad vk secret")
    if t == "message_new":
        obj = data.get("object",{}).get("message",{})
        ev = {
            "channel":"vk",
            "channel_user_id": str(obj.get("peer_id")),
            "type":"text",
            "text": obj.get("text",""),
            "attachments":[],
            "direction":"inbound",
        }
        await store_inbound_and_enqueue(session, ev)
    return "ok"

@router.post("/onec")
async def onec_webhook(request: Request, session: AsyncSession = Depends(get_session)):
    token = request.headers.get("X-ONEC-TOKEN")
    if token != settings.onec_inbound_token or not token:
        raise HTTPException(status_code=401, detail="bad onec token")
    data = await request.json()
    ev = {
        "channel": "onec",
        "channel_user_id": str(data.get("channel_user_id", "")),
        "conversation_id": str(data.get("conversation_id", "")) or None,
        "type": data.get("type","text"),
        "text": data.get("text"),
        "attachments": data.get("attachments", []),
        "direction": "inbound",
        "metadata": data.get("meta", {})
    }
    await store_inbound_and_enqueue(session, ev)
    return {"ok": True}
