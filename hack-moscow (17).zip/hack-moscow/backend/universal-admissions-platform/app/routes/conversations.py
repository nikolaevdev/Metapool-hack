from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_session
from ..models import Conversation, Message, User

router = APIRouter(prefix="/conversations", tags=["conversations"])

@router.get("")
async def list_conversations(session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Conversation).order_by(Conversation.last_msg_at.desc()).limit(100))
    items = q.scalars().all()
    return [{"id":c.id, "user_id": c.user_id, "status": c.status, "last_msg_at": c.last_msg_at.isoformat()} for c in items]

@router.get("/{conv_id}")
async def get_conversation(conv_id: str, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Conversation).where(Conversation.id == conv_id))
    c = q.scalar_one_or_none()
    if not c: raise HTTPException(status_code=404, detail="not found")
    q2 = await session.execute(select(User).where(User.id == c.user_id))
    u = q2.scalar_one_or_none()
    return {"id": c.id, "status": c.status, "user": {"id": u.id if u else None, "channel": u.channel if u else None, "channel_user_id": u.channel_user_id if u else None}}

@router.get("/{conv_id}/messages")
async def get_messages(conv_id: str, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Message).where(Message.conversation_id == conv_id).order_by(Message.created_at))
    rows = q.scalars().all()
    return [{"id":m.id,"direction":m.direction,"type":m.type,"status":m.status,"text":m.text,"created_at":m.created_at.isoformat()} for m in rows]
