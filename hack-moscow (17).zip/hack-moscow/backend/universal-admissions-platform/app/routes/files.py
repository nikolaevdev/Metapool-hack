from __future__ import annotations
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from ..db import get_session
from ..storage import save_upload, get_file, as_file_response
from ..schemas import FileOut

router = APIRouter(prefix="/files", tags=["files"])

@router.post("/upload", response_model=FileOut)
async def upload_file(file: UploadFile = File(...), session: AsyncSession = Depends(get_session)):
    rec = await save_upload(session, file)
    return FileOut(id=rec.id, original_name=rec.original_name, mime=rec.mime, size=rec.size, download_url=f"/files/{rec.id}/download")

@router.get("/{file_id}/download")
async def download_file(file_id: str, session: AsyncSession = Depends(get_session)):
    rec = await get_file(session, file_id)
    if not rec: raise HTTPException(status_code=404, detail="file not found")
    return as_file_response(rec)
