from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from ..db import get_session
from ..models import Escalation, Conversation
from ..schemas import EscalationOut
from ..services.core import escalate

router = APIRouter(prefix="/escalations", tags=["escalations"])

@router.get("")
async def list_escalations(session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Escalation).where(Escalation.status != "resolved"))
    rows = q.scalars().all()
    return [EscalationOut(id=r.id, conversation_id=r.conversation_id, reason=r.reason, status=r.status, created_at=r.created_at.isoformat()) for r in rows]

@router.post("/{esc_id}/resolve")
async def resolve_escalation(esc_id: str, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Escalation).where(Escalation.id == esc_id))
    esc = q.scalar_one_or_none()
    if not esc: raise HTTPException(status_code=404, detail="not found")
    esc.status = "resolved"
    await session.commit()
    return {"status":"resolved", "id": esc_id}

@router.post("/conversations/{conv_id}/escalate")
async def force_escalate(conv_id: str, session: AsyncSession = Depends(get_session)):
    q = await session.execute(select(Conversation).where(Conversation.id == conv_id))
    conv = q.scalar_one_or_none()
    if not conv: raise HTTPException(status_code=404, detail="conversation not found")
    esc = await escalate(session, conv, reason="Manual escalation")
    return {"status":"queued","escalation_id": esc.id}
