from __future__ import annotations
from typing import Optional, Literal
from pydantic import BaseModel, Field

class OutboundMessageIn(BaseModel):
    channel: Literal["telegram","onec","vk","webchat"]
    channel_user_id: str
    conversation_id: Optional[str] = None
    type: Literal["text","image","file","typing"]
    text: Optional[str] = None
    file_id: Optional[str] = None
    idempotency_key: Optional[str] = Field(default=None)

class FileOut(BaseModel):
    id: str
    original_name: str
    mime: Optional[str] = None
    size: int
    download_url: str

class EscalationOut(BaseModel):
    id: str
    conversation_id: str
    reason: str
    status: str
    created_at: str
