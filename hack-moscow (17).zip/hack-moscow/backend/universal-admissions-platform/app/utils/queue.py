from __future__ import annotations
import json
from typing import Any, Dict
import redis.asyncio as redis
from ..config import settings

INBOUND_STREAM = "inbound"
OUTBOUND_TG_STREAM = "outbound:telegram"
OUTBOUND_ONEC_STREAM = "outbound:onec"
OUTBOUND_VK_STREAM = "outbound:vk"
OUTBOUND_WEBCHAT_STREAM = "outbound:webchat"
ESCALATIONS_STREAM = "escalations"

_redis: redis.Redis | None = None

def get_redis() -> redis.Redis:
    global _redis
    if _redis is None:
        _redis = redis.from_url(settings.redis_url, decode_responses=True)
    return _redis

async def push_inbound(event: Dict[str, Any]) -> str:
    r = get_redis()
    return await r.xadd(INBOUND_STREAM, {"payload": json.dumps(event, ensure_ascii=False)})

async def push_outbound(stream: str, msg: Dict[str, Any]) -> str:
    r = get_redis()
    return await r.xadd(stream, {"payload": json.dumps(msg, ensure_ascii=False)})

async def push_escalation(ev: Dict[str, Any]) -> str:
    r = get_redis()
    return await r.xadd(ESCALATIONS_STREAM, {"payload": json.dumps(ev, ensure_ascii=False)})
