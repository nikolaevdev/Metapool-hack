from allauth.account.adapter import DefaultAccountAdapter
from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives

class CustomAccountAdapter(DefaultAccountAdapter):
    def send_mail(self, template_prefix, email, context):
        subject = render_to_string(f"{template_prefix}_subject.txt", context).strip()
        msg_txt = render_to_string(f"{template_prefix}_message.txt", context)
        try:
            msg_html = render_to_string(f"{template_prefix}_message.html", context)
        except Exception:
            msg_html = None
        message = EmailMultiAlternatives(subject, msg_txt, to=[email])
        if msg_html:
            message.attach_alternative(msg_html, "text/html")
        message.send()
