# backend/backend/asgi.py
import os

# 1) Сначала — настройки Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

# Инициализируем Django ДО любых импортов моделей/приложений
import django
django.setup()

from django.core.asgi import get_asgi_application
from starlette.applications import Starlette
from starlette.routing import Mount

# 2) Поднимаем чистый ASGI Django
django_asgi_app = get_asgi_application()

# 3) Теперь можно импортировать FastAPI, внутри которого тянутся модели/роутеры
from fastapi_app.main import app as fastapi_app
'''
try:
    from fastapi_app.main import app as fastapi_app
except Exception:
    # Fallback, чтобы не падать при временных ошибках FastAPI части
    from fastapi import FastAPI
    fastapi_app = FastAPI(title="FastAPI (fallback)")
'''

# 4) Композит: /api -> FastAPI, / -> Django
application = Starlette(
    routes=[
        Mount("/api", app=fastapi_app),
        Mount("/", app=django_asgi_app),
    ]
)

# 5) Алиас для конфигураций, которые ожидают ":app"
app = application

