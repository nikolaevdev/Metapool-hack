from langdetect import detect, DetectorFactory
DetectorFactory.seed = 42

def detect_lang(text: str) -> str:
    try:
        return detect(text or "")
    except Exception:
        return "en"
