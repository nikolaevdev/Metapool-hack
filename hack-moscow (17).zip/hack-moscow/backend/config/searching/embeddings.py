import os
from functools import lru_cache
from typing import List, Optional
from sentence_transformers import SentenceTransformer

DEFAULT_MODEL_EN = os.getenv("EMBEDDING_MODEL_EN", "sentence-transformers/all-MiniLM-L6-v2")
DEFAULT_MODEL_MULTI = os.getenv("EMBEDDING_MODEL_MULTI", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")

MODEL_BY_LANG = {
    "en": DEFAULT_MODEL_EN,
    "ru": DEFAULT_MODEL_MULTI,
    "uk": DEFAULT_MODEL_MULTI,
    "de": DEFAULT_MODEL_MULTI,
    "fr": DEFAULT_MODEL_MULTI,
    "es": DEFAULT_MODEL_MULTI,
}

@lru_cache(maxsize=8)
def _get_model(model_name: str) -> SentenceTransformer:
    return SentenceTransformer(model_name)

def get_model(lang: Optional[str] = None) -> SentenceTransformer:
    name = MODEL_BY_LANG.get((lang or "en").split("-")[0].lower(), DEFAULT_MODEL_MULTI)
    return _get_model(name)

def embed_texts(texts: List[str], lang: Optional[str] = None) -> List[List[float]]:
    model = get_model(lang)
    return model.encode(texts, convert_to_numpy=False, normalize_embeddings=True).tolist()

def dim(lang: Optional[str] = None) -> int:
    model = get_model(lang)
    try:
        return model.get_sentence_embedding_dimension()
    except Exception:
        v = model.encode(["test"], convert_to_numpy=False, normalize_embeddings=True)[0]
        return len(v)
