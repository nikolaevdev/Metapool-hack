from fastapi.responses import JSONResponse
from backend.fastapi_app.schemas.common import StandardResponse, ErrorResponse, Meta

def ok(data=None, message: str="ok", status_code: int = 200):
    return JSONResponse(StandardResponse(status="ok", data=data, meta=Meta(message=message)).model_dump(), status_code=status_code)

def created(data=None, message: str="created"):
    return ok(data=data, message=message, status_code=201)

def no_content(message: str="no content"):
    return JSONResponse(StandardResponse(status="ok", data=None, meta=Meta(message=message)).model_dump(), status_code=204)

def error(message: str, status_code: int=400):
    return JSONResponse(ErrorResponse(status="error", error=message, meta=Meta(message=message)).model_dump(), status_code=status_code)
