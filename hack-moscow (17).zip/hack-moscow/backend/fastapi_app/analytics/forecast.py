
from typing import List, Tuple, Dict
from datetime import datetime, timedelta
from asgiref.sync import sync_to_async
from django.db import connection

def _fetch_daily_totals(days_back: int = 60) -> List[Tuple[str,int]]:
    # агрегируем из telemetry_events (PG), если нет — пусто
    sql = "SELECT date(ts) d, count(*) FROM telemetry_events GROUP BY d ORDER BY d"
    with connection.cursor() as cur:
        cur.execute(sql)
        rows = cur.fetchall()
    return [(str(r[0]), int(r[1])) for r in rows]

async def forecast(days_back: int = 60, horizon: int = 14) -> Dict[str, list]:
    data = await sync_to_async(_fetch_daily_totals)(days_back)
    if not data:
        # заглушка: пустой прогноз
        base = datetime.utcnow().date()
        return {"history": [], "forecast": [(str(base + timedelta(days=i+1)), 0.0) for i in range(horizon)]}
    ds = [d for d,_ in data]
    ys = [y for _,y in data]

    # Пытаемся Prophet
    try:
        from prophet import Prophet  # type: ignore
        import pandas as pd
        df = pd.DataFrame({"ds": pd.to_datetime(ds), "y": ys})
        m = Prophet()
        m.fit(df)
        future = m.make_future_dataframe(periods=horizon)
        fc = m.predict(future).tail(horizon)
        return {"history": data, "forecast": [(str(d.date()), float(y)) for d,y in zip(fc["ds"], fc["yhat"])]}
    except Exception:
        pass

    # Пытаемся ARIMA
    try:
        from statsmodels.tsa.arima.model import ARIMA  # type: ignore
        import numpy as np
        model = ARIMA(ys, order=(1,1,1)).fit()
        fc = model.forecast(steps=horizon)
        base = datetime.fromisoformat(ds[-1]).date()
        return {"history": data, "forecast": [(str(base + timedelta(days=i+1)), float(fc[i])) for i in range(horizon)]}
    except Exception:
        pass

    # Наивный средний
    avg = sum(ys)/len(ys)
    base = datetime.fromisoformat(ds[-1]).date()
    return {"history": data, "forecast": [(str(base + timedelta(days=i+1)), float(avg)) for i in range(horizon)]}
