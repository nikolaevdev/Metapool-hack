
import os, json
from typing import Any, Dict, Optional
import asyncpg
from datetime import datetime

PG_DSN = os.getenv("PG_ANALYTICS_DSN", "")

DDL_MAIN = """
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS analytics_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  category TEXT NOT NULL,
  payload JSONB NOT NULL
) PARTITION BY RANGE (ts);
"""

MARTS = """
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_daily_counts AS
  SELECT date_trunc('day', ts) AS day, category, count(*) AS cnt
  FROM analytics_events
  GROUP BY 1,2;

CREATE MATERIALIZED VIEW IF NOT EXISTS mv_hourly_heat AS
  SELECT extract(dow from ts)::int AS weekday, extract(hour from ts)::int AS hour, count(*) AS cnt
  FROM analytics_events
  GROUP BY 1,2;
"""

async def _ensure_partitions(conn):
    now = datetime.utcnow()
    y, m = now.year, now.month
    next_y = y + (1 if m == 12 else 0)
    next_m = 1 if m == 12 else m + 1
    part_this = f"analytics_events_{y}_{m:02d}"
    part_next = f"analytics_events_{next_y}_{next_m:02d}"
    await conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {part_this} PARTITION OF analytics_events
        FOR VALUES FROM ('{y}-{m:02d}-01') TO ('{y}-{(m%12)+1:02d}-01');
    """)
    await conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {part_next} PARTITION OF analytics_events
        FOR VALUES FROM ('{next_y}-{next_m:02d}-01') TO ('{(next_y if next_m<12 else next_y+1)}-{(1 if next_m==12 else next_m+1):02d}-01');
    """)

async def ensure_schema():
    if not PG_DSN:
        return False
    conn = await asyncpg.connect(PG_DSN)
    try:
        await conn.execute(DDL_MAIN)
        await _ensure_partitions(conn)
        await conn.execute(MARTS)
        return True
    finally:
        await conn.close()

async def write_event(category: str, payload: Dict[str, Any]):
    if not PG_DSN:
        return False
    conn = await asyncpg.connect(PG_DSN)
    try:
        await conn.execute("INSERT INTO analytics_events(category, payload) VALUES($1,$2)", category, json.dumps(payload))
        return True
    finally:
        await conn.close()
