
from typing import Any, Dict
from asgiref.sync import sync_to_async
from django.db import connection

async def log_event_pg(category: str, payload: Dict[str, Any]):
    sql = "INSERT INTO telemetry_events (category, payload) VALUES (%s, %s::jsonb)"
    await sync_to_async(lambda: _exec(sql, [category, json_dumps(payload)]))()

def _exec(sql, params):
    from psycopg2.extras import Json
    with connection.cursor() as cur:
        cur.execute(sql, params)

def json_dumps(d: Dict[str, Any]) -> str:
    import json
    return json.dumps(d, ensure_ascii=False)
