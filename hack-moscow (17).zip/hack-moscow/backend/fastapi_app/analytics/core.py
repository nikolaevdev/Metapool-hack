
import json
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import redis.asyncio as redis
from fastapi_app.analytics.store_pg import log_event_pg

KEY_EVENTS = "analytics:events"           # LPUSH JSON
KEY_COUNT_PREFIX = "analytics:count"      # analytics:count:YYYY-MM-DD:category -> int

def _day_key(day: datetime, category: str) -> str:
    return f"{KEY_COUNT_PREFIX}:{day.strftime('%Y-%m-%d')}:{category}"

async def log_event(r: "redis.Redis", category: str, payload: Dict[str, Any]):
    # PG (надежное хранилище)
    try:
        await log_event_pg(category, payload)
    except Exception:
        pass
    now = datetime.utcnow()
    rec = {"ts": now.isoformat(), "category": category, **payload}
    await r.lpush(KEY_EVENTS, json.dumps(rec))
    await r.incr(_day_key(now, category))

async def fetch_events(r: "redis.Redis", limit: int = 200) -> List[Dict[str, Any]]:
    items = await r.lrange(KEY_EVENTS, 0, max(0, limit-1))
    return [json.loads(x) for x in items]

async def summary_counts(r: "redis.Redis", days: int = 14) -> Dict[str, Dict[str, int]]:
    from datetime import timedelta
    res: Dict[str, Dict[str, int]] = {}
    cats = set()
    now = datetime.utcnow().date()
    for i in range(days):
        d = now - timedelta(days=i)
        # перебирать категории не очень эффективно — вытащим по тем, что встречаются в событиях
        # для простоты считаем по top-событиям
        events = await fetch_events(r, limit=1000)
        for e in events:
            cats.add(e.get("category", "other"))
        for cat in cats:
            key = f"{KEY_COUNT_PREFIX}:{d.isoformat()}:{cat}"
            cnt = int(await r.get(key) or 0)
            res.setdefault(d.isoformat(), {})[cat] = cnt
    return res

async def heatmap_by_weekday_hour(r: "redis.Redis", limit: int = 2000) -> List[List[int]]:
    # 7x24 матрица
    m = [[0 for _ in range(24)] for _ in range(7)]
    items = await fetch_events(r, limit=limit)
    for it in items:
        try:
            ts = datetime.fromisoformat(it["ts"])
            wd = ts.weekday()  # 0..6
            hr = ts.hour       # 0..23
            m[wd][hr] += 1
        except Exception:
            pass
    return m

async def predict_next_days(r: "redis.Redis", days_back: int = 14, horizon: int = 7) -> List[Tuple[str, float]]:
    # Грубый прогноз: среднее за последние N дней
    from datetime import timedelta
    now = datetime.utcnow().date()
    totals = []
    for i in range(days_back):
        d = now - timedelta(days=i)
        # сумма по всем категориям за день
        events = await fetch_events(r, limit=5000)
        s = 0
        for e in events:
            ts = datetime.fromisoformat(e["ts"]).date()
            if ts == d:
                s += 1
        totals.append(s)
    avg = sum(totals)/len(totals) if totals else 0.0
    return [((now + timedelta(days=i+1)).isoformat(), avg) for i in range(horizon)]
