
import asyncio
import logging
from typing import Optional

import redis.asyncio as redis
from aiogram import Bot

from fastapi_app.bots.admission.config import Settings as BotSettings

log = logging.getLogger(__name__)

async def alerts_loop(bot: Bot, stop_event: asyncio.Event):
    r = redis.from_url(BotSettings().REDIS_URL, decode_responses=True)
    while not stop_event.is_set():
        try:
            # Пример простых алертов: много pending или сессий без оператора
            pend = await r.hlen("op:pending")
            sess = await r.hlen("op:sessions")
            if pend > 20:  # пороги вынести в конфиг при необходимости
                # отправьте уведомление ответственному оператору/каналу (требует chat_id)
                pass
            await asyncio.sleep(30)
        except Exception:
            await asyncio.sleep(5)

async def start_alerts(bot: Bot) -> list[asyncio.Task]:
    stop_event = asyncio.Event()
    task = asyncio.create_task(alerts_loop(bot, stop_event))
    task.__alerts_stop_event__ = stop_event  # type: ignore
    return [task]

async def stop_alerts(tasks: list[asyncio.Task]):
    if not tasks:
        return
    stop_event: Optional[asyncio.Event] = getattr(tasks[0], "__alerts_stop_event__", None)  # type: ignore
    if stop_event:
        stop_event.set()
    for t in tasks:
        t.cancel()
