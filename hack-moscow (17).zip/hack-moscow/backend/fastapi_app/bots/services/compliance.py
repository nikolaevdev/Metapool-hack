
import re
from dataclasses import dataclass
from typing import Tuple

# Простые регэкспы (демо): РФ номера телефонов, email, паспорт РФ, СНИЛС
RX_PHONE = re.compile(r"(?:\+7|8)[\s\-\(\)]?\d{3}[\s\-\)]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}")
RX_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
# Паспорт: серия 4 цифры + номер 6 цифр (упрощённо, допускаем пробелы)
RX_PASSPORT = re.compile(r"\b\d{2}\s?\d{2}\s?\d{6}\b")
# СНИЛС: 000-000-000 00
RX_SNILS = re.compile(r"\b\d{3}-\d{3}-\d{3}\s?\d{2}\b")

# Словарь "красных флагов" (ключевые слова/фразы)
SENSITIVE_KEYWORDS = [
    "паспорт", "паспортные данные", "серия и номер", "снилс", "полис омс", "медполис",
    "inn", "инн", "свидетельство о рождении", "адрес прописки", "адрес регистрации",
    "телефон", "номер телефона", "email", "почта", "электронная почта",
    "номер карты", "cvv", "cvc", "pin", "пин-код", "банковская карта",
    "персональные данные", "пдн", "личные данные",
]

BADGE_TEXT = "Нужна проверка"

@dataclass
class ComplianceResult:
    flagged: bool
    masked_text: str
    reason: str

def _mask_phone(m: re.Match) -> str:
    s = m.group(0)
    return s[:4] + "****" + s[-4:]

def _mask_email(m: re.Match) -> str:
    s = m.group(0)
    parts = s.split("@")
    if len(parts) != 2:
        return "***@***"
    name, domain = parts
    name_mask = (name[:1] + "***") if name else "***"
    return name_mask + "@" + domain

def _mask_passport(m: re.Match) -> str:
    s = re.sub(r"\s+", "", m.group(0))
    return s[:2] + "**" + s[4:6] + "****"

def _mask_snils(m: re.Match) -> str:
    s = m.group(0)
    return "XXX-XXX-XXX XX"

def check_and_mask(text: str) -> ComplianceResult:
    t = text or ""
    masked = t

    found = False
    if RX_PHONE.search(t):
        masked = RX_PHONE.sub(_mask_phone, masked)
        found = True
    if RX_EMAIL.search(t):
        masked = RX_EMAIL.sub(_mask_email, masked)
        found = True
    if RX_PASSPORT.search(t):
        masked = RX_PASSPORT.sub(_mask_passport, masked)
        found = True
    if RX_SNILS.search(t):
        masked = RX_SNILS.sub(_mask_snils, masked)
        found = True

    # Ключевые слова (мягкая защита)
    kw_flag = any(kw.lower() in t.lower() for kw in SENSITIVE_KEYWORDS)

    reason = BADGE_TEXT if (found or kw_flag) else ""
    return ComplianceResult(flagged=(found or kw_flag), masked_text=masked, reason=reason)
