
import json
from typing import Any, Dict, Optional
from asgiref.sync import sync_to_async
from django.db import connection

async def push_pg(item: Dict[str, Any]) -> int:
    sql = "INSERT INTO queue_jobs (payload) VALUES (%s::jsonb) RETURNING id"
    return await sync_to_async(_exec_returning)(sql, [json.dumps(item, ensure_ascii=False)])

async def pop_pg() -> Optional[Dict[str, Any]]:
    sql = """
    UPDATE queue_jobs
    SET status='in_progress', locked_at=now(), attempts=attempts+1
    WHERE id = (
        SELECT id FROM queue_jobs
        WHERE status='queued'
        ORDER BY created_at
        FOR UPDATE SKIP LOCKED
        LIMIT 1
    )
    RETURNING id, payload
    """
    row = await sync_to_async(_exec_fetchone)(sql)
    if not row:
        return None
    job_id, payload = row
    try:
        data = json.loads(payload)
    except Exception:
        data = {"raw": payload}
    data["__job_id"] = job_id
    return data

async def mark_done(job_id: int):
    await sync_to_async(_exec)("UPDATE queue_jobs SET status='done' WHERE id=%s", [job_id])

async def mark_failed(job_id: int):
    await sync_to_async(_exec)("UPDATE queue_jobs SET status='failed' WHERE id=%s", [job_id])

def _exec(sql, params=None):
    with connection.cursor() as cur:
        cur.execute(sql, params or [])

def _exec_fetchone(sql, params=None):
    with connection.cursor() as cur:
        cur.execute(sql, params or [])
        return cur.fetchone()

def _exec_returning(sql, params=None):
    with connection.cursor() as cur:
        cur.execute(sql, params or [])
        row = cur.fetchone()
        return row[0] if row else 0
