
import re
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class EscalationMeta:
    score: float
    reasons: List[str]
    features: dict

_NEG_PATTERNS_CACHE = {}

def _has_negative_phrases(text: str, patterns: str) -> bool:
    # patterns: "phrase1;phrase2;..."
    key = patterns
    rx = _NEG_PATTERNS_CACHE.get(key)
    if rx is None:
        parts = [re.escape(p.strip()) for p in patterns.split(";") if p.strip()]
        rx = re.compile(r"\b(" + "|".join(parts) + r")\b", re.IGNORECASE) if parts else None
        _NEG_PATTERNS_CACHE[key] = rx
    if not rx:
        return False
    return bool(rx.search(text or ""))

def compute_confidence(question: str, raw_answer: str, final_answer: str,
                       attachments_count: int,
                       min_atts: int,
                       min_answer_len: int,
                       negative_phrases: str) -> EscalationMeta:
    reasons = []
    score_parts = []

    # coverage by attachments
    if attachments_count >= max(1, min_atts):
        score_parts.append(0.35)
    else:
        reasons.append(f"недостаточно материалов: {attachments_count} < {min_atts}")
        score_parts.append(0.0)

    # answer length
    final_len = len((final_answer or "").strip())
    if final_len >= min_answer_len:
        score_parts.append(0.35)
    else:
        reasons.append(f"короткий ответ: {final_len} < {min_answer_len}")
        score_parts.append(0.0)

    # negativity
    neg = _has_negative_phrases(final_answer or "", negative_phrases) or _has_negative_phrases(raw_answer or "", negative_phrases)
    if not neg:
        score_parts.append(0.3)
    else:
        reasons.append("обнаружены негативные сигналы ('не знаю'/'нет информации')")
        score_parts.append(0.0)

    score = sum(score_parts)  # 0..1
    return EscalationMeta(score=score, reasons=reasons, features={
        "attachments_count": attachments_count,
        "final_len": final_len,
        "neg_detected": neg,
    })

def should_escalate(meta: EscalationMeta, threshold: float, retries_done: int, max_retries: int) -> Tuple[bool, str]:
    if meta.score >= threshold:
        return False, ""
    if retries_done < max_retries:
        return False, f"низкая уверенность (score={meta.score:.2f}) — ещё одна попытка"
    # escalate
    reason = "низкая уверенность: " + ", ".join(meta.reasons) if meta.reasons else f"score={meta.score:.2f} ниже порога"
    return True, reason
