
from enum import Enum
from dataclasses import dataclass
from typing import Literal, Optional

from fastapi_app.bots.services.compliance import check_and_mask

class PIIClass(str, Enum):
    LOW = "low"        # телефоны, email
    MEDIUM = "medium"  # паспорт, СНИЛС
    HIGH = "high"      # банковские карты, CVV, PIN (детектится словарём в compliance)

@dataclass
class PolicyDecision:
    action: Literal["allow", "mask_escalate", "block_escalate"]
    reason: str
    masked_text: Optional[str] = None

# Упрощённая матрица по ролям
ROLE_POLICY = {
    # внешний пользователь — максимум маскировать и эскалировать
    "external_user": {
        PIIClass.LOW: "mask_escalate",
        PIIClass.MEDIUM: "mask_escalate",
        PIIClass.HIGH: "block_escalate",
    },
    # оператор — может видеть низкий класс (замаскированный), средний только замаскированный, high — блок
    "operator": {
        PIIClass.LOW: "mask_escalate",
        PIIClass.MEDIUM: "mask_escalate",
        PIIClass.HIGH: "block_escalate",
    },
    # администратор комплаенса — просмотр через защищённый контур (пока так же)
    "compliance_admin": {
        PIIClass.LOW: "mask_escalate",
        PIIClass.MEDIUM: "mask_escalate",
        PIIClass.HIGH: "block_escalate",
    },
}

def classify_pii(comp_reason: str) -> PIIClass:
    # Грубая эвристика: наличие ключевых слов в тексте уже проверено в compliance
    # Идентифицируем класс по типу найденных сущностей
    r = comp_reason.lower()
    if "паспорт" in r or "снилс" in r:
        return PIIClass.MEDIUM
    if "карта" in r or "cvv" in r or "pin" in r:
        return PIIClass.HIGH
    return PIIClass.LOW

def decide(role: str, text: str) -> PolicyDecision:
    c = check_and_mask(text)
    if not c.flagged:
        return PolicyDecision(action="allow", reason="no_pii")
    cls = classify_pii(text)
    action = ROLE_POLICY.get(role, ROLE_POLICY["external_user"]).get(cls, "mask_escalate")
    if action == "block_escalate":
        return PolicyDecision(action=action, reason=f"{c.reason}:{cls.value}", masked_text="")
    return PolicyDecision(action=action, reason=f"{c.reason}:{cls.value}", masked_text=c.masked_text or "")
