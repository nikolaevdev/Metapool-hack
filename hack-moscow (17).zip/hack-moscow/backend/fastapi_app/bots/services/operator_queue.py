
import asyncio
import json
import logging
from typing import Optional, List

import redis.asyncio as redis
from aiogram import Bot
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from fastapi_app.bots.adapters.telegram_operator import OpAction, kb_job
from fastapi_app.bots.adapters.telegram_operator import R_ON_SHIFT, R_JOB2CHAT, R_CHAT2JOB, R_PENDING

log = logging.getLogger(__name__)

async def _list_on_shift(r: redis.Redis) -> List[int]:
    members = await r.smembers(R_ON_SHIFT)
    return [int(m) for m in members or []]

async def operator_queue_loop(bot: Bot, stop_event: asyncio.Event):
    r = redis.from_url("redis://localhost:6379/0", decode_responses=True)
    log.info("Operator queue listener started")
    while not stop_event.is_set():
        try:
            res = await r.blpop("operator_queue", timeout=2)
            if not res:
                await asyncio.sleep(0.1)
                continue
            _, payload = res
            job = json.loads(payload)
            meta = job.get("meta") or {}
            badge = meta.get("badge")
            job_id = job.get("job_id")
            chat_id = int(job.get("chat_id"))
            transcript = job.get("transcript") or ""

            # сохранить соответствие
            await r.hset(R_JOB2CHAT, job_id, str(chat_id))
            await r.hset(R_CHAT2JOB, str(chat_id), job_id)

            # уведомить всех в смене
            ops = await _list_on_shift(r)
            if not ops:
                # никого нет на смене — оставляем в pending
                await r.hset(R_PENDING, str(chat_id), "1")
                continue

            meta_line = ""
            if meta:
                meta_line = f"\n\n<i>Автоэскалация по причине:</i> {meta.get('reason', '-')} (score={meta.get('score', '-')})"
            badge_line = f"\n<b>[{badge}]</b>" if badge else ""
            text = f"🆕 Новая заявка #{job_id[:8]} от пользователя {chat_id}{badge_line}\n\n{transcript or 'Без текста'}{meta_line}"
            kb = kb_job(job_id)
            for op_id in ops:
                try:
                    await bot.send_message(op_id, text, reply_markup=kb)
                except Exception:
                    log.exception("notify operator %s failed", op_id)

        except Exception as e:
            log.exception("operator_queue_loop error: %s", e)
            await asyncio.sleep(0.5)

    log.info("Operator queue listener stopped")

async def start_operator_listener(bot: Bot) -> list[asyncio.Task]:
    stop_event = asyncio.Event()
    task = asyncio.create_task(operator_queue_loop(bot, stop_event))
    task.__opq_stop_event__ = stop_event  # type: ignore
    return [task]

async def stop_operator_listener(tasks: list[asyncio.Task]):
    if not tasks:
        return
    stop_event: Optional[asyncio.Event] = getattr(tasks[0], "__opq_stop_event__", None)  # type: ignore
    if stop_event:
        stop_event.set()
    for t in tasks:
        t.cancel()
