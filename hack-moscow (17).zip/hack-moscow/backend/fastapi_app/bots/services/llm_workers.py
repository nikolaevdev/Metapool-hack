
import asyncio
import logging
from typing import Optional, List, Tuple

from aiogram import Bot
import redis.asyncio as redis

from fastapi_app.bots.admission.redis_queue import RedisQueue, _pg_dequeue
from fastapi_app.bots.admission.config import Settings as BotSettings
from fastapi_app.bots.services.durable_queue import pop_pg, mark_done, mark_failed
from fastapi_app.bots.admission.search_adapter import get_top_attachments
from fastapi_app.bots.services.sources_enricher import enrich_attachments
from fastapi_app.bots.services.policy import decide
from fastapi_app.analytics.pg_store import write_event as pg_write_event
from fastapi_app.bots.services.sources import extract_clauses
from fastapi_app.bots.services.compliance import check_and_mask
from fastapi_app.analytics.core import log_event
from fastapi_app.bots.services.escalation import compute_confidence, should_escalate
from fastapi_app.bots.glossary.loader import detect_terms
from fastapi_app.bots.glossary.kg_loader import links_for_term
from fastapi_app.bots.admission.LMStudio_gpt_sdk_async import rewrite_answer as lmstudio_rewrite

log = logging.getLogger(__name__)

# Redis keys
R_CHAT2JOB = "dlg:chat2job"
R_JOB2CHAT = "op:job2chat"
R_SESSIONS = "op:sessions"
R_PENDING  = "op:pending"
R_LOWCONF  = "llm:lowconf"   # chat_id -> retries counter

async def _build_raw_answer(question: str, settings: BotSettings) -> Tuple[str, List]:
    """Вернуть краткую компиляцию найденных материалов + список самих объектов."""
    try:
        atts = await get_top_attachments(question, settings)
    except Exception as e:
        log.exception("search failed: %s", e)
        return "", []
    if not atts:
        return "", []
    lines = [f"- {getattr(a, 'title', str(a))}" for a in atts]
    return "Найдены материалы:\n" + "\n".join(lines), atts

async def _llm_answer(question: str, settings: BotSettings) -> Tuple[str, List]:
    raw, atts = await _build_raw_answer(question, settings)
    try:
        loop = asyncio.get_running_loop()
        answer = await loop.run_in_executor(None, lmstudio_rewrite, "", question, raw or question)
        return (answer or raw or "К сожалению, пока не нашёл ответа."), atts
    except Exception as e:
        log.exception("lmstudio failed: %s", e)
        return (raw or "К сожалению, пока не нашёл ответа."), atts

async def llm_worker_loop(bot: Bot, stop_event: asyncio.Event):
    settings = BotSettings()
    q = RedisQueue(settings.REDIS_URL, settings.REDIS_QUEUE_NAME)
    r = redis.from_url(settings.REDIS_URL, decode_responses=True)
    log.info("LLM worker started on %s / queue=%s", settings.REDIS_URL, settings.REDIS_QUEUE_NAME)

    while not stop_event.is_set():
        try:
            job = await q.pop(timeout=3)
            if not job:
                job = await _pg_dequeue()
            if not job:
                await asyncio.sleep(0.2)
                continue

            chat_id = int(job.get("chat_id"))
            text = (job.get("text") or "").strip()
            comp = check_and_mask(text)
            pol = decide(text, role='external')
            if pol.action == 'block':
                await pg_write_event('policy_block', {'chat_id': chat_id, 'reason': pol.reason})
                await bot.send_message(chat_id, '⚠️ Сообщение содержит запрещённые данные. Пожалуйста, удалите чувствительные реквизиты и повторите запрос.')
                continue
            if pol.action in ('mask','escalate'):
                text = pol.masked_text
            if comp.flagged:
                # Автоэскалация по комплаенсу
                await q.push_operator_request(chat_id, transcript=comp.masked_text, meta={"reason":"compliance:red_flag","badge":"Нужна проверка"})  # type: ignore[arg-type]
                await r.hset(R_PENDING, str(chat_id), "1")
                await bot.send_message(chat_id, "⚠️ Обращение содержит чувствительные данные. Подключаю оператора.")
                await log_event(r, "escalation_compliance", {"chat_id": chat_id})
                continue
            if not text:
                continue

            # 0) Ручная эскалация по ключевому слову
            low = text.lower()
            if low.startswith("/operator") or low.startswith("оператор") or low.startswith("живой"):
                await q.push_operator_request(chat_id, transcript=text, meta={"reason": "manual", "score": "-"})  # type: ignore[arg-type]
                await r.hset(R_PENDING, str(chat_id), "1")
                await bot.send_message(chat_id, "Передаю вопрос оператору. Ожидайте отклика.")
                continue

            # 1) Ответ модели
            answer, atts = await _llm_answer(text, settings)

            # 2) Оценка уверенности
            meta = compute_confidence(
                question=text,
                raw_answer="",
                final_answer=answer,
                attachments_count=len(atts),
                min_atts=settings.ESCALATION_MIN_ATTS,
                min_answer_len=settings.ESCALATION_MIN_ANSWER_LEN,
                negative_phrases=settings.ESCALATION_NEGATIVE_PHRASES,
            )
            retries = int(await r.hget(R_LOWCONF, str(chat_id)) or 0)
            do_escalate, reason = should_escalate(meta, settings.ESCALATION_SCORE_THRESHOLD, retries, settings.ESCALATION_MAX_RETRIES)

            if do_escalate:
                await log_event(r, "escalation_low_conf", {"chat_id": chat_id, "score": round(meta.score,2)})
                # увеличить счётчик и эскалировать
                await r.hset(R_LOWCONF, str(chat_id), str(retries + 1))
                await q.push_operator_request(chat_id, transcript=text, meta={
                    "reason": reason,
                    "score": round(meta.score, 2),
                    "features": meta.features,
                })  # type: ignore[arg-type]
                await r.hset(R_PENDING, str(chat_id), "1")
                await bot.send_message(chat_id, "Подключаю оператора — скоро ответит.")
                continue
            else:
                # сбросить счётчик и выдать ответ
                if retries:
                    await r.hdel(R_LOWCONF, str(chat_id))
                sources = _format_sources(atts)
                gloss = _format_glossary(text)
                await bot.send_message(chat_id, answer + (sources or "") + (gloss or ""))
                if job.get('__job_id'):
                    try: await mark_done(job['__job_id'])
                    except Exception: pass
                await log_event(r, "llm_answer", {"chat_id": chat_id})

        except Exception as e:
            log.exception("worker error: %s", e)
            # пометим как failed, если это PG-задача
            try:
                if job and job.get('__job_id'):
                    await mark_failed(job['__job_id'])
            except Exception:
                pass
            await asyncio.sleep(0.5)

    log.info("LLM worker stopped")

async def start_llm_pool(bot: Bot, workers: int = 3) -> list[asyncio.Task]:
    stop_event = asyncio.Event()
    tasks = [asyncio.create_task(llm_worker_loop(bot, stop_event)) for _ in range(workers)]
    tasks[0].__llm_stop_event__ = stop_event  # type: ignore
    return tasks

async def stop_llm_pool(tasks: list[asyncio.Task]):
    if not tasks:
        return
    stop_event: Optional[asyncio.Event] = getattr(tasks[0], "__llm_stop_event__", None)  # type: ignore
    if stop_event:
        stop_event.set()
    for t in tasks:
        t.cancel()


def _format_sources(atts, max_n: int = 3) -> str:
    if not atts:
        return ""
    items = []
    for a in atts[:max_n]:
        title = getattr(a, "title", None) or getattr(a, "name", None) or "Источник"
        url = getattr(a, "url", None) or getattr(a, "link", None) or getattr(a, "source", None) or ""
        if url:
            items.append(f"• {title}: {url}")
        else:
            items.append(f"• {title}")
    return "\n\n<b>Источники:</b>\n" + "\n".join(items)


def _format_glossary(text: str) -> str:
    items = detect_terms(text, limit=3)
    if not items:
        return ""
    enriched = []
    for t,d in items:
        links = links_for_term(t)
        if links:
            refs = "; ".join([f"{x.get('doc')} {x.get('clause','')}" for x in links])
            enriched.append(f"• {t.upper()}: {d} (НПА: {refs})")
        else:
            enriched.append(f"• {t.upper()}: {d}")
    lines = enriched
    return "\n\n<b>Глоссарий:</b>\n" + "\n".join(lines)
