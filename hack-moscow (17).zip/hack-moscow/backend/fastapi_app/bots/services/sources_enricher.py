
import re
from typing import List, Dict, Any

RX_CLAUSE = re.compile(r"\b(статья|ст\.|пункт|п\.|раздел|глава)\s+([IVXLC\d][\w\.\-\(\)]*)", re.IGNORECASE)
RX_NUM = re.compile(r"\bп\.?\s*\d+(?:\.\d+)*\b", re.IGNORECASE)

def extract_citations(text: str) -> List[str]:
    t = text or ""
    found = set()
    for m in RX_CLAUSE.finditer(t):
        found.add(f"{m.group(1).capitalize()} {m.group(2)}")
    for m in RX_NUM.finditer(t):
        found.add(m.group(0))
    return list(found)[:5]

def enrich_attachments(atts: list) -> list:
    res = []
    for a in atts or []:
        title = getattr(a, "title", None) or getattr(a, "name", None) or "Источник"
        url = getattr(a, "url", None) or getattr(a, "link", None) or getattr(a, "source", None) or ""
        body = getattr(a, "text", None) or getattr(a, "content", None) or getattr(a, "body", None) or ""
        cites = extract_citations(str(body)[:8000])
        res.append({"title": title, "url": url, "citations": cites})
    return res
