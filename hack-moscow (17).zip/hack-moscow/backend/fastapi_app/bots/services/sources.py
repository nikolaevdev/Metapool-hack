
import re
from typing import List
RX_CLAUSE = re.compile(r"(?:п\.?\s*\d+(?:\.\d+){0,3}|ст\.?\s*\d+(?:\.\d+)?|раздел\s*\d+|приложение\s*№?\s*\d+)", re.IGNORECASE)
def extract_clauses(text: str, max_items: int = 5) -> List[str]:
    if not text: return []
    found = []
    for m in RX_CLAUSE.finditer(text):
        val = m.group(0).strip()
        if val not in found:
            found.append(val)
        if len(found) >= max_items:
            break
    return found
