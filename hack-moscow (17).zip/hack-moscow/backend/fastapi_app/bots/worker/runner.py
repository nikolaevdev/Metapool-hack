# fastapi_app/bots/worker/runner.py
"""
Надёжный запуск Telegram-ботов (public/operator) внутри FastAPI-приложения.
— Поддержка aiogram v3.
— Безопасный старт/стоп, защита от двойного запуска при hot-reload.
— Экспорт «живых» Bot/Dispatcher в fastapi_app.bots.context для межботовой
  пересылки сообщений (operator ↔ public).
— Fallback: если TELEGRAM_USE_WEBHOOK=true, пока логируем и принудительно
  используем polling (для простоты и стабильности на хакатоне).
"""
from __future__ import annotations

import asyncio
import logging
import os
from typing import Callable, Dict

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from fastapi_app.config import (
    TELEGRAM_PUBLIC_BOT_TOKEN,
    TELEGRAM_OPERATOR_BOT_TOKEN,
    TELEGRAM_USE_WEBHOOK,
)
from fastapi_app.bots.context import set_public_bot, set_operator_bot

log = logging.getLogger(__name__)

# Держим контекст запущенных ботов/тасков, чтобы их можно было корректно остановить
_TASKS: Dict[str, asyncio.Task] = {}
_BOTS: Dict[str, Bot] = {}
_DPS: Dict[str, Dispatcher] = {}

# Флаг, предотвращающий повторный старт при uvicorn --reload (родитель + потомок)
_STARTED = False


async def _poll_forever(name: str, token: str, builder: Callable[[Bot], Dispatcher]) -> None:
    """Цикл polling для одного бота с авто-переподключением и очисткой webhook."""
    if not token:
        log.warning("[%s] Пропуск старта: token пуст.", name)
        return

    # Создаём Bot/Dispatcher
    bot = Bot(token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = builder(bot)

    # Сохраним для health/остановки и кросс-уведомлений
    _BOTS[name] = bot
    _DPS[name] = dp
    if name == "public":
        set_public_bot(bot)
    elif name == "operator":
        set_operator_bot(bot)

    # Какие апдейты реально нужны — пусть решит диспетчер по зарегистрированным хэндлерам
    allowed = dp.resolve_used_update_types()

    # Бесконечный цикл с backoff: при сетевых/временных ошибках переподнимаем поллинг
    backoff = 1.0
    MAX_BACKOFF = 30.0

    while True:
        try:
            # КРИТИЧЕСКОЕ: чистим webhook перед поллингом, иначе бот будет «немой»
            try:
                await bot.delete_webhook(drop_pending_updates=True)
            except Exception as e:
                log.debug("[%s] delete_webhook: %s", name, e)

            log.info("[%s] start polling... allowed_updates=%s", name, allowed)
            await dp.start_polling(
                bot,
                allowed_updates=allowed,
                handle_signals=False,  # сигналы ловит uvicorn
            )
            # Если polling завершился без исключения — выходим из цикла
            log.info("[%s] polling завершён штатно.", name)
            return

        except asyncio.CancelledError:
            # Нормальное завершение по stop_bots()
            log.info("[%s] polling отменён (CancelledError).", name)
            return

        except Exception as e:
            # Любая ошибка поллинга → логируем и пробуем перезапуск с backoff
            log.exception("[%s] ошибка поллинга: %s", name, e)
            await asyncio.sleep(backoff)
            backoff = min(MAX_BACKOFF, backoff * 2)  # экспоненциальный backoff

        finally:
            # На каждом цикле гарантируем закрытие HTTP-сессии, если dp завершил работу
            # (aiogram создаёт сессию внутри Bot; безопасно закрывать повторно)
            try:
                await bot.session.close()
            except Exception:
                pass


def _make_task(name: str, token: str, builder: Callable[[Bot], Dispatcher]) -> asyncio.Task:
    """Создаёт и регистрирует asyncio-task для бота."""
    task = asyncio.create_task(_poll_forever(name, token, builder), name=f"{name}-bot")
    _TASKS[name] = task
    return task


async def start_bots() -> None:
    """Публичный API: запуск обоих ботов.

    Защита от двойного запуска: при повторном вызове — игнорируем.
    ENV:
      — BOTS_ENABLED=false  → полностью отключить старт ботов;
      — RUN_BOTS=0          → отключить старт (например, в воркерах/миграциях).
    """
    global _STARTED

    if os.environ.get("BOTS_ENABLED", "true").lower() == "false":
        log.warning("Bots disabled by BOTS_ENABLED=false")
        return
    if os.environ.get("RUN_BOTS", "1").lower() in {"0", "false"}:
        log.warning("Bots disabled by RUN_BOTS env")
        return
    if _STARTED:
        log.info("start_bots(): уже запущено, пропускаю повторный старт.")
        return

    # Ленивая загрузка адаптеров (исключаем циклические импорты)
    from fastapi_app.bots.adapters.telegram_public import build_public_dispatcher
    from fastapi_app.bots.adapters.telegram_operator import build_operator_dispatcher

    if TELEGRAM_USE_WEBHOOK:
        log.warning(
            "TELEGRAM_USE_WEBHOOK=true — используется polling fallback. "
            "Для вебхуков потребуется отдельная конфигурация."
        )

    log.info("Инициализация ботов…")
    public_task = _make_task("public", TELEGRAM_PUBLIC_BOT_TOKEN, build_public_dispatcher)
    operator_task = _make_task("operator", TELEGRAM_OPERATOR_BOT_TOKEN, build_operator_dispatcher)

    _STARTED = True
    log.info("Боты запущены (polling в фоне).")


async def stop_bots() -> None:
    """Публичный API: мягкая остановка всех ботов (ожидание отмены и закрытие сессий)."""
    global _STARTED
    log.info("Остановка ботов…")

    # Отмена тасков polling и ожидание их завершения
    tasks = list(_TASKS.values())
    for t in tasks:
        try:
            t.cancel()
        except Exception:
            pass
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)
    _TASKS.clear()

    # Закрываем HTTP-сессии ботов на всякий случай
    for name, bot in list(_BOTS.items()):
        try:
            await bot.session.close()
        except Exception:
            pass
    _BOTS.clear()
    _DPS.clear()

    _STARTED = False
    log.info("Боты остановлены.")
