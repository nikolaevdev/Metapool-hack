
import json
from functools import lru_cache
from typing import List, Dict

@lru_cache(maxsize=1)
def load_kg() -> Dict[str, list]:
    try:
        with open(__file__.rsplit("/",1)[0] + "/kg.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def links_for_term(term: str) -> list:
    return load_kg().get(term.lower(), [])
