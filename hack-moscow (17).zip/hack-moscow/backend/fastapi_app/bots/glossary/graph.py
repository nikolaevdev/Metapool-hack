
import json
from functools import lru_cache
from typing import List, Tuple

@lru_cache(maxsize=1)
def load_edges():
    try:
        with open(__file__.rsplit("/",1)[0] + "/edges.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def linked_regulations(term: str, limit: int = 2) -> List[Tuple[str,str]]:
    g = load_edges()
    items = g.get(term.lower(), [])
    return items[:limit]
