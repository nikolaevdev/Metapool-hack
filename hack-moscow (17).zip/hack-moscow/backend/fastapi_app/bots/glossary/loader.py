
import json
import re
from functools import lru_cache
from typing import Dict, List, Tuple

@lru_cache(maxsize=1)
def load_glossary() -> Dict[str,str]:
    try:
        with open(__file__.rsplit("/",1)[0] + "/rosatom_glossary.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        # ожидаем формат: {"термин": "определение", ...}
        return {k.lower(): v for k,v in data.items()}
    except Exception:
        return {}

def detect_terms(text: str, limit: int = 5) -> List[Tuple[str,str]]:
    g = load_glossary()
    if not g: return []
    low = (text or "").lower()
    found = []
    for term, defi in g.items():
        if len(found) >= limit: break
        # простое вхождение как слово
        if re.search(r"\b" + re.escape(term) + r"\b", low):
            found.append((term, defi))
    return found
