"""
Асинхронная обёртка над функцией search_pools из приложения datalake.
"""

from typing import List

from asgiref.sync import sync_to_async

from datalake.search import search_pools
from datalake.models import Attachment
from tg_admission_bot.config import Settings


async def get_top_attachments(query: str, settings: Settings) -> List[Attachment]:
    """
    Возвращает первые N результатов (N задаётся в settings.SEARCH_RESULT_LIMIT).
    """
    res = await sync_to_async(search_pools)(query, None)
    return list(res)[: settings.SEARCH_RESULT_LIMIT]
