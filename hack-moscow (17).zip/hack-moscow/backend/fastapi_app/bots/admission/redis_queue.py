
import json, asyncio, uuid
from typing import Any, Optional
import redis.asyncio as redis
import os

class RedisQueue:
    def __init__(self, url: str, name: str):
        self._r = redis.from_url(url, decode_responses=True)
        self._name = name

    async def push(self, item: dict[str, Any]) -> str:
        """Кладём задание в конец очереди, возвращаем job-id."""
        jid = item.setdefault("job_id", str(uuid.uuid4()))
        await self._r.rpush(self._name, json.dumps(item))
        return jid

    async def pop(self, timeout: int = 0) -> Optional[dict[str, Any]]:
        """BLPOP из очереди. Возвращает dict или None по таймауту."""
        res = await self._r.blpop(self._name, timeout=timeout)
        if res and len(res) == 2:
            return json.loads(res[1])
        return None

    async def push_operator_request(self, chat_id: int, transcript: str = "", meta: Optional[dict] = None) -> str:
        """Спец-очередь для hand-off оператору."""
        job = {
            "job_id": str(uuid.uuid4()),
            "chat_id": chat_id,
            "transcript": transcript or "",
        }
        if meta:
            job["meta"] = meta
        await self._r.rpush("operator_queue", json.dumps(job))
        return job["job_id"]

PG_DSN = os.getenv("PG_ANALYTICS_DSN","")

async def _pg_enqueue(table: str, payload: dict) -> str:
    if not PG_DSN: return ""
    conn = await asyncpg.connect(PG_DSN)
    try:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS ai_jobs (
                id UUID PRIMARY KEY,
                payload JSONB NOT NULL,
                status TEXT NOT NULL DEFAULT 'ready',
                created_at TIMESTAMPTZ NOT NULL DEFAULT now()
            );
        """)
        jid = payload.get("job_id") or str(uuid.uuid4())
        await conn.execute("INSERT INTO ai_jobs(id, payload, status) VALUES($1,$2,'ready')", jid, json.dumps(payload))
        return jid
    finally:
        await conn.close()

async def _pg_dequeue() -> dict | None:
    if not PG_DSN: return None
    conn = await asyncpg.connect(PG_DSN)
    try:
        row = await conn.fetchrow("DELETE FROM ai_jobs WHERE id=(SELECT id FROM ai_jobs WHERE status='ready' ORDER BY created_at LIMIT 1) RETURNING payload")
        return dict(row["payload"]) if row else None
    finally:
        await conn.close()
