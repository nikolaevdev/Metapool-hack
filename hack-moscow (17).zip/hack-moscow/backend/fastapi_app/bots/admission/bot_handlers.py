#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Хэндлеры «абитуриентского» бота.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
import uuid
from datetime import datetime, timezone

from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import CommandStart
from aiogram.types import FSInputFile
from redis.asyncio import Redis

from tg_admission_bot.config import Settings
from tg_admission_bot.redis_queue import RedisQueue
from tg_admission_bot.search_adapter import get_top_attachments
from tg_admission_bot.LMStudio_gpt_sdk_async import rewrite_answer

log = logging.getLogger(__name__)

# ══════════════════════════════════  Константы  ══════════════════════════════════
STATE_BOT                  = "BOT"
STATE_AWAIT_OPERATOR_QUERY = "AWAIT_OPERATOR_QUERY"
STATE_HUMAN_PENDING        = "HUMAN_PENDING"
STATE_HUMAN_ACTIVE         = "HUMAN_ACTIVE"

OPERATOR_TRIGGERS = {
    "оператор", "operator", "human", "человек", "живой",
    "support", "поддержка", "help",
}

LLM_STOP_PHRASES = {
    "пустая строка", "нет информации", "не могу ответить",
    "sorry", "извините", "нет данных", "не относится к представленному контексту", "не относится", "контексту", "контексту", "контексте"
}

# Redis-ключи
R_CHAT2JOB      = "dlg:chat2job"        # chat_id → job_id
R_LAST_ACTIVITY = "dlg:last_activity"   # job_id → ts

# ══════════════════════════════════  Globals (инициализируются в register)  ═════
_settings: Settings
_llm_queue: RedisQueue
_operator_queue: RedisQueue
_dialog_queue: RedisQueue
_rds: Redis

# ══════════════════════════════════  Вспомогательные  ════════════════════════════
def _want_operator(text: str) -> bool:
    low = text.lower()
    return any(k in low for k in OPERATOR_TRIGGERS)


async def _state_set(chat_id: int, state: str) -> None:
    await _rds.setex(f"session:{chat_id}", 6 * 3600, state)


async def _state_get(chat_id: int) -> str | None:
    return await _rds.get(f"session:{chat_id}")


async def _state_clear(chat_id: int) -> None:
    await _rds.delete(f"session:{chat_id}")


async def _push_to_dialog(chat_id: int, text: str) -> None:
    job_id = await _rds.hget(R_CHAT2JOB, chat_id)
    if not job_id:
        return
    ts = int(time.time())
    await _dialog_queue.push({
        "job_id": job_id,
        "chat_id": chat_id,
        "text": text,
        "ts": ts,
    })
    await _rds.hset(R_LAST_ACTIVITY, job_id, ts)

# ══════════════════════════════════  LLM-воркер  ═════════════════════════════════
async def process_question(bot: Bot, job: dict) -> None:
    """Отвечает LLM или передаёт запрос оператору."""
    chat_id: int = job["chat_id"]
    question: str = job["question"]
    wait_msg_id: int | None = job.get("wait_msg_id")

    if await _state_get(chat_id) in (STATE_HUMAN_PENDING, STATE_HUMAN_ACTIVE):
        return                                      # уже у оператора

    try:
        # 1️⃣ поиск
        atts = await get_top_attachments(question, _settings)
        if not atts:
            raise LookupError

        # 2️⃣ контекст
        ctx  = "\n".join(f"ID {a.id}: {a.description or a.keywords or ''}" for a in atts)
        body = "\n\n".join((a.content or a.description or "")[:500] for a in atts)

        # 3️⃣ LLM
        reply = (await asyncio.to_thread(rewrite_answer, ctx, question, body)).strip()
        if not reply or any(s in reply.lower() for s in LLM_STOP_PHRASES):
            raise LookupError

        # 4️⃣ успех
        if wait_msg_id:
            with contextlib.suppress(Exception):
                await bot.delete_message(chat_id, wait_msg_id)
        await bot.send_message(chat_id, reply)

        # 5️⃣ вложения
        for a in atts:
            f = getattr(a, "file", None)
            if not f:
                continue
            payload = f.url if getattr(f, "url", "").startswith("http") else FSInputFile(f.path, filename=f.name)
            cap = (a.description or "")[:1024] or None
            try:
                if (a.mime_type or "").startswith("image/"):
                    await bot.send_photo(chat_id, payload, caption=cap)
                else:
                    await bot.send_document(chat_id, payload, caption=cap)
            except Exception:
                log.exception("cant send attachment %s", a.id)

    except LookupError:
        await _state_set(chat_id, STATE_HUMAN_PENDING)
        await _operator_queue.push_operator_request(chat_id, question)
        if wait_msg_id:
            with contextlib.suppress(Exception):
                await bot.delete_message(chat_id, wait_msg_id)
        await bot.send_message(chat_id, "Ваш вопрос передан оператору. Пожалуйста, ожидайте ответа…")

    except Exception:
        log.exception("process_question")
        await bot.send_message(chat_id, "Произошла ошибка. Попробуйте позднее.")

# ══════════════════════════════════  Регистрация хэндлеров  ══════════════════════
def register_handlers(dp: Dispatcher, settings: Settings) -> None:
    global _settings, _llm_queue, _operator_queue, _dialog_queue, _rds
    _settings       = settings
    _llm_queue      = RedisQueue(settings.REDIS_URL, settings.REDIS_QUEUE_NAME)
    _operator_queue = RedisQueue(settings.REDIS_URL, "operator_queue")
    _dialog_queue   = RedisQueue(settings.REDIS_URL, "dialog_queue")
    _rds            = Redis.from_url(settings.REDIS_URL, decode_responses=True)

    # /start
    @dp.message(CommandStart())
    async def _start(m: types.Message):
        await m.answer(
            "Здравствуйте!"
            "Спросите меня или напишите «оператор», чтобы поговорить с человеком."
        )
        await _state_clear(m.chat.id)

    # явный /operator
    @dp.message(F.text.casefold() == "/operator")
    async def _operator_cmd(m: types.Message):
        await _state_set(m.chat.id, STATE_AWAIT_OPERATOR_QUERY)
        await m.answer("Хорошо, подключаю оператора.\nНапишите, пожалуйста, сам вопрос одним сообщением.")

    # все текстовые
    @dp.message(F.text)
    async def _on_text(m: types.Message, bot: Bot):
        chat_id = m.chat.id
        txt = (m.text or "").strip()
        st  = await _state_get(chat_id)

        # ждём формулировку
        if st == STATE_AWAIT_OPERATOR_QUERY:
            if _want_operator(txt) or len(txt) < 4:
                return await m.answer("Пожалуйста, сформулируйте сам вопрос одним сообщением.")
            await _state_set(chat_id, STATE_HUMAN_PENDING)
            await _operator_queue.push_operator_request(chat_id, txt)
            await _rds.hset(R_LAST_ACTIVITY, uuid.uuid4().hex, int(time.time()))
            return await m.answer("Ваш вопрос передан оператору. Ожидайте ответа…")

        # уже активен диалог
        if st in (STATE_HUMAN_PENDING, STATE_HUMAN_ACTIVE):
            await _push_to_dialog(chat_id, txt)
            return await m.answer("Ваше сообщение добавлено к текущему обращению.")

        # запрос оператора
        if _want_operator(txt):
            await _state_set(chat_id, STATE_AWAIT_OPERATOR_QUERY)
            return await m.answer("Подключаю оператора. Напишите, пожалуйста, вопрос одним сообщением.")

        # слишком длинно
        if len(txt) > 500:
            return await m.answer("Сообщение слишком длинное, сократите, пожалуйста.")

        # обычный вопрос
        j_id = uuid.uuid4().hex
        wait = await m.answer("Ваш вопрос принят. Подождите…")
        await _llm_queue.push({
            "job_id": j_id,
            "chat_id": chat_id,
            "user_id": m.from_user.id,
            "question": txt,
            "wait_msg_id": wait.message_id,
        })
