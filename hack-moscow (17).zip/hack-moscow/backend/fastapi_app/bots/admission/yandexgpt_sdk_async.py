"""
Синхронная обёртка над официальным yandex_cloud_ml_sdk
для работы с моделью *yandexgpt-lite (rc)*.
"""

from __future__ import annotations

import logging
import os
from typing import List, Dict

from yandex_cloud_ml_sdk import YCloudML
from yandex_cloud_ml_sdk.exceptions import YCloudMLError
from pydantic import SecretStr
from tg_admission_bot.config import Settings

logger = logging.getLogger(__name__)

# ---------- параметры из окружения (.env) ----------
settings = Settings()

FOLDER_ID = settings.YC_FOLDER_ID
API_KEY = settings.YC_API_KEY

# По умолчанию – yandexgpt-lite, но можно переопределить через переменную окружения
MODEL_NAME = settings.YC_MODEL or "yandexgpt-lite"
MODEL_VERSION = "rc"  # фиксируем версию RC

MAX_TOKENS = settings.YC_MAX_TOKENS
TEMPERATURE = float(settings.YC_TEMPERATURE)
# ---------------------------------------------------

def _build_sdk() -> YCloudML:
    """
    Создаёт экземпляр клиента SDK, гарантируя,
    что folder_id и auth передаются как строки.
    """
    folder_id = settings.YC_FOLDER_ID
    api_key = settings.YC_API_KEY

    # Если поля заданы как SecretStr, извлекаем секрет:
    if isinstance(folder_id, SecretStr):
        folder_id = folder_id.get_secret_value()
    if isinstance(api_key, SecretStr):
        api_key = api_key.get_secret_value()

    if not (folder_id and api_key):
        raise RuntimeError("YC_FOLDER_ID и/или YC_API_KEY не заданы")

    return YCloudML(folder_id=str(folder_id), auth=str(api_key))


_SDK: YCloudML | None = None


def _sdk() -> YCloudML:
    global _SDK
    if _SDK is None:
        _SDK = _build_sdk()
    return _SDK


_PROMPT_HEADER = (
    "Вы — высокоэффективная LLM, задачи которой:\n"
    "1. Получить на вход исходный текст ответа.\n"
    "2. Переформулировать его *максимально лаконично*, сохраняя факты.\n"
    "3. Не добавлять новых фактов или мнений.\n"
    "4. Вернуть только переформулированный текст."
)


def _build_messages(context: str, question: str, raw_answer: str) -> List[Dict[str, str]]:
    """
    Формирует payload для Yandex GPT-lite.
    """
    user_block = (
        f"Контекст:\n«{context}»\n\n"
        f"Вопрос абитуриента:\n«{question}»\n\n"
        f"Переформулируй ответ:\n«{raw_answer}»"
    )
    return [
        {"role": "system", "text": _PROMPT_HEADER},
        {"role": "user", "text": user_block},
    ]

def _alt_text(alt) -> str:
    """Извлекает текст из объекта Alternative."""
    # В SDK класс Alternative имеет поле .text; защищаемся на всякий случай
    return alt.text.strip() if hasattr(alt, "text") else str(alt).strip()

def rewrite_answer(context: str, question: str, raw_answer: str) -> str:
    """
    Синхронно возвращает «сглаженный» ответ,
    используя модель yandexgpt-lite (версия rc).

    Пример:
        refined = rewrite_answer(ctx, q, ans)
    """
    msgs = _build_messages(context, question, raw_answer)

    try:
        result = (
            _sdk()
            .models.completions(MODEL_NAME).configure(
                temperature=TEMPERATURE,
                max_tokens=MAX_TOKENS
            ).run(msgs)
        )
    except (YCloudMLError, TimeoutError):
        logger.exception("Ошибка при вызове Yandex GPT")
        raise

    # --- исправленный возврат ---
    return _alt_text(result[0]) if result else ""