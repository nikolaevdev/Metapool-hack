
from typing import Optional
from aiogram import Bot

PUBLIC_BOT: Optional[Bot] = None
OPERATOR_BOT: Optional[Bot] = None

def set_public_bot(bot: Bot) -> None:
    global PUBLIC_BOT
    PUBLIC_BOT = bot

def set_operator_bot(bot: Bot) -> None:
    global OPERATOR_BOT
    OPERATOR_BOT = bot
