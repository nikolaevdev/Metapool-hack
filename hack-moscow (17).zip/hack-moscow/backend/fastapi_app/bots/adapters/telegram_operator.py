# fastapi_app/bots/adapters/telegram_operator.py
from __future__ import annotations

import os
import logging
from enum import Enum
from typing import Optional, Tuple

import redis.asyncio as redis
from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import CommandStart, Command
from aiogram.filters.command import CommandObject
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

from fastapi_app.bots.context import PUBLIC_BOT  # для отправки сообщений пользователю

log = logging.getLogger(__name__)

# ───────────────────────── Redis настройки и ключи ─────────────────────────

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# Пользовательский диалог <-> работа
R_CHAT2JOB = "dlg:chat2job"   # chat_id -> job_id   (читает public-бот)
R_JOB2CHAT = "op:job2chat"    # job_id  -> chat_id  (используем для ответа пользователю)

# Сессии оператора
R_SESSIONS = "op:sessions"    # job_id  -> operator_id (читает public-бот при релеях)
R_OP2JOB  = "op:op2job"       # operator_id -> job_id  (нужно, чтобы понимать, какой job сейчас у оператора)
R_ON_SHIFT = "op:on_shift"    # set(operator_id)      (кто «на смене»)
R_PENDING = "op:pending"      # список/очередь job_id, ожидающих взятия (для /pending)

# ───────────────────────── Типы действий оператора ─────────────────────────

class OpAction(str, Enum):
    TAKE = "take"      # взять диалог
    DROP = "drop"      # отвязаться (вернуть в ожидание)
    END  = "end"       # завершить диалог

# ───────────────────────── Вспомогательные функции ─────────────────────────

def _cb_data(action: OpAction, job_id: str, chat_id: int) -> str:
    # Формат callback_data: "op:{action}:{job_id}:{chat_id}"
    return f"op:{action}:{job_id}:{chat_id}"

def kb_job(job_id: str, chat_id: int) -> InlineKeyboardMarkup:
    """Клавиатура к карточке заявки для оператора."""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Взять", callback_data=_cb_data(OpAction.TAKE, job_id, chat_id)),
                InlineKeyboardButton(text="Сбросить", callback_data=_cb_data(OpAction.DROP, job_id, chat_id)),
                InlineKeyboardButton(text="Завершить", callback_data=_cb_data(OpAction.END,  job_id, chat_id)),
            ]
        ]
    )

async def _set_session(r: redis.Redis, operator_id: int, job_id: str, chat_id: int) -> None:
    await r.hset(R_SESSIONS, job_id, operator_id)
    await r.hset(R_OP2JOB, operator_id, job_id)
    await r.hset(R_JOB2CHAT, job_id, chat_id)
    await r.hset(R_CHAT2JOB, chat_id, job_id)

async def _clear_session(r: redis.Redis, operator_id: int, job_id: Optional[str] = None) -> None:
    """Снимает привязку оператора; если job_id не указан — возьмём из R_OP2JOB."""
    if job_id is None:
        job_id = await r.hget(R_OP2JOB, operator_id)
    if job_id:
        chat_id = await r.hget(R_JOB2CHAT, job_id)
        await r.hdel(R_SESSIONS, job_id)
        await r.hdel(R_JOB2CHAT, job_id)
        if chat_id:
            await r.hdel(R_CHAT2JOB, chat_id)
    await r.hdel(R_OP2JOB, operator_id)

async def _current_job_of(r: redis.Redis, operator_id: int) -> Optional[str]:
    return await r.hget(R_OP2JOB, operator_id)

async def _job_chat(r: redis.Redis, job_id: str) -> Optional[int]:
    val = await r.hget(R_JOB2CHAT, job_id)
    return int(val) if val is not None else None

def _parse_cb(data: str) -> Optional[Tuple[OpAction, str, int]]:
    # data = "op:{action}:{job_id}:{chat_id}"
    try:
        prefix, action, job_id, chat_id = data.split(":", 3)
        if prefix != "op":
            return None
        return OpAction(action), job_id, int(chat_id)
    except Exception:
        return None

# ───────────────────────── Handlers ─────────────────────────

router = Router(name="operator")

@router.message(CommandStart())
async def on_start(m: Message):
    await m.answer(
        "Здравствуйте! Вы подключены как оператор.\n\n"
        "Команды:\n"
        "• /shift_on — выйти на смену\n"
        "• /shift_off — уйти со смены\n"
        "• /pending — показать ожидающие заявки\n"
        "• /take <job_id> — взять заявку\n"
        "• /drop — отвязаться от текущей заявки\n"
        "• /end — завершить текущую заявку\n"
        "• /help — помощь"
    )

@router.message(Command("help"))
async def on_help(m: Message):
    await on_start(m)

@router.message(Command("shift_on"))
async def shift_on(m: Message):
    r = redis.from_url(REDIS_URL, decode_responses=True)
    await r.sadd(R_ON_SHIFT, m.from_user.id)
    await m.answer("Вы отмечены как «на смене». Новые заявки будут приходить.")

@router.message(Command("shift_off"))
async def shift_off(m: Message):
    r = redis.from_url(REDIS_URL, decode_responses=True)
    await r.srem(R_ON_SHIFT, m.from_user.id)
    # при уходе со смены — снимаем активную сессию, если была
    job_id = await _current_job_of(r, m.from_user.id)
    if job_id:
        await _clear_session(r, m.from_user.id, job_id)
    await m.answer("Вы сняты со смены. Активные привязки очищены.")

@router.message(Command("pending"))
async def list_pending(m: Message):
    r = redis.from_url(REDIS_URL, decode_responses=True)
    # первые 10
    try:
        jobs = await r.lrange(R_PENDING, 0, 9)
    except Exception:
        jobs = []
    if not jobs:
        await m.answer("Ожидающих заявок нет.")
        return
    msg = "Ожидающие заявки (job_id):\n" + "\n".join(f"• {j}" for j in jobs)
    await m.answer(msg)

@router.message(Command("take"))
async def take_by_command(m: Message, command: CommandObject):
    args = (command.args or "").strip().split()
    if not args:
        await m.answer("Укажите идентификатор заявки: /take <job_id>")
        return
    job_id = args[0]
    r = redis.from_url(REDIS_URL, decode_responses=True)
    chat_id = await _job_chat(r, job_id)
    if chat_id is None:
        await m.answer("Для этой заявки не найден chat_id. Проверьте корректность job_id.")
        return
    await _set_session(r, m.from_user.id, job_id, chat_id)
    await m.answer(f"Вы взяли заявку {job_id}. Пишите сообщение — оно уйдёт пользователю.")
    if PUBLIC_BOT:
        try:
            await PUBLIC_BOT.send_message(
                chat_id,
                "Оператор подключился к Вашему диалогу. Продолжайте, пожалуйста.",
            )
        except Exception as e:
            log.warning("Не удалось уведомить пользователя: %s", e)

@router.message(Command("drop"))
async def drop_current(m: Message):
    r = redis.from_url(REDIS_URL, decode_responses=True)
    job_id = await _current_job_of(r, m.from_user.id)
    if not job_id:
        await m.answer("У Вас нет активной заявки.")
        return
    await _clear_session(r, m.from_user.id, job_id)
    await m.answer(f"Вы отвязались от заявки {job_id}.")
    # По желанию: вернуть job_id в R_PENDING (если используется список)
    try:
        await r.lpush(R_PENDING, job_id)
    except Exception:
        pass

@router.message(Command("end"))
async def end_current(m: Message):
    r = redis.from_url(REDIS_URL, decode_responses=True)
    job_id = await _current_job_of(r, m.from_user.id)
    if not job_id:
        await m.answer("У Вас нет активной заявки.")
        return
    chat_id = await _job_chat(r, job_id)
    await _clear_session(r, m.from_user.id, job_id)
    await m.answer(f"Заявка {job_id} завершена.")
    if PUBLIC_BOT and chat_id:
        try:
            await PUBLIC_BOT.send_message(
                chat_id,
                "Диалог с оператором завершён. Спасибо! "
                "Вы можете оценить разговор — эта статистика помогает нам улучшаться.",
            )
        except Exception as e:
            log.warning("Не удалось уведомить пользователя об окончании: %s", e)

@router.callback_query(F.data.startswith("op:"))
async def on_action(cb: CallbackQuery):
    parsed = _parse_cb(cb.data or "")
    if not parsed:
        await cb.answer("Некорректные данные.", show_alert=True)
        return
    action, job_id, chat_id = parsed
    op_id = cb.from_user.id
    r = redis.from_url(REDIS_URL, decode_responses=True)

    if action == OpAction.TAKE:
        await _set_session(r, op_id, job_id, chat_id)
        await cb.message.edit_text(
            f"Вы взяли заявку {job_id}. Пишите сообщение — оно уйдёт пользователю.",
            reply_markup=kb_job(job_id, chat_id),
        )
        if PUBLIC_BOT:
            try:
                await PUBLIC_BOT.send_message(
                    chat_id, "Оператор подключился к Вашему диалогу. Продолжайте, пожалуйста."
                )
            except Exception as e:
                log.warning("Не удалось уведомить пользователя: %s", e)
        await cb.answer("Заявка взята.")

    elif action == OpAction.DROP:
        await _clear_session(r, op_id, job_id)
        # по желанию — вернуть в pending
        try:
            await r.lpush(R_PENDING, job_id)
        except Exception:
            pass
        await cb.message.edit_text(
            f"Вы отвязались от заявки {job_id}.",
            reply_markup=None,
        )
        await cb.answer("Заявка возвращена в очередь.")

    elif action == OpAction.END:
        await _clear_session(r, op_id, job_id)
        await cb.message.edit_text(f"Заявка {job_id} завершена.", reply_markup=None)
        if PUBLIC_BOT and chat_id:
            try:
                await PUBLIC_BOT.send_message(
                    chat_id,
                    "Диалог с оператором завершён. Спасибо! "
                    "Вы можете оценить разговор — эта статистика помогает нам улучшаться.",
                )
            except Exception as e:
                log.warning("Не удалось уведомить пользователя об окончании: %s", e)
        await cb.answer("Заявка завершена.")

    else:
        await cb.answer("Неизвестное действие.", show_alert=True)

@router.message(F.text & (F.chat.type == "private"))
async def relay_to_user(m: Message):
    """
    Любое текстовое сообщение оператора в личке — уходит текущему пользователю.
    """
    r = redis.from_url(REDIS_URL, decode_responses=True)
    job_id = await _current_job_of(r, m.from_user.id)
    if not job_id:
        await m.answer("Нет активной заявки. Используйте /pending или /take <job_id>.")
        return
    chat_id = await _job_chat(r, job_id)
    if not chat_id:
        await m.answer("Не найден chat_id пользователя для текущей заявки.")
        return
    if PUBLIC_BOT is None:
        await m.answer("Публичный бот недоступен. Сообщение не отправлено.")
        return
    try:
        await PUBLIC_BOT.send_message(chat_id, f"Оператор: {m.text}")
        await m.answer("Отправлено пользователю.")
    except Exception as e:
        log.exception("Ошибка отправки пользователю: %s", e)
        await m.answer("Не удалось отправить сообщение пользователю.")

# ───────────────────────── Builder ─────────────────────────

def build_operator_dispatcher(_: Bot) -> Dispatcher:
    """
    Конструктор Dispatcher для операторского бота.
    Подпись совместима с вызовом из runner.py: builder(bot) -> Dispatcher
    """
    dp = Dispatcher()
    dp.include_router(router)
    return dp
