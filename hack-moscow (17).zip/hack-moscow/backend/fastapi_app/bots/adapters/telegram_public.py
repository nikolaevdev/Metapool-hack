
import logging
from aiogram import Dispatcher, F, Router, Bot
from fastapi_app.bots.admission.redis_queue import RedisQueue
from fastapi_app.bots.admission.config import Settings as BotSettings
from fastapi_app.bots.services.durable_queue import push_pg
from aiogram.types import Message
from aiogram.filters import CommandStart, Command

log = logging.getLogger(__name__)

router = Router()

@router.message(CommandStart())
async def on_start(m: Message):
    await m.answer("Здравствуйте! Я приёмный бот. Задайте вопрос.")

@router.message(Command("ping"))
async def on_ping(m: Message):
    await m.answer("pong")

@router.message(F.text.len() > 0)
async def on_text(m: Message):
    text = (m.text or "").strip()
    if not text:
        return
    settings = BotSettings()
    q = RedisQueue(settings.REDIS_URL, settings.REDIS_QUEUE_NAME)
    try:
        await q.push({"chat_id": m.chat.id, "text": text})
    except Exception:
        # Redis недоступен — пишем в PG durable queue
        await push_pg({"chat_id": m.chat.id, "text": text})
    await m.answer("Спасибо! Думаю над ответом…")

def build_public_dispatcher(bot: Bot) -> Dispatcher:
    dp = Dispatcher()
    dp.include_router(router)
    return dp


# Релей с пользователем в активной сессии
import redis.asyncio as redis
from fastapi_app.bots.context import OPERATOR_BOT
R_CHAT2JOB = "dlg:chat2job"
R_SESSIONS = "op:sessions"
R_JOB2CHAT = "op:job2chat"

@router.message(F.text, F.chat.type == "private")
async def relay_if_session(m: Message):
    # если есть активная сессия с оператором — пересылаем ему, иначе — обычная очередь LLM
    r = redis.from_url("redis://localhost:6379/0", decode_responses=True)
    job = await r.hget(R_CHAT2JOB, str(m.chat.id))
    if job:
        op_id = await r.hget(R_SESSIONS, job)
        if op_id and OPERATOR_BOT:
            await OPERATOR_BOT.send_message(int(op_id), f"Сообщение от пользователя: {m.text}")
            return
