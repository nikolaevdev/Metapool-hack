from pydantic import BaseModel
from fastapi_app.schemas.common import Meta
from fastapi_app.schemas.dto import (
    UserOut, PagedUsersOut,
    PoolOut, PagedPoolsOut,
    CategoryOut, PagedCategoriesOut,
    AttachmentOut, PagedAttachmentsOut,
)

class SRUsersList(BaseModel):
    status: str = "ok"
    data: PagedUsersOut
    meta: Meta

class SRUsersDetail(BaseModel):
    status: str = "ok"
    data: UserOut
    meta: Meta

class SRPoolsList(BaseModel):
    status: str = "ok"
    data: PagedPoolsOut
    meta: Meta

class SRPoolsDetail(BaseModel):
    status: str = "ok"
    data: PoolOut
    meta: Meta

class SRCategoriesList(BaseModel):
    status: str = "ok"
    data: PagedCategoriesOut
    meta: Meta

class SRCategoriesDetail(BaseModel):
    status: str = "ok"
    data: CategoryOut
    meta: Meta

class SRAttachmentsList(BaseModel):
    status: str = "ok"
    data: PagedAttachmentsOut
    meta: Meta

class SRAttachmentsDetail(BaseModel):
    status: str = "ok"
    data: AttachmentOut
    meta: Meta
