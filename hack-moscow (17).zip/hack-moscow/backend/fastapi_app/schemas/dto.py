from typing import Optional, List, Dict
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field, model_validator

# --- Core DTOs ---

class PermissionOut(BaseModel):
    codename: str = Field(..., description="Код разрешения")
    name: str = Field(..., description="Название разрешения")

class RoleOut(BaseModel):
    id: int
    name: str
    permissions: List[PermissionOut] = []

class UserOut(BaseModel):
    id: int
    email: str
    username: str
    first_name: str | None = None
    last_name: str | None = None
    is_active: bool
    is_staff: bool
    # расширяйте при необходимости

class RegistrationCodeOut(BaseModel):
    id: int
    code: str
    is_active: bool

class CategoryOut(BaseModel):
    id: int
    title: str
    description: str | None = None

class PoolOut(BaseModel):
    id: int
    # в базе поле называется name, наружу отдаём как "title"
    name: str = Field(..., serialization_alias="title")
    description: str | None = None
    keywords: str | None = None
    year: int
    revision: int
    created_at: datetime
    updated_at: datetime

    # чтобы .model_validate(..., from_attributes=True) работал по атрибутам ORM
    model_config = ConfigDict(from_attributes=True)

class AttachmentOut(BaseModel):
    id: int
    pool_id: int
    title: str
    content: str | None = None
    file_url: str | None = None

class OperatorOut(BaseModel):
    id: int
    user_id: int
    telegram_id: str | None = None
    is_active: bool

# --- Auth DTOs ---

class TokenOut(BaseModel):
    access: str
    refresh: str | None = None
    token_type: str = "bearer"
    mfa: bool | None = None
    require_2fa: bool | None = None

# --- Search DTOs ---

class SearchHitOut(BaseModel):
    id: str
    score: float
    payload: dict

class SearchResponseOut(BaseModel):
    collection: str
    results: List[SearchHitOut]

# --- Pagination wrappers (если потребуется явная типизация данных) ---

class PageMetaOut(BaseModel):
    total: int
    page: int
    size: int

class PagedUsersOut(BaseModel):
    items: List[UserOut]
    meta: PageMetaOut

class PagedPoolsOut(BaseModel):
    items: List[PoolOut]
    meta: PageMetaOut

class PagedCategoriesOut(BaseModel):
    items: List[CategoryOut]
    meta: PageMetaOut

class PagedAttachmentsOut(BaseModel):
    items: List[AttachmentOut]
    meta: PageMetaOut
