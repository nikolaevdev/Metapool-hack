from typing import Any, Optional, Dict
from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field, model_validator

class Meta(BaseModel):
    message: str = Field(default="ok", description="Human-readable message")

class StandardResponse(BaseModel):
    status: str = Field(default="ok", description="'ok' or 'error'")
    data: Any = Field(default=None, description="Payload")
    meta: Meta = Field(default_factory=Meta)

class ErrorResponse(BaseModel):
    status: str = "error"
    error: str
    meta: Optional[Meta] = None

# POOL
class PoolBase(BaseModel):
    name: str
    description: Optional[str] = None
    keywords: Optional[str] = None
    year: int
    revision: int = 1

class PoolCreate(PoolBase):
    pass

class PoolUpdate(PoolBase):
    pass

class PoolOut(PoolBase):
    id: int
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    @model_validator(mode='before')
    def normalize_input(cls, data):
        # Если прилетает Django-модель
        if hasattr(data, "id"):
            def get_attr(obj, *names):
                for n in names:
                    if hasattr(obj, n):
                        return getattr(obj, n)
                return None
            return {
                "id": data.id,
                "name": get_attr(data, "name"),
                "description": get_attr(data, "description"),
                "keywords": get_attr(data, "keywords"),
                "year": get_attr(data, "year"),
                "revision": get_attr(data, "revision") or 1,
                "created_at": get_attr(data, "created_at", "created"),
                "updated_at": get_attr(data, "updated_at", "updated"),
            }
        return data

# CATEGORY
class CategoryBase(BaseModel):
    path: str
    title: str
    description: Optional[str] = None
    keywords: Optional[str] = None
    properties: Dict = Field(default_factory=dict)

class CategoryOut(CategoryBase):
    id: int
    pool_id: int

    model_config = ConfigDict(from_attributes=True)

    @model_validator(mode='before')
    def normalize_input(cls, data):
        # Обработка Django-модели
        if hasattr(data, 'path') and hasattr(data, 'id') and hasattr(data, 'pool_id'):
            p = data.path
            if isinstance(p, (list, tuple)):
                p = '.'.join(p)
            return {
                'id': data.id,
                'pool_id': data.pool_id,
                'path': p,
                'title': data.title,
                'description': data.description,
                'keywords': data.keywords,
                'properties': data.properties,
            }
        # Обработка словаря с path в виде списка
        if isinstance(data, dict) and 'path' in data and isinstance(data['path'], (list, tuple)):
            data['path'] = '.'.join(data['path'])
        return data

# ATTACHMENT
class AttachmentCreate(BaseModel):
    category_id: int
    description: Optional[str] = None
    keywords: Optional[str] = None
    content: Optional[str] = None  # Текстовое содержимое вложения

    @model_validator(mode='after')
    def ensure_content_present(cls, values):
        if values.content is None:
            raise ValueError('Необходимо указать текстовое содержимое "content" для текстовой вложки')
        return values

class AttachmentUpdate(BaseModel):
    description: Optional[str] = None
    keywords: Optional[str] = None
    content: Optional[str] = None

class AttachmentOut(BaseModel):
    id: int
    pool_id: int
    category_id: int
    description: str
    keywords: str
    mime_type: str
    content: Optional[str] = None
    file_url: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class SearchRequest(BaseModel):
    query: str
    pool_id: Optional[int] = None
