from __future__ import annotations
from typing import Optional
from django.conf import settings
from django.contrib.auth import get_user_model
from rest_framework_simplejwt.backends import TokenBackend
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from users.models import User, AuditLog
from django.core.exceptions import ObjectDoesNotExist
from asgiref.sync import sync_to_async

security = HTTPBearer(auto_error=False)

def _decode_access(token: str) -> dict | None:
    tb = TokenBackend(algorithm=settings.SIMPLE_JWT['ALGORITHM'], signing_key=settings.SIMPLE_JWT['SIGNING_KEY'])
    try:
        return tb.decode(token, verify=True)
    except Exception:
        return None

User = get_user_model()

async def get_current_user(
        creds: Optional[HTTPAuthorizationCredentials] = Depends(security)
):
    if not creds or creds.scheme.lower() != "bearer":
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Требуется авторизация")

    payload = _decode_access(creds.credentials)
    if not payload:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Невалидный токен")

    uid = payload.get("user_id") or payload.get("sub")
    if not uid:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Некорректный токен")

    try:
        # ВАЖНО: оборачиваем Django ORM в sync_to_async
        user = await sync_to_async(User.objects.get)(pk=uid)
        return user
    except ObjectDoesNotExist:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Пользователь не найден")

def require_permission(codename: str):
    """
    Dependency для проверки прав через встроенную систему permissions.
    """
    def checker(user: User = Depends(get_current_user)) -> User:
        if not user.has_perm(codename):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail='Not enough permissions'
            )
        return user
    return checker

