from contextlib import asynccontextmanager
import os
import asyncio
from fastapi import FastAPI

# Импорт роутеров (как у Вас)
from fastapi_app.routers import (
    categories as categories_module,
    search as search_module,
    users as users_module,
    attachments as attachments_module,
    imports as imports_module,
    roles as roles_module,
    audit as audit_module,
    permissions as permissions_module,
    registration_codes as registration_codes_module,
    indexing as indexing_module,
    sse as sse_module,
    search_adv as search_adv_module,
    operators as operators_module,
    auth as auth_module,
    pools as pools_module,
    profile as profile_module,
    totp as totp_module,
    analytics,
    analytics_ui,
)
from fastapi_app.routers import health

# ── Bots lifecycle ─────────────────────────────────────────────
from fastapi_app.bots.worker.runner import start_bots, stop_bots

@asynccontextmanager
async def lifespan(app: FastAPI):
    run_bots = os.getenv("RUN_BOTS", "1") not in {"0", "false", "False"}
    if run_bots:
        await start_bots()   # неблокирующий запуск (таски создаются внутри)
    try:
        yield
    finally:
        if run_bots:
            await stop_bots()  # мягкая остановка

app = FastAPI(title="FastAPI side", docs_url="/docs", redoc_url="/redoc", lifespan=lifespan)

# === Подключение роутеров ===
app.include_router(auth_module.router, prefix="/auth", tags=["auth"])
app.include_router(users_module.router, prefix="/users", tags=["users"])
app.include_router(roles_module.router, prefix="/roles", tags=["roles"])
app.include_router(permissions_module.router, prefix="/permissions", tags=["permissions"])
app.include_router(audit_module.router, prefix="/audit", tags=["audit"])
app.include_router(registration_codes_module.router, prefix="/registration-codes", tags=["registration-codes"])
app.include_router(profile_module.router, prefix="/profile", tags=["profile"])
app.include_router(pools_module.router, prefix="/pools", tags=["pools"])
app.include_router(categories_module.router, prefix="/categories", tags=["categories"])
app.include_router(attachments_module.router, prefix="/attachments", tags=["attachments"])
app.include_router(search_module.router, prefix="/pools_search", tags=["search"])
app.include_router(search_adv_module.router, prefix="/advanced_search", tags=["advanced-search"])
app.include_router(operators_module.router, prefix="/operators", tags=["operators"])
app.include_router(imports_module.router, prefix="/imports", tags=["imports"])
app.include_router(indexing_module.router, prefix="/indexing", tags=["indexing"])
app.include_router(sse_module.router, prefix="/sse", tags=["sse"])
app.include_router(totp_module.router, prefix="/totp", tags=["totp"])
app.include_router(analytics.router, prefix="/analytics", tags=["Analytics"])
app.include_router(analytics_ui.router, prefix="/analytics", tags=["Analytics UI"])
app.include_router(health.router, prefix="/health", tags=["health"])

# Неблокирующий health для k8s/compose
@app.get("/health", tags=["health"])
def health_root():
    return {"status": "ok"}
