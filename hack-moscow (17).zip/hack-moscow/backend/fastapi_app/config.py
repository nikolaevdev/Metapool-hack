# fastapi_app/config.py
import os
try:
    from django.conf import settings as dj
except Exception:
    dj = None

def DJ(name: str, default=None):
    """
    Сначала читаем из Django settings.py (если Django уже сконфигурирован),
    иначе — из переменных окружения. ВНИМАНИЕ: тут НЕЛЬЗЯ вызывать DJ() повторно.
    """
    if dj is not None and getattr(dj, "configured", False) and hasattr(dj, name):
        return getattr(dj, name)
    # важно: прямой доступ к os.environ, чтобы не было рекурсии
    return os.environ.get(name, default)

"""
Application configuration file.

This file defines environment-based settings without relying on `python-decouple`.
You can configure these values via environment variables.
"""

import os
from datetime import timedelta

# === JWT ===
SECRET_KEY = DJ("JWT_SECRET_KEY", "change-this-in-production")
ALGORITHM = DJ("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(DJ("ACCESS_TOKEN_EXPIRE_MINUTES", 15))
REFRESH_TOKEN_EXPIRE_DAYS = int(DJ("REFRESH_TOKEN_EXPIRE_DAYS", 7))

# === Redis ===
REDIS_URL = DJ("REDIS_URL", "redis://localhost:6379/0")

# === CORS ===
FRONTEND_URL = DJ("FRONTEND_URL", "http://localhost:5173")

# === Rate Limiting ===
RATE_LIMIT = int(DJ("RATE_LIMIT", 60))

# === OTP / MFA ===
OTP_ISSUER_NAME = DJ("OTP_ISSUER_NAME", "MetaPool")


# === Telegram bots ===
TELEGRAM_PUBLIC_BOT_TOKEN = DJ("TELEGRAM_PUBLIC_BOT_TOKEN", "")
TELEGRAM_OPERATOR_BOT_TOKEN = DJ("TELEGRAM_OPERATOR_BOT_TOKEN", "")
TELEGRAM_USE_WEBHOOK = DJ("TELEGRAM_USE_WEBHOOK", "false").lower() == "true"
TELEGRAM_WEBHOOK_BASE = DJ("TELEGRAM_WEBHOOK_BASE", "")  # https://your.domain
