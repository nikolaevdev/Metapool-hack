from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response, JSONResponse
import json

class EnvelopeMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)

        ctype = response.headers.get("content-type","")
        if "application/json" not in ctype and "text/plain" not in ctype:
            return response

        try:
            body = b""
            async for chunk in response.body_iterator:
                body += chunk
            response.body_iterator = iter([body])

            if "application/json" in ctype:
                payload = json.loads(body.decode() or "null")
            else:
                payload = {"detail": body.decode()}
        except Exception:
            return response

        if isinstance(payload, dict) and "status" in payload and ("data" in payload or "error" in payload):
            return response

        status = response.status_code
        if status >= 400:
            msg = payload.get("detail") if isinstance(payload, dict) else "error"
            wrapped = {"status":"error","error": msg, "meta":{"message": msg}}
            return JSONResponse(wrapped, status_code=status)

        wrapped = {"status":"ok","data": payload, "meta":{"message":"ok"}}
        return JSONResponse(wrapped, status_code=status)
