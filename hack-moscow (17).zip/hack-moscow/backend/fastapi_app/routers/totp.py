from __future__ import annotations
import io, base64
import qrcode
from asgiref.sync import sync_to_async
from django.conf import settings
from django_otp.plugins.otp_totp.models import TOTPDevice
from fastapi import APIRouter
from fastapi_app.dependencies import get_current_user

router = APIRouter()

def ok(data=None, meta=None): return {'status':'ok','data':data,'meta': meta or {}}
def err(error, meta=None): return {'status':'error','error':str(error),'data':None,'meta': meta or {}}

def _make_provisioning_uri(user, device: TOTPDevice) -> str:
    issuer = getattr(settings, 'PROJECT_NAME', 'BackendApp')
    label = f"{issuer}:{user.username or user.email}"
    return device.config_url.replace('otpauth://totp/', f'otpauth://totp/{label}?issuer={issuer}&')

def _qr_png(text: str) -> str:
    img = qrcode.make(text)
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode('ascii')

@router.post('/enroll')
async def enroll(current_user = get_current_user):
    def _create():
        d = TOTPDevice.objects.create(user=current_user, name='Authenticator', confirmed=False)
        uri = _make_provisioning_uri(current_user, d)
        return {'device_id': d.pk, 'secret': d.key.decode() if isinstance(d.key, bytes) else d.key, 'otpauth_url': uri, 'qr_png': _qr_png(uri)}
    data = await sync_to_async(_create)()
    return ok(data, meta={'message':'created'})

@router.post('/confirm')
async def confirm(code: str, current_user = get_current_user):
    def _confirm():
        d = TOTPDevice.objects.filter(user=current_user, confirmed=False).order_by('-id').first()
        if not d: return None, 'no_pending'
        if d.verify_token(code):
            d.confirmed = True; d.save(update_fields=['confirmed'])
            return {'device_id': d.pk, 'confirmed': True}, None
        return None, 'invalid'
    data, errcode = await sync_to_async(_confirm)()
    if errcode == 'no_pending': return err('no_pending_device')
    if errcode == 'invalid': return err('invalid_otp')
    return ok(data, meta={'message':'confirmed'})

@router.get('/devices')
async def devices(current_user = get_current_user):
    def _list():
        return [{'id': d.pk, 'name': d.name, 'confirmed': d.confirmed}
                for d in TOTPDevice.objects.filter(user=current_user).order_by('id')]
    items = await sync_to_async(_list)()
    return ok(items, meta={'total': len(items)})

@router.delete('/devices/{device_id}')
async def remove(device_id: int, current_user = get_current_user):
    def _del():
        return TOTPDevice.objects.filter(user=current_user, pk=device_id).delete()[0]
    deleted = await sync_to_async(_del)()
    return ok({'deleted': bool(deleted)}, meta={'count': deleted})
