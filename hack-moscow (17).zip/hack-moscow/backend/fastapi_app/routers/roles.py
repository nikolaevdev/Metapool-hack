# fastapi_app/routers/roles.py
from typing import List, Optional

from asgiref.sync import sync_to_async
from fastapi import APIRouter, Depends, HTTPException
from fastapi_app.schemas.dto import *
from fastapi_app.schemas.common import StandardResponse
from pydantic import BaseModel, ConfigDict

from users.models import Role, Permission, AuditLog, User
from fastapi_app.dependencies import require_permission
from fastapi_app.routers.permissions import PermOut

router = APIRouter()


class RoleOut(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    permissions: List[PermOut] = []

    model_config = ConfigDict(from_attributes=True)


class RoleCreate(BaseModel):
    name: str
    description: Optional[str] = None
    permissions: List[int] = []


class RoleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    permissions: Optional[List[int]] = None


@router.get("/", response_model=List[RoleOut])
async def list_roles(
        current_user: User = Depends(require_permission("users.view_role"))
):
    """
    Список всех ролей с их правами.
    """
    roles_qs = await sync_to_async(list)(
        Role.objects.prefetch_related("permissions").all()
    )
    result: List[RoleOut] = []
    for role in roles_qs:
        perms = await sync_to_async(list)(role.permissions.all())
        result.append(
            RoleOut(
                id=role.id,
                name=role.name,
                description=role.description,
                permissions=perms,
            )
        )
    return result


@router.get("/{role_id}", response_model=RoleOut)
async def get_role(
        role_id: int,
        current_user: User = Depends(require_permission("users.view_role"))
):
    """
    Детальная информация по одной роли.
    """
    role = await sync_to_async(
        Role.objects.prefetch_related("permissions")
        .filter(id=role_id)
        .first
    )()
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")

    perms = await sync_to_async(list)(role.permissions.all())
    return RoleOut(
        id=role.id,
        name=role.name,
        description=role.description,
        permissions=perms,
    )


@router.post("/", response_model=RoleOut)
async def create_role(
        data: RoleCreate,
        current_user: User = Depends(require_permission("users.add_role"))
):
    """
    Создать роль с правами и залогировать, кто создал.
    """
    role = await sync_to_async(Role.objects.create)(
        name=data.name,
        description=data.description
    )
    if data.permissions:
        perms_qs = await sync_to_async(list)(
            Permission.objects.filter(id__in=data.permissions)
        )
        await sync_to_async(role.permissions.set)(perms_qs)

    await sync_to_async(AuditLog.objects.create)(
        user=current_user,
        action=f"Created role {role.name}"
    )

    # Перезагрузим роль, чтобы получить её с актуальными связями
    role = await sync_to_async(
        Role.objects.prefetch_related("permissions").get
    )(id=role.id)
    perms = await sync_to_async(list)(role.permissions.all())
    return RoleOut(
        id=role.id,
        name=role.name,
        description=role.description,
        permissions=perms,
    )


@router.put("/{role_id}", response_model=RoleOut)
async def update_role(
        role_id: int,
        data: RoleUpdate,
        current_user: User = Depends(require_permission("users.change_role"))
):
    """
    Обновить поля роли и/или её права, залогировать, кто это сделал.
    """
    role = await sync_to_async(
        Role.objects.prefetch_related("permissions")
        .filter(id=role_id)
        .first
    )()
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")

    updated = False
    if data.name is not None:
        role.name = data.name
        updated = True
    if data.description is not None:
        role.description = data.description
        updated = True
    if updated:
        await sync_to_async(role.save)()
        await sync_to_async(AuditLog.objects.create)(
            user=current_user,
            action=f"Updated role {role.name}"
        )

    if data.permissions is not None:
        perms_qs = await sync_to_async(list)(
            Permission.objects.filter(id__in=data.permissions)
        )
        await sync_to_async(role.permissions.set)(perms_qs)
        await sync_to_async(AuditLog.objects.create)(
            user=current_user,
            action=f"Updated permissions for role {role.name}"
        )

    role = await sync_to_async(
        Role.objects.prefetch_related("permissions").get
    )(id=role.id)
    perms = await sync_to_async(list)(role.permissions.all())
    return RoleOut(
        id=role.id,
        name=role.name,
        description=role.description,
        permissions=perms,
    )


@router.delete("/{role_id}", response_model=StandardResponse, summary="roles:delete ")
async def delete_role(
        role_id: int,
        current_user: User = Depends(require_permission("users.delete_role"))
):
    """
    Удалить роль и залогировать, кто это сделал.
    """
    role = await sync_to_async(Role.objects.filter(id=role_id).first)()
    if not role:
        raise HTTPException(status_code=404, detail="Role not found")

    name = role.name
    await sync_to_async(role.delete)()
    await sync_to_async(AuditLog.objects.create)(
        user=current_user,
        action=f"Deleted role {name}"
    )
    return {"msg": "Deleted"}

