from typing import List, Annotated
from datetime import date
from io import BytesIO
import base64

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi_app.schemas.dto import *
from fastapi_app.schemas.common import StandardResponse
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, ConfigDict

import qrcode
from django_otp.plugins.otp_totp.models import TOTPDevice
from django_otp.plugins.otp_static.models import StaticDevice, StaticToken

from urllib.parse import urlparse, parse_qs, urlencode, quote
from fastapi_app.config import OTP_ISSUER_NAME

from users.models import User
from fastapi_app.dependencies import get_current_user

router = APIRouter()

# Ответные модели профиля
class ProfileOut(BaseModel):
    id: int
    email: str
    username: str | None
    first_name: str | None = Field(None, alias="firstName")
    last_name: str | None = Field(None, alias="lastName")
    birth_date: date | None = Field(None, alias="birthDate")
    is_twofa_enabled: bool = Field(..., alias="isTwofaEnabled")

    model_config = ConfigDict(
        from_attributes=True,
        populate_by_name=True,
        json_encoders={
            date: lambda v: v.isoformat() if v is not None else None
        }
    )

# Входная модель для обновления профиля
class ProfileUpdateIn(BaseModel):
    username: str | None = Field(None)
    first_name: str | None = Field(None, alias="firstName")
    last_name: str | None = Field(None, alias="lastName")
    birth_date: date | None = Field(None, alias="birthDate")

    model_config = ConfigDict(
        populate_by_name=True
    )


class TwoFAInitOut(BaseModel):
    otp_auth_url: str = Field(..., alias="otpAuthUrl")
    qr_code: str      = Field(..., alias="qrCode")
    backup_codes: List[str] = Field(..., alias="backupCodes")

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class TwoFAVerifyIn(BaseModel):
    totpCode: str = Field(
        ..., min_length=6, max_length=6,
        description="6-значный TOTP-код"
    )

    model_config = ConfigDict()


class TwoFAVerifyOut(BaseModel):
    verified: bool

    model_config = ConfigDict()


class BackupVerifyIn(BaseModel):
    backupCode: str = Field(
        ..., min_length=8, max_length=8,
        description="Одноразовый резервный код"
    )

    model_config = ConfigDict()


class BackupVerifyOut(BaseModel):
    valid: bool

    model_config = ConfigDict()


# Получение профиля текущего пользователя
@router.get("/", response_model=ProfileOut, summary="Получить профиль")
def get_profile(
        current_user: Annotated[User, Depends(get_current_user)]
):
    return current_user

# Обновление данных профиля
@router.put("/", response_model=ProfileOut, summary="Обновить профиль")
def update_profile(
        data: ProfileUpdateIn,
        current_user: Annotated[User, Depends(get_current_user)]
):
    update_fields: list[str] = []
    if data.username is not None:
        current_user.username = data.username
        update_fields.append("username")
    if data.first_name is not None:
        current_user.first_name = data.first_name
        update_fields.append("first_name")
    if data.last_name is not None:
        current_user.last_name = data.last_name
        update_fields.append("last_name")
    if data.birth_date is not None:
        current_user.birth_date = data.birth_date
        update_fields.append("birth_date")
    if update_fields:
        current_user.save(update_fields=update_fields)
    return current_user


@router.get("/2fa/status", summary="Статус 2FA", response_model=StandardResponse)
def twofa_status(
        current_user: Annotated[User, Depends(get_current_user)]
):
    enabled = TOTPDevice.objects.filter(
        user=current_user, confirmed=True
    ).exists()
    # возвращаем через alias
    return {"isTwofaEnabled": enabled}


@router.post(
    "/2fa/init",
    response_model=TwoFAInitOut,
    summary="Инициализация 2FA"
)
def init_2fa(
        current_user: Annotated[User, Depends(get_current_user)]
):
    if TOTPDevice.objects.filter(user=current_user, confirmed=True).exists():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="2FA уже включена"
        )

    # Удаляем старые устройства и резервные коды
    TOTPDevice.objects.filter(user=current_user).delete()
    StaticDevice.objects.filter(user=current_user).delete()

    # Создаём новое TOTP-устройство
    totp_dev = TOTPDevice.objects.create(
        user=current_user, name="default", confirmed=False
    )

    # Собираем кастомный otpauth URI
    base_uri = totp_dev.config_url
    parsed   = urlparse(base_uri)
    params   = parse_qs(parsed.query)
    issuer   = OTP_ISSUER_NAME       # "MetaPool"
    params['issuer'] = issuer
    label    = quote(f"{issuer}:{current_user.email}")
    new_query= urlencode(params, doseq=True)
    otp_uri  = f"otpauth://totp/{label}?{new_query}"

    # Генерируем QR-код
    img = qrcode.make(otp_uri)
    buf = BytesIO(); img.save(buf, format="PNG")
    qr_b64 = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()

    # Создаём резервные коды
    static_dev   = StaticDevice.objects.create(
        user=current_user, name="backup", confirmed=True
    )
    backup_codes: List[str] = []
    for _ in range(10):
        token = StaticToken.random_token()
        static_dev.token_set.create(token=token)
        backup_codes.append(token)

    return {
        "otpAuthUrl": otp_uri,
        "qrCode"   : qr_b64,
        "backupCodes": backup_codes,
    }


@router.post(
    "/2fa/verify",
    response_model=TwoFAVerifyOut,
    summary="Верификация TOTP-кода"
)
def verify_2fa(
        data: TwoFAVerifyIn,
        current_user: Annotated[User, Depends(get_current_user)]
):
    try:
        dev = TOTPDevice.objects.get(
            user=current_user, name="default"
        )
    except TOTPDevice.DoesNotExist:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="2FA не инициализирована"
        )

    if dev.verify_token(data.totpCode):
        dev.confirmed = True
        dev.save(update_fields=["confirmed"])
        return {"verified": True}
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Неверный TOTP-код"
        )


@router.post(
    "/2fa/verify-backup",
    response_model=BackupVerifyOut,
    summary="Верификация резервного кода"
)
def verify_backup(
        data: BackupVerifyIn,
        current_user: Annotated[User, Depends(get_current_user)]
):
    try:
        static_dev = StaticDevice.objects.get(
            user=current_user, name="backup"
        )
    except StaticDevice.DoesNotExist:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Резервные коды не созданы"
        )

    valid = static_dev.verify_token(data.backupCode)
    if valid:
        return {"valid": True}
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Неверный резервный код"
        )


@router.post("/2fa/disable", summary="Отключить 2FA", response_model=StandardResponse)
def disable_2fa(
        current_user: Annotated[User, Depends(get_current_user)]
):
    TOTPDevice.objects.filter(user=current_user).delete()
    StaticDevice.objects.filter(user=current_user).delete()
    return JSONResponse({"disabled": True})
