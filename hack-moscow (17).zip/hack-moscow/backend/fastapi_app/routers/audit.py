# fastapi_app/routers/audit.py
from datetime import datetime
from typing import List, Literal

from asgiref.sync import sync_to_async
from fastapi import APIRouter, Depends, Query, Response
from pydantic import BaseModel, ConfigDict

from fastapi_app.dependencies import require_permission
from users.models import AuditLog

router = APIRouter()


class AuditOut(BaseModel):
    user_id: int | None
    action: str
    timestamp: datetime

    model_config = ConfigDict(from_attributes=True)


class AuditResponseData(BaseModel):
    items: List[AuditOut]
    total: int


class AuditResponse(BaseModel):
    status: Literal["ok"]
    data: AuditResponseData


@router.get("/", response_model=AuditResponse)
async def get_audit_logs(
        response: Response,
        skip: int = 0,
        limit: int = 100,
        user_id: int | None = Query(None, description="Фильтр по ID пользователя"),
        action: str | None = Query(None, description="Поиск по тексту действия"),
        date_from: datetime | None = Query(None, description="Дата начала (YYYY-MM-DDThh:mm:ss)"),
        date_to: datetime | None = Query(None, description="Дата конца (YYYY-MM-DDThh:mm:ss)"),
        current_user=Depends(require_permission("users.view_auditlog")),
):
    """
    Асинхронно возвращает записи аудита с фильтрацией и пагинацией.
    В теле ответа возвращается структура { status: "ok", data: { items, total } }.
    Заголовок X-Total-Count по-прежнему ставится для обратной совместимости.
    """

    def _fetch():
        qs = AuditLog.objects.all()
        if user_id is not None:
            qs = qs.filter(user_id=user_id)
        if action:
            qs = qs.filter(action__icontains=action)
        if date_from:
            qs = qs.filter(timestamp__gte=date_from)
        if date_to:
            qs = qs.filter(timestamp__lte=date_to)

        total_count = qs.count()
        items = list(qs.order_by("-timestamp")[skip : skip + limit])
        return total_count, items

    total_count, items = await sync_to_async(_fetch)()

    # Добавляем заголовок для CORS
    response.headers["X-Total-Count"] = str(total_count)
    # Убедитесь, что в настройках CORS есть:
    # Access-Control-Expose-Headers: X-Total-Count

    return {
        "status": "ok",
        "data": {
            "items": items,
            "total": total_count,
        }
    }

