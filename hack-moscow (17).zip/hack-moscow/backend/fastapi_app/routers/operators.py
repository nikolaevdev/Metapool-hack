# fastapi_app/routers/operators.py
from typing import List

from asgiref.sync import sync_to_async
from fastapi import APIRouter, Depends, HTTPException
from fastapi_app.schemas.dto import *
from fastapi_app.schemas.common import StandardResponse
from pydantic import BaseModel, ConfigDict, PositiveInt

from users.models import User, Operator, OperatorIdentity
from fastapi_app.dependencies import require_permission

router = APIRouter()


class OperatorIn(BaseModel):
    user_id: PositiveInt
    telegram_id: PositiveInt


class OperatorOut(BaseModel):
    id: int
    user_id: int
    telegram_id: int
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


@router.get("/", response_model=List[OperatorOut])
async def list_operators(
        current_user: User = Depends(require_permission("users.manage_operator"))
):
    qs = await sync_to_async(list)(Operator.objects.all())
    return qs


@router.post("/", response_model=OperatorOut, status_code=201)
async def add_operator(
        data: OperatorIn,
        current_user: User = Depends(require_permission("users.manage_operator"))
):
    if await sync_to_async(Operator.objects.filter(telegram_id=data.telegram_id).exists)():
        raise HTTPException(409, "Telegram-ID уже добавлен")

    user = await sync_to_async(User.objects.filter(id=data.user_id).first)()
    if not user:
        raise HTTPException(404, "User not found")

    op = await sync_to_async(Operator.objects.create)(
        user=user,
        telegram_id=data.telegram_id,
        is_active=True,
    )
    return op


@router.delete("/{operator_id}", status_code=200, response_model=StandardResponse, summary="operators:delete")
async def delete_operator(
        operator_id: int,
        current_user: User = Depends(require_permission("users.manage_operator"))
):
    op = await sync_to_async(Operator.objects.filter(id=operator_id).first)()
    if not op:
        raise HTTPException(status_code=404, detail="Operator not found")

    await sync_to_async(op.delete)()
    return StandardResponse(success=True, message="Operator deleted successfully")



class OperatorIdentityIn(BaseModel):
    provider: str
    external_id: str
    is_active: bool = True

@router.get("/identities", summary="operators:identities:list", response_model=StandardResponse)
async def list_identities(current_user: User = Depends(require_permission("users.manage_operator"))):
    items = await sync_to_async(list)(OperatorIdentity.objects.select_related("operator", "operator__user").all())
    data = [{
        "id": oi.id,
        "provider": oi.provider,
        "external_id": oi.external_id,
        "is_active": oi.is_active,
        "user_id": oi.operator.user.id,
        "email": oi.operator.user.email,
    } for oi in items]
    return StandardResponse(success=True, data=data)

@router.post("/{user_id}/identities", summary="operators:identities:create", response_model=StandardResponse)
async def add_identity(user_id: int, payload: OperatorIdentityIn,
                       current_user: User = Depends(require_permission("users.manage_operator"))):
    op = await sync_to_async(Operator.objects.filter(user_id=user_id).first)()
    if not op:
        raise HTTPException(status_code=404, detail="Operator not found")
    oi = OperatorIdentity(operator=op, provider=payload.provider, external_id=str(payload.external_id), is_active=payload.is_active)
    await sync_to_async(oi.save)()
    return StandardResponse(success=True, message="Identity added", data={"id": oi.id})

@router.delete("/identities/{identity_id}", summary="operators:identities:delete", response_model=StandardResponse)
async def delete_identity(identity_id: int, current_user: User = Depends(require_permission("users.manage_operator"))):
    oi = await sync_to_async(OperatorIdentity.objects.filter(id=identity_id).first)()
    if not oi:
        raise HTTPException(status_code=404, detail="Identity not found")
    await sync_to_async(oi.delete)()
    return StandardResponse(success=True, message="Identity deleted")
