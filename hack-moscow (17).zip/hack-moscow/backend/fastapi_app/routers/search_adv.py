import os, math
from typing import List, Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException
from fastapi_app.dependencies import require_permission
from qdrant_client import QdrantClient
from qdrant_client.http import models as qm
from sentence_transformers import CrossEncoder
from fastapi_app.schemas.common import StandardResponse
from datalake.search import search_pools

router = APIRouter()

QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")

class PoolSearchRequest(BaseModel):
    query: str = Field(..., min_length=2, description="Поисковый запрос")
    top_k: int = Field(10, ge=1, le=50, description="Количество пулов в выдаче")
    vector_limit: int = Field(60, ge=10, le=200, description="Сколько векторных чанков брать из Qdrant")
    score_threshold: float = Field(0.18, ge=0, le=1, description="Порог похожести по вектору (COSINE)")
    category_id: Optional[int] = Field(None, description="Фильтрация по категории")
    rerank: bool = Field(True, description="Включить кросс-энкодер для rerank")
    rerank_limit: int = Field(40, ge=5, le=200, description="Сколько кандидатов подавать в reranker")

class PoolSearchHit(BaseModel):
    pool_id: int
    title: Optional[str] = None
    reason: List[str] = []
    score: float

class PoolSearchResponse(BaseModel):
    total: int
    items: List[PoolSearchHit]

def qdrant() -> QdrantClient:
    return QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY)

def reciprocal_rank_fusion(runs: List[List[tuple[int,float]]], k: int = 60, C: float = 60.0):
    # runs: list of [(pool_id, score), ...]
    from collections import defaultdict
    ranks = defaultdict(float)
    for run in runs:
        for rank,(pid,_) in enumerate(run[:k], start=1):
            ranks[pid] += 1.0 / (C + rank)
    return sorted(ranks.items(), key=lambda x: x[1], reverse=True)

@router.post("/pool", response_model=StandardResponse, summary="Гибридный поиск по пулам (BM25+Vector, опц. rerank)")
def search_pool(payload: PoolSearchRequest, _=Depends(require_permission("pools.read"))):
    # 1) BM25/pg-run
    pg_candidates = search_pools(payload.query, category_id=payload.category_id, limit=payload.vector_limit)
    pg_run = [(row["id"], row.get("score", 1.0)) for row in pg_candidates]

    # 2) Vector-run (Qdrant, collection 'pool_chunks')
    from apps.search.embeddings import embed_texts
    lang = detect_lang(payload.query)
    vec = embed_texts([payload.query], lang=lang)[0]
    flt = None
    if payload.category_id:
        flt = qm.Filter(should=[qm.FieldCondition(key="category_id", match=qm.MatchValue(value=payload.category_id))])
    qres = qdrant().search(collection_name="pool_chunks", query_vector=vec, limit=payload.vector_limit, with_payload=True, score_threshold=payload.score_threshold, query_filter=flt)
    vec_run = []
    evidence = {}  # pool_id -> list of reasons
    for r in qres:
        pid = int(r.payload.get("pool_id"))
        vec_run.append((pid, float(r.score)))
        # reason
        t = r.payload.get("type","chunk")
        title = r.payload.get("title","")
        evidence.setdefault(pid, [])
        if len(evidence[pid])<3:
            evidence[pid].append(f"{t}: {title}" if title else t)

    # 3) Fuse (RRF)
    fused = reciprocal_rank_fusion([pg_run, vec_run], k=payload.vector_limit)

    # 4) Optional rerank with cross-encoder over short summaries
    ranked = fused
    if payload.rerank and fused:
        model = CrossEncoder(os.getenv("CROSS_ENCODER_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2"))
        # Prepare pairwise inputs: (query, text) -> score
        # We use top N candidates; text: concatenation of top evidences or pool title/prompt
        from datalake.models import Pool
        ids = [pid for pid,_ in fused[:payload.rerank_limit]]
        pools = {p.id:p for p in Pool.objects.filter(id__in=ids)}
        pairs, id_order = [], []
        for pid in ids:
            p = pools.get(pid)
            if not p:
                continue
            snippet = (p.title or "") + " " + (p.prompt or "")
            if pid in evidence:
                snippet = (p.title or "") + " " + " ".join(evidence[pid])
            pairs.append((payload.query, snippet[:512]))
            id_order.append(pid)
        scores = model.predict(pairs).tolist()
        ranked = sorted(zip(id_order, scores), key=lambda x: x[1], reverse=True)

    # 5) Build response
    items = []
    seen = set()
    for pid,score in ranked:
        if pid in seen:
            continue
        seen.add(pid)
        items.append(dict(pool_id=pid, title=None, reason=evidence.get(pid, []), score=float(score)))
        if len(items) >= payload.top_k:
            break

    return {"status":"ok","data":{"total": len(items), "items": items},"meta":{"message":"ok"}}


class PoolInnerSearchRequest(BaseModel):
    query: str = Field(..., min_length=2)
    top_k: int = Field(10, ge=1, le=50)
    vector_limit: int = Field(60, ge=10, le=200)
    score_threshold: float = Field(0.18, ge=0, le=1)
    rerank: bool = Field(False)
    rerank_limit: int = Field(20, ge=5, le=200)

@router.post("/pool/{pool_id}", response_model=StandardResponse, summary="Поиск внутри конкретного пула (по чанкам/вложениям)")
def search_inside_pool(pool_id: int, payload: PoolInnerSearchRequest, _=Depends(require_permission("pools.read"))):
    lang = detect_lang(payload.query)
    vec = embed_texts([payload.query], lang=lang)[0]
    flt = qm.Filter(must=[qm.FieldCondition(key="pool_id", match=qm.MatchValue(value=int(pool_id)))])
    try:
        res = qdrant().search(collection_name="pool_chunks", query_vector=vec, limit=payload.vector_limit, with_payload=True, score_threshold=payload.score_threshold, query_filter=flt)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Search error: {e}")
    items = []
    for r in res[:payload.top_k]:
        items.append({"id": r.id, "score": float(r.score), "payload": r.payload})
    return {"status":"ok","data":{"collection":"pool_chunks","results": items},"meta":{"message":"ok"}}
