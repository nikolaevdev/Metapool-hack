# fastapi_app/routers/pools.py

from __future__ import annotations
import os
import io
import json
import shutil
import tempfile
from typing import List, Optional, Tuple
from pathlib import PurePath
from zipfile import ZipFile, ZIP_DEFLATED, BadZipFile

from asgiref.sync import sync_to_async
from django.db import transaction
from django.contrib.postgres.search import SearchVector
from django.db.models import Value

from fastapi import (
    APIRouter,
    Depends,
    Form,
    HTTPException,
    UploadFile,
    status,
)
from fastapi.encoders import jsonable_encoder
from starlette.responses import StreamingResponse
from typing import Optional

from fastapi_app.dependencies import require_permission
from django.utils.text import slugify
from users.models import AuditLog
from datalake.models import Attachment, Category, Pool
from starlette.concurrency import run_in_threadpool
from fastapi_app.schemas.common import (
    PoolCreate,
    PoolOut,
    PoolUpdate,
    CategoryOut,
    AttachmentOut as AttachmentOutCommon,  # ← фиксируем «правильный» класс
    StandardResponse,
)
# from fastapi_app.schemas.typed_envelopes import SRPoolsList  # если вдруг понадобится где-то ещё

router = APIRouter()

# Параметры безопасности при распаковке ZIP
MAX_FILES = 1000
MAX_TOTAL_UNCOMPRESSED = 100 * 1024 * 1024  # 100 MB
MAX_COMPRESSION_RATIO = 10
MAX_FILENAME_LENGTH = 255
MAX_PATH_DEPTH = 20

# Ограничение длины исходного текста для tsvector (в символах)
# Уменьшили до 50 000, чтобы гарантированно не превышать максимум в БД
MAX_TSV_SOURCE_LEN = 50_000

def _is_safe_member(name: str) -> bool:
    """
    Проверка пути внутри архива:
      - не абсолютный
      - нет сегментов ".."
      - длина имени и глубина пути в пределах
    """
    p = PurePath(name)
    if p.is_absolute() or ".." in p.parts:
        return False
    if len(name) > MAX_FILENAME_LENGTH:
        return False
    if len(p.parts) > MAX_PATH_DEPTH:
        return False
    return True

# ---------- CRUD POOLS (без изменений) ----------

@router.get("/", response_model=List[PoolOut])
async def list_pools(current_user=Depends(require_permission("datalake.view_pool"))):
    qs = await sync_to_async(list)(Pool.objects.all().order_by("-id"))
    return [PoolOut.model_validate(p, from_attributes=True) for p in qs]

@router.post("/", response_model=PoolOut, status_code=status.HTTP_201_CREATED)
async def create_pool(payload: PoolCreate, current_user=Depends(require_permission("datalake.add_pool"))):
    obj = await sync_to_async(Pool.objects.create)(**payload.model_dump())
    # гарантируем, что поля, задаваемые БД, подхвачены
    await sync_to_async(obj.refresh_from_db)()
    return PoolOut.model_validate(obj)

@router.get("/{pool_id}", response_model=PoolOut)
async def get_pool(
        pool_id: int,
        current_user=Depends(require_permission("datalake.view_pool")),
):
    obj = await sync_to_async(Pool.objects.filter(id=pool_id).first)()
    if not obj:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Pool not found")
    return PoolOut.model_validate(obj, from_attributes=True)

@router.put("/{pool_id}", response_model=PoolOut)
async def update_pool(
        pool_id: int,
        payload: PoolUpdate,
        current_user=Depends(require_permission("datalake.change_pool")),
):
    obj = await sync_to_async(Pool.objects.filter(id=pool_id).first)()
    if not obj:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Pool not found")
    for field, val in payload.model_dump().items():
        setattr(obj, field, val)
    await sync_to_async(obj.save)()
    return PoolOut.model_validate(obj, from_attributes=True)

@router.delete("/{pool_id}", response_model=StandardResponse, summary="pools:delete")
async def delete_pool(pool_id: int, current_user=Depends(require_permission("delete_pool"))):
    p = await sync_to_async(Pool.objects.filter(id=pool_id).first)()
    if not p:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Pool not found")
    pid = p.id
    await sync_to_async(p.delete)()
    await sync_to_async(AuditLog.objects.create)(
        user=current_user,
        action=f"Deleted pool {pid}"
    )
    return {
        "status": "ok",
        "data": {"id": pid},
        "meta": {"message": "Deleted"}
    }


# ---------- EXPORT POOL AS ZIP (без изменений) ----------

@router.get(
        "/{pool_id}/export",
        summary="Export pool as ZIP",
    response_class=StreamingResponse,
)
async def export_pool_zip(
        pool_id: int,
        current_user=Depends(require_permission("datalake.export_pool")),
):
    pool = await sync_to_async(Pool.objects.filter(id=pool_id).first)()
    if not pool:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Pool not found")

    cats = await sync_to_async(list)(Category.objects.filter(pool=pool))
    atts = await sync_to_async(list)(Attachment.objects.filter(pool=pool))

    config = {
        "pool": PoolOut.model_validate(pool, from_attributes=True).model_dump(),
        "categories": [CategoryOut.model_validate(c, from_attributes=True).model_dump() for c in cats],
        "attachments": [{
            **AttachmentOutCommon.model_validate(a, from_attributes=True).model_dump(),
            "content": a.content or "",
        } for a in atts],
    }

    config_enc = jsonable_encoder(config)

    # безопасное чтение FileField (открыть/закрыть в другом потоке)
    def _read_fieldfile(ff) -> bytes:
        ff.open("rb")
        try:
            return ff.read()
        finally:
            ff.close()

    buf = io.BytesIO()
    with ZipFile(buf, "w", ZIP_DEFLATED) as zipf:
        zipf.writestr(
            "config.json",
            json.dumps(config_enc, ensure_ascii=False, indent=2),
        )
        for a in atts:
            if a.file:
                data = await sync_to_async(_read_fieldfile)(a.file)
                arcname = f"files/{os.path.basename(a.file.name)}"
                zipf.writestr(arcname, data)

    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=pool_{pool.id}.zip"},
    )

# ---------- IMPORT POOL FROM ZIP (исправленный) ----------

def _import_pools_sync(raw: bytes, pool_id: Optional[int]) -> None:
    buf = io.BytesIO(raw)
    try:
        zipf = ZipFile(buf)
    except BadZipFile:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "Uploaded file is not a valid ZIP archive",
        )

    infolist = zipf.infolist()
    if len(infolist) > MAX_FILES:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Archive contains too many files ({len(infolist)})"
        )

    # Проверяем перекрывающиеся записи
    prev_offset = zipf.start_dir
    for z in sorted(infolist, key=lambda z: z.header_offset, reverse=True):
        if z.header_offset + z.compress_size > prev_offset:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "Archive contains overlapping entries"
            )
        prev_offset = z.header_offset

    total_uncompressed = 0
    for z in infolist:
        if not _is_safe_member(z.filename):
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"Unsafe file path in archive: {z.filename}"
            )
        if z.flag_bits & 0x1:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"Encrypted entries are not supported: {z.filename}"
            )
        ratio = z.file_size / max(z.compress_size, 1)
        if ratio > MAX_COMPRESSION_RATIO:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"Compression ratio too high for {z.filename}"
            )
        total_uncompressed += z.file_size
        if total_uncompressed > MAX_TOTAL_UNCOMPRESSED:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "Total uncompressed size exceeds limit"
            )

    with tempfile.TemporaryDirectory() as tmpdir:
        # Распаковываем все файлы
        for z in infolist:
            dest = os.path.join(tmpdir, z.filename)
            if z.is_dir():
                os.makedirs(dest, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with zipf.open(z) as src, open(dest, "wb") as dst:
                    shutil.copyfileobj(src, dst, length=64 * 1024)

        # Обязательный config.json
        config_path = os.path.join(tmpdir, "config.json")
        if not os.path.exists(config_path):
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "Archive must contain config.json"
            )
        try:
            with open(config_path, encoding="utf-8") as cfg:
                data = json.load(cfg)
        except json.JSONDecodeError:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "Invalid JSON in config.json"
            )

        # Собираем данные для последующего обновления tsvector
        tsv_updates: List[Tuple[int, str, str, str]] = []

        # Атомарная транзакция: создаём Pool, Category, Attachment
        with transaction.atomic():
            # Получаем или создаём Pool
            if pool_id is not None:
                pool = Pool.objects.filter(id=pool_id).first()
                if not pool:
                    raise HTTPException(
                        status.HTTP_404_NOT_FOUND,
                        "Pool not found"
                    )
            else:
                meta = data.get("pool", {})
                if not meta.get("name") or not meta.get("year"):
                    raise HTTPException(
                        status.HTTP_400_BAD_REQUEST,
                        "config.json must include pool.name and pool.year"
                    )
                pool = Pool.objects.create(
                    name=meta["name"],
                    description=meta.get("description", ""),
                    keywords=meta.get("keywords", ""),
                    year=meta["year"],
                    revision=meta.get("revision", 1),
                )

            # Создаём новые категории с уникальным path
            cat_map: dict[int, Category] = {}
            for cat in data.get("categories", []):
                name = cat.get("name") or cat.get("title") or ""
                raw_slug = slugify(name)
                unique_slug = raw_slug
                idx = 1
                while Category.objects.filter(pool=pool, path=unique_slug).exists():
                    unique_slug = f"{raw_slug}-{idx}"
                    idx += 1

                c = Category.objects.create(
                    pool=pool,
                    title=name,
                    path=unique_slug,
                    description=cat.get("description", ""),
                )
                cat_map[cat["id"]] = c

            # Создаём новые вложения, удаляя все NUL-символы
            for att in data.get("attachments", []):
                fname = att.get("file_name", "")
                file_path = os.path.join(tmpdir, fname) if fname else None
                if file_path and os.path.exists(file_path):
                    with open(file_path, "rb") as fb:
                        content = fb.read().decode("utf-8", errors="ignore")
                else:
                    content = att.get("content", "")

                content = content.replace("\x00", "")

                a = Attachment.objects.create(
                    pool=pool,
                    category=cat_map[att["category_id"]],
                    description=att.get("description", ""),
                    keywords=att.get("keywords", ""),
                    mime_type=att.get("mime_type", ""),
                    content=content,
                )
                tsv_updates.append((
                    a.id,
                    content,
                    att.get("description", ""),
                    att.get("keywords", ""),
                ))

        # ВНЕ транзакции: обновляем tsvector по одному, с обрезкой и защитой от ошибок
        for att_id, content, desc, keys in tsv_updates:
            # Обрезаем текст до безопасной длины
            src = content[:MAX_TSV_SOURCE_LEN]
            # Если исходный текст всё ещё слишком длинный, пропускаем
            if len(src) < len(content) and len(src) == MAX_TSV_SOURCE_LEN:
                # этот файл слишком большой для tsvector — пропускаем
                continue
            try:
                Attachment.objects.filter(id=att_id).update(
                    tsvector=(
                            SearchVector(Value(src), weight="A")
                            + SearchVector(Value(desc), weight="B")
                            + SearchVector(Value(keys), weight="C")
                    )
                )
            except Exception:
                # Не удалось обновить — пропускаем
                continue

@router.post(
    "/import",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Import pool from ZIP",
)
async def import_pools_zip(
        file: UploadFile,
        pool_id: Optional[int] = Form(None),
        current_user=Depends(require_permission("datalake.import_pool")),
):
    raw = await file.read()
    try:
        # Выполняем синхронную логику в пуле потоков
        await run_in_threadpool(_import_pools_sync, raw, pool_id)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            f"Unexpected error during import: {e}"
        )
    return {"msg": "Import completed successfully"}

