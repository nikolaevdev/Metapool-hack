
from fastapi import APIRouter, Query
from typing import Optional
import redis.asyncio as redis

from fastapi_app.analytics.core import fetch_events, summary_counts, heatmap_by_weekday_hour, predict_next_days

router = APIRouter()

def _r():
    # Используем общий REDIS_URL из admission settings
    from fastapi_app.bots.admission.config import Settings as BotSettings
    return redis.from_url(BotSettings().REDIS_URL, decode_responses=True)

@router.get("/events")
async def events(limit: int = Query(200, ge=1, le=5000)):
    r = _r()
    return await fetch_events(r, limit=limit)

@router.get("/summary")
async def summary(days: int = Query(14, ge=1, le=90)):
    r = _r()
    return await summary_counts(r, days=days)

@router.get("/heatmap")
async def heatmap(limit: int = Query(2000, ge=100, le=100000)):
    r = _r()
    return {"matrix": await heatmap_by_weekday_hour(r, limit=limit)}

@router.get("/predict")
async def predict(days_back: int = Query(14, ge=7, le=90), horizon: int = Query(7, ge=1, le=30)):
    r = _r()
    return {"forecast": await predict_next_days(r, days_back=days_back, horizon=horizon)}
