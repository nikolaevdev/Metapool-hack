# backend/fastapi_app/routers/sse.py
from __future__ import annotations
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
import os

# 1) Совместимость: сначала пытаемся использовать redis.asyncio, затем fallback на aioredis
try:
    from redis import asyncio as redis  # пакет redis>=4.2/5.x
except Exception:  # если redis.asyncio нет, пробуем старый aioredis
    import aioredis as redis  # type: ignore

router = APIRouter()

def _get_cfg() -> tuple[str, str]:
    """Читаем URL/канал из ENV, затем пытаемся взять из Django settings, иначе дефолты."""
    redis_url = os.getenv("REDIS_URL")
    channel = os.getenv("TASKS_CHANNEL")

    if not (redis_url and channel):
        try:
            from django.conf import settings as dj
        except Exception:
            dj = None  # Django ещё не инициализирован или отсутствует

        if not redis_url and dj is not None:
            # пробуем REDIS_URL, затем используем CELERY_BROKER_URL как универсальный дефолт
            redis_url = getattr(dj, "REDIS_URL", None) or getattr(dj, "CELERY_BROKER_URL", None)

        if not channel and dj is not None:
            channel = getattr(dj, "TASKS_CHANNEL", None)

    # окончательные дефолты
    redis_url = redis_url or "redis://redis:6379/0"
    channel = channel or "tasks"
    return redis_url, channel

async def event_stream():
    redis_url, channel = _get_cfg()
    r = await redis.from_url(redis_url, decode_responses=True)
    pubsub = r.pubsub()
    await pubsub.subscribe(channel)
    try:
        async for msg in pubsub.listen():
            if msg and msg.get("type") == "message":
                yield f"data: {msg['data']}\n\n"
    finally:
        try:
            await pubsub.unsubscribe(channel)
            await pubsub.close()
        finally:
            await r.close()

@router.get("/stream")
async def stream():
    # небольшие заголовки на всякий случай
    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache"}
    )

