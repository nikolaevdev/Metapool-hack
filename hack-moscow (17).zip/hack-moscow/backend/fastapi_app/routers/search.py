from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from asgiref.sync import sync_to_async

from datalake.search import search_pools
from datalake.models import Attachment
from  fastapi_app.schemas.common import AttachmentOut
from fastapi_app.dependencies import require_permission

router = APIRouter()

# ───────────────────────────────────────────────────────────────
#  входная схема для POST-запроса
# ───────────────────────────────────────────────────────────────
class SearchRequest(BaseModel):
    query: str
    pool_id: Optional[int] = None

# ───────────────────────────────────────────────────────────────
#  POST /api/pools_search/  (JSON-тело)
# ───────────────────────────────────────────────────────────────
@router.post(
    "/",
    response_model=list[AttachmentOut],
    summary="Advanced search in pools (POST)",
    status_code=status.HTTP_200_OK,
)
async def search_endpoint(
        body: SearchRequest,
        current_user=Depends(require_permission("datalake.view_attachment")),
):
    try:
        results = await sync_to_async(search_pools)(body.query, body.pool_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # конвертируем ORM-объекты в схемы
    return [
        AttachmentOut.model_validate(a).model_copy(update={
            "file_url": a.file.url if a.file else None,
            "content": a.content or None,
        })
        for a in results
    ]
