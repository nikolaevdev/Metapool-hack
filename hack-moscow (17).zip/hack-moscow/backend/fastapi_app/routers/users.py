# fastapi_app/routers/users.py
from typing import List, Optional

from asgiref.sync import sync_to_async
from fastapi_app.schemas.typed_envelopes import *
from fastapi_app.schemas.dto import *
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, EmailStr
from django_otp.plugins.otp_totp.models import TOTPDevice

from users.models import User, Role, UserRole, AuditLog
from fastapi_app.dependencies import require_permission
from fastapi_app.schemas.common import StandardResponse

router = APIRouter()


class RoleSummary(BaseModel):
    id: int
    name: str
    description: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class UserOut(BaseModel):
    id: int
    email: EmailStr
    username: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    is_active: bool
    is_blocked: bool
    is_twofa_enabled: bool
    roles: List[RoleSummary] = []

    model_config = ConfigDict(from_attributes=True)


class UserCreate(BaseModel):
    email: EmailStr
    username: str
    password: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    is_active: Optional[bool] = True
    is_blocked: Optional[bool] = False
    roles: Optional[List[int]] = []

    model_config = ConfigDict(from_attributes=True)


class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    username: Optional[str] = None
    password: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    is_active: Optional[bool] = None
    is_blocked: Optional[bool] = None
    roles: Optional[List[int]] = None
    disable_twofa: Optional[bool] = None

    model_config = ConfigDict(from_attributes=True)


@router.get("/", response_model=List[UserOut])
async def list_users(
        current_user: User = Depends(require_permission("users.view_user"))
):
    qs = await sync_to_async(list)(
        User.objects.prefetch_related("user_roles__role").all()
    )
    out: List[UserOut] = []
    for u in qs:
        # роли
        user_roles = await sync_to_async(list)(u.user_roles.all())
        roles = [ur.role for ur in user_roles]
        # двухфакторка
        is2fa = await sync_to_async(
            lambda user: TOTPDevice.objects.filter(user=user, confirmed=True).exists()
        )(u)
        out.append(UserOut(
            id=u.id,
            email=u.email,
            username=u.username,
            first_name=u.first_name,
            last_name=u.last_name,
            is_active=u.is_active,
            is_blocked=u.is_blocked,
            is_twofa_enabled=is2fa,
            roles=roles,
        ))
    return out


@router.get("/{user_id}", response_model=UserOut)
async def get_user(
        user_id: int,
        current_user: User = Depends(require_permission("users.view_user"))
):
    u = await sync_to_async(
        User.objects.prefetch_related("user_roles__role")
        .filter(id=user_id)
        .first
    )()
    if not u:
        raise HTTPException(status_code=404, detail="User not found")

    user_roles = await sync_to_async(list)(u.user_roles.all())
    roles = [ur.role for ur in user_roles]
    is2fa = await sync_to_async(
        lambda user: TOTPDevice.objects.filter(user=user, confirmed=True).exists()
    )(u)
    return UserOut(
        id=u.id,
        email=u.email,
        username=u.username,
        first_name=u.first_name,
        last_name=u.last_name,
        is_active=u.is_active,
        is_blocked=u.is_blocked,
        is_twofa_enabled=is2fa,
        roles=roles,
    )


@router.post("/", response_model=UserOut)
async def create_user(
        data: UserCreate,
        current_user: User = Depends(require_permission("users.add_user"))
):
    u = await sync_to_async(User.objects.create_user)(
        email=data.email,
        username=data.username,
        password=data.password,
        first_name=data.first_name or "",
        last_name=data.last_name or "",
    )
    u.is_active = data.is_active
    u.is_blocked = data.is_blocked
    await sync_to_async(u.save)()

    if data.roles:
        roles_qs = await sync_to_async(list)(Role.objects.filter(id__in=data.roles))
        for r in roles_qs:
            await sync_to_async(UserRole.objects.create)(user=u, role=r)

    await sync_to_async(AuditLog.objects.create)(
        user=current_user,
        action=f"Created user {u.email}"
    )

    # вернуть свежие
    u = await sync_to_async(
        User.objects.prefetch_related("user_roles__role").get
    )(id=u.id)
    user_roles = await sync_to_async(list)(u.user_roles.all())
    roles = [ur.role for ur in user_roles]
    is2fa = await sync_to_async(
        lambda user: TOTPDevice.objects.filter(user=user, confirmed=True).exists()
    )(u)
    return UserOut(
        id=u.id,
        email=u.email,
        username=u.username,
        first_name=u.first_name,
        last_name=u.last_name,
        is_active=u.is_active,
        is_blocked=u.is_blocked,
        is_twofa_enabled=is2fa,
        roles=roles,
    )


@router.put("/{user_id}", response_model=UserOut)
async def update_user(
        user_id: int,
        data: UserUpdate,
        current_user: User = Depends(require_permission("users.change_user"))
):
    u = await sync_to_async(
        User.objects.prefetch_related("user_roles__role")
        .filter(id=user_id)
        .first
    )()
    if not u:
        raise HTTPException(status_code=404, detail="User not found")

    updated = False
    for field in ("email", "username", "first_name", "last_name", "is_active", "is_blocked"):
        val = getattr(data, field)
        if val is not None:
            setattr(u, field, val)
            updated = True
    if data.password:
        u.set_password(data.password)
        updated = True
    if updated:
        await sync_to_async(u.save)()
        await sync_to_async(AuditLog.objects.create)(
            user=current_user,
            action=f"Updated user {u.email}"
        )

    if data.roles is not None:
        await sync_to_async(UserRole.objects.filter(user=u).delete)()
        if data.roles:
            roles_qs = await sync_to_async(list)(Role.objects.filter(id__in=data.roles))
            for r in roles_qs:
                await sync_to_async(UserRole.objects.create)(user=u, role=r)
        await sync_to_async(AuditLog.objects.create)(
            user=current_user,
            action=f"Updated roles for user {u.email}"
        )

    if data.disable_twofa:
        if not current_user.has_perm("users.disable_twofa"):
            raise HTTPException(status_code=403, detail="Forbidden")
        await sync_to_async(TOTPDevice.objects.filter(user=u).delete)()
        await sync_to_async(AuditLog.objects.create)(
            user=current_user,
            action=f"Disabled two-factor for user {u.email}"
        )

    # вернуть обновлённого
    u = await sync_to_async(
        User.objects.prefetch_related("user_roles__role").get
    )(id=u.id)
    user_roles = await sync_to_async(list)(u.user_roles.all())
    roles = [ur.role for ur in user_roles]
    is2fa = await sync_to_async(
        lambda user: TOTPDevice.objects.filter(user=user, confirmed=True).exists()
    )(u)
    return UserOut(
        id=u.id,
        email=u.email,
        username=u.username,
        first_name=u.first_name,
        last_name=u.last_name,
        is_active=u.is_active,
        is_blocked=u.is_blocked,
        is_twofa_enabled=is2fa,
        roles=roles,
    )


@router.delete("/{user_id}", response_model=StandardResponse, summary="users:delete ")
async def delete_user(
        user_id: int,
        current_user: User = Depends(require_permission("users.delete_user"))
):
    u = await sync_to_async(User.objects.filter(id=user_id).first)()
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    email = u.email
    await sync_to_async(u.delete)()
    await sync_to_async(AuditLog.objects.create)(
        user=current_user,
        action=f"Deleted user {email}"
    )
    return {"msg": "Deleted"}
