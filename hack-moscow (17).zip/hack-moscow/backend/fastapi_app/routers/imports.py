from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from fastapi.responses import JSONResponse
from pathlib import Path
from django.conf import settings
from datetime import datetime
import uuid, os

from fastapi_app.dependencies import require_permission
from asgiref.sync import sync_to_async
from datalake.tasks import import_pools_from_csv, import_pools_from_excel

router = APIRouter()

@router.post("/upload", dependencies=[Depends(require_permission("datalake.import"))])
async def upload_catalog(file: UploadFile = File(...)):
    ext = os.path.splitext(file.filename)[1].lower()
    media_dir = Path(settings.MEDIA_ROOT) / "uploads" / "catalog"
    media_dir.mkdir(parents=True, exist_ok=True)
    fname = f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex}{ext}"
    target = media_dir / fname
    data = await file.read()
    target.write_bytes(data)

    if ext == ".csv":
        task = import_pools_from_csv.delay(str(target))
    elif ext in [".xlsx", ".xls"]:
        task = import_pools_from_excel.delay(str(target))
    else:
        raise HTTPException(status_code=415, detail="Unsupported file type")

    return JSONResponse({"detail": "accepted", "task_id": task.id, "path": str(target)})
