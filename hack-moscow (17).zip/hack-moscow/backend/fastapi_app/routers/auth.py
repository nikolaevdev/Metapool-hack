from __future__ import annotations
from typing import Optional
from asgiref.sync import sync_to_async
from django.conf import settings
from django.contrib.auth import authenticate
from django_otp.plugins.otp_totp.models import TOTPDevice
from rest_framework_simplejwt.tokens import RefreshToken
from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel, Field
from fastapi_app.dependencies import get_current_user

router = APIRouter()

def ok(data=None, meta=None): return {'status':'ok','data':data,'meta': meta or {}}
def err(error, meta=None): return {'status':'error','error':str(error),'data':None,'meta': meta or {}}

class LoginIn(BaseModel):
    username: str = Field(..., min_length=1)
    password: str = Field(..., min_length=1)
    otp: Optional[str] = None

def _issue_tokens(user):
    rf = RefreshToken.for_user(user)
    return {'access': str(rf.access_token), 'refresh': str(rf)}

def _has_confirmed_totp(user) -> bool:
    return TOTPDevice.objects.filter(user=user, confirmed=True).exists()

def _verify_otp(user, code: str) -> bool:
    dev = TOTPDevice.objects.filter(user=user, confirmed=True).order_by('-id').first()
    return bool(dev and dev.verify_token(code))

@router.post('/login')
async def login(payload: LoginIn):
    def _auth():
        return authenticate(username=payload.username, password=payload.password)
    user = await sync_to_async(_auth)()
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, 'Неверные учетные данные')

    require_2fa = bool(getattr(settings, 'REQUIRE_2FA', True))
    has_2fa = await sync_to_async(_has_confirmed_totp)(user)

    '''
    if require_2fa:
        if not has_2fa:
            return err('otp_required', meta={'otp_required': True, 'enroll_required': True})
        if not payload.otp:
            return err('otp_required', meta={'otp_required': True})
        ok_otp = await sync_to_async(_verify_otp)(user, payload.otp)
        if not ok_otp:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, 'Неверный OTP-код')
    '''

    return ok(_issue_tokens(user), meta={'require_2fa': require_2fa})

class RefreshIn(BaseModel):
    refresh: str

@router.post('/refresh')
async def refresh(payload: RefreshIn):
    try:
        rf = RefreshToken(payload.refresh)
        access = str(rf.access_token)
        return ok({'access': access})
    except Exception:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, 'Невалидный refresh')

@router.get('/me')
async def me(current_user = Depends(get_current_user)):
    def _data():
        perms = list(current_user.get_all_permissions())
        codenames = [p.split('.',1)[1] if '.' in p else p for p in perms]
        return {
            'user': {
                'id': current_user.id,
                'username': current_user.username,
                'email': current_user.email,
                'is_active': current_user.is_active
            },
            'permissions': perms,
            'codenames': codenames
        }

    data = await sync_to_async(_data)()
    return ok(data)
