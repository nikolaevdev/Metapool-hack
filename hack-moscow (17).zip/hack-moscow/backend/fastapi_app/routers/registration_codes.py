# fastapi_app/routers/registration_codes.py
from datetime import datetime
from typing import List, Optional

import secrets
from asgiref.sync import sync_to_async
from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi_app.schemas.dto import *
from fastapi_app.schemas.common import StandardResponse
from pydantic import BaseModel, ConfigDict

from fastapi_app.dependencies import get_current_user, require_permission
from users.models import AuditLog, RegistrationCode

router = APIRouter()


class RegCodeOut(BaseModel):
    id: int
    code: str
    is_used: bool
    created_at: datetime
    expires_at: datetime

    model_config = ConfigDict(from_attributes=True)


class RegCodeCreate(BaseModel):
    count: Optional[int] = 1
    # ISO-format datetime, например "2025-06-01T00:00:00"
    expires_at: datetime


class RegCodeUpdate(BaseModel):
    expires_at: Optional[datetime] = None
    is_used: Optional[bool] = None


# ---------- CRUD ----------
@router.get("/", response_model=List[RegCodeOut])
async def list_codes(
        skip: int = 0,
        limit: int = 100,
        is_used: Optional[bool] = Query(None),
        created_after: Optional[datetime] = Query(None),
        created_before: Optional[datetime] = Query(None),
        current_user=Depends(require_permission("users.view_registrationcode")),
):
    """Список кодов с фильтрами и пагинацией."""

    def _query():
        qs = RegistrationCode.objects.all()
        if is_used is not None:
            qs = qs.filter(is_used=is_used)
        if created_after:
            qs = qs.filter(created_at__gte=created_after)
        if created_before:
            qs = qs.filter(created_at__lte=created_before)
        return list(qs.order_by("-created_at")[skip : skip + limit])

    return await sync_to_async(_query)()


@router.get("/{code_id}", response_model=RegCodeOut)
async def get_code(code_id: int, current_user=Depends(require_permission("users.view_registrationcode"))):
    """Получить один регистрационный код по ID."""

    code = await sync_to_async(RegistrationCode.objects.filter(id=code_id).first)()
    if not code:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Registration code not found")
    return code


@router.post("/", response_model=List[RegCodeOut], status_code=status.HTTP_201_CREATED)
async def create_codes(data: RegCodeCreate, current_user=Depends(require_permission("users.add_registrationcode"))):
    """Создать `count` новых кодов (по умолчанию — 1)."""

    def _create_batch() -> List[RegistrationCode]:
        created: List[RegistrationCode] = []
        for _ in range(data.count or 1):
            code_str = secrets.token_urlsafe(24)
            rc = RegistrationCode.objects.create(code=code_str, expires_at=data.expires_at)
            created.append(rc)
            AuditLog.objects.create(user=current_user, action=f"Created registration code {rc.code}")
        return created

    return await sync_to_async(_create_batch)()


@router.put("/{code_id}", response_model=RegCodeOut)
async def update_code(
        code_id: int,
        data: RegCodeUpdate,
        current_user=Depends(require_permission("users.change_registrationcode")),
):
    """Обновить срок действия и/или флаг `is_used` у кода регистрации."""

    def _update():
        rc = RegistrationCode.objects.filter(id=code_id).first()
        if not rc:
            raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Registration code not found")

        updated = False
        if data.expires_at is not None:
            rc.expires_at = data.expires_at
            updated = True
        if data.is_used is not None:
            rc.is_used = data.is_used
            updated = True
        if updated:
            rc.save()
            AuditLog.objects.create(
                user=current_user,
                action=f"Updated registration code {rc.code} (is_used={rc.is_used}, expires_at={rc.expires_at})",
            )
        return rc

    return await sync_to_async(_update)()

@router.delete(
    "/{code_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="registration_codes:delete",
    responses={204: {"description": "Registration code deleted successfully"}}
)
async def delete_code(
        code_id: int,
        current_user=Depends(require_permission("users.delete_registrationcode")),
):
    """Удаление регистрационного кода."""

    def _delete():
        rc = RegistrationCode.objects.filter(id=code_id).first()
        if not rc:
            raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Registration code not found")
        code_str = rc.code
        rc.delete()
        AuditLog.objects.create(user=current_user, action=f"Deleted registration code {code_str}")

    await sync_to_async(_delete)()

    # Ничего не возвращаем — это корректно для 204
    return Response(status_code=status.HTTP_204_NO_CONTENT)

