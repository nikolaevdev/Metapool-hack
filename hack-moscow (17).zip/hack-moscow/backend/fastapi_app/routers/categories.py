# fastapi_app/routers/categories.py
from typing import List

from asgiref.sync import sync_to_async
from fastapi import APIRouter, Depends, HTTPException, status

from fastapi_app.schemas.dto import *
from datalake.models import Pool, Category
from fastapi_app.dependencies import require_permission
from fastapi_app.schemas.common import CategoryOut, CategoryBase, StandardResponse

router = APIRouter()

@router.post(
    "/",
    response_model=CategoryOut,
    status_code=status.HTTP_201_CREATED,
    summary="categories:create",
    dependencies=[Depends(require_permission("datalake.add_category"))],
)
async def create_category(
        pool_id: int,
        data: CategoryBase,
):
    pool = await sync_to_async(Pool.objects.filter(id=pool_id).first)()
    if not pool:
        raise HTTPException(status_code=404, detail="Pool not found")

    obj = await sync_to_async(Category.objects.create)(
        pool=pool, **data.model_dump()
    )
    return CategoryOut.model_validate(obj)


@router.get(
    "/",
    response_model=List[CategoryOut],
    summary="categories:list",
    dependencies=[Depends(require_permission("datalake.view_category"))],
)
async def list_categories(pool_id: int):
    pool_exists = await sync_to_async(Pool.objects.filter(id=pool_id).exists)()
    if not pool_exists:
        raise HTTPException(status_code=404, detail="Pool not found")

    qs = await sync_to_async(list)(
        Category.objects.filter(pool_id=pool_id)
    )
    return [CategoryOut.model_validate(c) for c in qs]


@router.put(
    "/{cat_id}",
    response_model=CategoryOut,
    summary="categories:update",
    dependencies=[Depends(require_permission("datalake.change_category"))],
)
async def update_category(
        pool_id: int,
        cat_id: int,
        data: CategoryBase,
):
    # Берём категорию строго в рамках пула
    obj = await sync_to_async(
        Category.objects.filter(id=cat_id, pool_id=pool_id).first
    )()
    if not obj:
        raise HTTPException(status_code=404, detail="Category not found in this pool")

    for field, val in data.model_dump().items():
        setattr(obj, field, val)

    await sync_to_async(obj.save)()
    return CategoryOut.model_validate(obj)


@router.delete(
    "/{cat_id}",
    response_model=StandardResponse,
    summary="categories:delete",
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(require_permission("datalake.delete_category"))],
)
async def delete_category(pool_id: int, cat_id: int):
    # Удаляем только если категория принадлежит указанному пулу
    deleted, _ = await sync_to_async(
        Category.objects.filter(id=cat_id, pool_id=pool_id).delete
    )()
    if not deleted:
        raise HTTPException(status_code=404, detail="Category not found in this pool")

    # Предполагается, что StandardResponse имеет поле msg; при иной схеме — адаптируйте.
    return StandardResponse(msg="deleted")
