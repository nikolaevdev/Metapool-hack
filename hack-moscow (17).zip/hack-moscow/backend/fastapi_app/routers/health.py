
from fastapi import APIRouter
from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from fastapi_app.config import TELEGRAM_PUBLIC_BOT_TOKEN, TELEGRAM_OPERATOR_BOT_TOKEN

router = APIRouter()
@router.get("/bots")
async def bots_health():
    async def probe(token: str):
        if not token:
            return {"present": False, "getMe": None}
        try:
            bot = Bot(token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
            me = await bot.get_me()
            await bot.session.close()
            return {"present": True, "getMe": {"id": me.id, "username": me.username}}
        except Exception as e:
            return {"present": True, "getMe": f"ERROR: {e}"}
    return {
        "public": await probe(TELEGRAM_PUBLIC_BOT_TOKEN),
        "operator": await probe(TELEGRAM_OPERATOR_BOT_TOKEN),
    }
