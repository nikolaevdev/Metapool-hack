
from fastapi import APIRouter, Response

router = APIRouter()

HTML = """
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Analytics Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { font-family: system-ui, Arial, sans-serif; margin: 20px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
    canvas { background: #fff; border: 1px solid #eee; border-radius: 12px; padding: 12px; }
    h1 { margin-bottom: 16px; }
  </style>
</head>
<body>
  <h1>Аналитика обращений</h1>
  <div class="grid">
    <div>
      <h3>Тепловая карта (сутки × часы)</h3>
      <canvas id="heat"></canvas>
    </div>
    <div>
      <h3>Прогноз нагрузки (7 дней)</h3>
      <canvas id="forecast"></canvas>
    </div>
    <div>
      <h3>Дневные счётчики по категориям</h3>
      <canvas id="summary"></canvas>
    </div>
    <div>
      <h3>Воронка эскалаций</h3>
      <canvas id="funnel"></canvas>
    </div>
  </div>

<script>
async function getJSON(url){ const r = await fetch(url); return r.json(); }

async function draw(){
  // Heatmap -> упрощённый вид: столбиковая диаграмма по часам (сумма по всем дням)
  const heat = await getJSON('/analytics/heatmap');
  const M = heat.matrix;
  const hours = [...Array(24)].map((_,i)=>i);
  const byHour = hours.map(h=> M.reduce((s,row)=> s+row[h], 0));
  new Chart(document.getElementById('heat'), {
    type: 'bar',
    data: { labels: hours, datasets: [{ label: 'Запросы/час', data: byHour }] },
  });

  // Forecast
  const fc = await getJSON('/analytics/predict');
  new Chart(document.getElementById('forecast'), {
    type: 'line',
    data: { labels: fc.forecast.map(x=>x[0]), datasets: [{ label: 'Прогноз', data: fc.forecast.map(x=>x[1]) }] },
  });

  // Summary
  const sm = await getJSON('/analytics/summary');
  const days = Object.keys(sm).sort();
  const cats = new Set(); days.forEach(d=> Object.keys(sm[d]).forEach(c=>cats.add(c)));
  const datasets = [...cats].map((c,idx)=>({ label:c, data: days.map(d=> sm[d][c]||0) }));
  new Chart(document.getElementById('summary'), {
    type: 'line',
    data: { labels: days, datasets },
  });

  // Funnel (этапы): входящие -> llm_answer -> escalation_low_conf -> оператор принял -> закрыто
  const ev = await getJSON('/analytics/events?limit=2000');
  const counts = {in:0, llm:0, esc:0, taken:0, closed:0};
  ev.forEach(e=>{
    if (e.category==='llm_answer') counts.llm++;
    if (e.category==='escalation_low_conf') counts.esc++;
    if (e.category==='op_taken') counts.taken++;
    if (e.category==='op_closed') counts.closed++;
  });
  counts.in = ev.length;
  new Chart(document.getElementById('funnel'), {
    type: 'bar',
    data: { labels: ['Входящие','LLM','Эскалации','Принято','Закрыто'],
            datasets: [{ label:'Количество', data: [counts.in,counts.llm,counts.esc,counts.taken,counts.closed] }] },
  });
}
draw();
</script>
</body>
</html>
"""

@router.get("/ui")
async def ui():
    return Response(content=HTML, media_type="text/html")
