from fastapi import APIRouter, Depends, status
from fastapi.responses import JSONResponse
from typing import Optional
from pydantic import BaseModel, Field
from celery.result import AsyncResult

from fastapi_app.dependencies import require_permission
from datalake.qdrant_tasks import index_pool_attachments
from datalake.qdrant_tasks import index_all_pools, reindex_pool

router = APIRouter()

class IndexPoolPayload(BaseModel):
    pool_id: int = Field(..., ge=1, description="ID пула")
    collection: str = Field(default="attachments", description="Имя коллекции Qdrant")
    batch_size: int = Field(default=256, ge=1, le=2048)

@router.post("/index/pool", dependencies=[Depends(require_permission("datalake.index"))], summary="Индексировать вложения пула в Qdrant")
def index_pool(payload: IndexPoolPayload):
    task = index_pool_attachments.delay(pool_id=payload.pool_id, collection=payload.collection, batch_size=payload.batch_size)
    return JSONResponse({"task_id": task.id, "queued": True}, status_code=status.HTTP_202_ACCEPTED)

class TaskStatusOut(BaseModel):
    id: str
    state: str
    ready: bool
    successful: bool
    info: Optional[dict] = None

@router.get("/tasks/{task_id}", summary="Статус задачи Celery", response_model=TaskStatusOut)
def task_status(task_id: str):
    res = AsyncResult(task_id)
    info = res.info if isinstance(res.info, dict) else {"detail": str(res.info)}
    return TaskStatusOut(id=task_id, state=res.state, ready=res.ready(), successful=res.successful(), info=info)

@router.post("/index/all", dependencies=[Depends(require_permission("datalake.index"))], summary="Переиндексация всех пулов (чанкование)")
def index_all(collection: str = "pool_chunks", chunk_words: int = 180, overlap: int = 40, batch_size: int = 256):
    task = index_all_pools.delay(collection=collection, chunk_words=chunk_words, overlap=overlap, batch_size=batch_size)
    return JSONResponse({"task_id": task.id, "queued": True}, status_code=status.HTTP_202_ACCEPTED)

@router.post("/reindex/pool/{pool_id}", dependencies=[Depends(require_permission("datalake.index"))], summary="Переиндексация конкретного пула (очистка + индексирование)")
def reindex_pool_endpoint(pool_id: int, collection: str = "pool_chunks", chunk_words: int = 180, overlap: int = 40, batch_size: int = 256):
    task = reindex_pool.delay(pool_id=pool_id, collections=[collection], chunk_words=chunk_words, overlap=overlap, batch_size=batch_size)
    return JSONResponse({"task_id": task.id, "queued": True}, status_code=status.HTTP_202_ACCEPTED)
