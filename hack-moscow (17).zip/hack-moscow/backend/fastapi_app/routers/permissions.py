# fastapi_app/routers/permissions.py

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi_app.schemas.dto import *
from fastapi_app.schemas.common import StandardResponse
from pydantic import BaseModel, ConfigDict
from asgiref.sync import sync_to_async

from django.contrib.auth.models import Permission as DjangoPermission
from users.models import AuditLog, User
from fastapi_app.dependencies import require_permission

router = APIRouter()


class PermOut(BaseModel):
    id: int
    name: str
    codename: str

    model_config = ConfigDict(from_attributes=True)


class PermCreate(BaseModel):
    name: str
    codename: str


class PermUpdate(BaseModel):
    name: str | None = None
    codename: str | None = None


@router.get("/", response_model=List[PermOut])
async def list_perms(
        current_user: User = Depends(require_permission("users.view_permission"))
):
    """
    Вернуть список всех прав (id, name, codename).
    """
    perms = await sync_to_async(list)(DjangoPermission.objects.all())
    return perms


@router.post(
    "/",
    response_model=PermOut,
    status_code=status.HTTP_201_CREATED
)
async def create_perm(
        data: PermCreate,
        current_user: User = Depends(require_permission("users.add_permission"))
):
    """
    Создать новое право с указанными name и codename.
    """
    perm = await sync_to_async(DjangoPermission.objects.create)(
        name=data.name,
        codename=data.codename
    )
    # Логируем, кто и какое право создал
    await sync_to_async(AuditLog.objects.create)(
        user=current_user,
        action=f"Created permission {perm.codename}"
    )
    return perm


@router.put("/{perm_id}", response_model=PermOut)
async def update_perm(
        perm_id: int,
        data: PermUpdate,
        current_user: User = Depends(require_permission("users.change_permission"))
):
    """
    Изменить name и/или codename существующего права.
    """
    perm = await sync_to_async(DjangoPermission.objects.filter(id=perm_id).first)()
    if not perm:
        raise HTTPException(status_code=404, detail="Permission not found")

    updated = False
    if data.name is not None and data.name != perm.name:
        perm.name = data.name
        updated = True
    if data.codename is not None and data.codename != perm.codename:
        perm.codename = data.codename
        updated = True

    if updated:
        await sync_to_async(perm.save)()
        await sync_to_async(AuditLog.objects.create)(
            user=current_user,
            action=f"Updated permission {perm.codename}"
        )

    return perm


@router.delete(
    "/{perm_id}",
    status_code=status.HTTP_200_OK,   # или status.HTTP_202_ACCEPTED
    response_model=StandardResponse,
    summary="permissions:delete"
)
async def delete_perm(
        perm_id: int,
        current_user: User = Depends(require_permission("users.delete_permission"))
):
    perm = await sync_to_async(DjangoPermission.objects.filter(id=perm_id).first)()
    if not perm:
        raise HTTPException(status_code=404, detail="Permission not found")

    codename = perm.codename
    await sync_to_async(perm.delete)()
    await sync_to_async(AuditLog.objects.create)(
        user=current_user,
        action=f"Deleted permission {codename}"
    )

    return StandardResponse(detail=f"Permission '{codename}' deleted")
