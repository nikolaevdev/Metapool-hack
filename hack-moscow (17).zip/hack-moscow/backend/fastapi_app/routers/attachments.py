### attachments.py
from __future__ import annotations
import mimetypes
from typing import List

from asgiref.sync import sync_to_async
from fastapi import APIRouter
from fastapi_app.schemas.typed_envelopes import *
from fastapi_app.schemas.dto import *
from fastapi import Depends, HTTPException, UploadFile, File as FastAPIFile, Form, status
from django.conf import settings
from django.core.files.base import File as DjangoFile
from fastapi_app.dependencies import require_permission
from fastapi_app.schemas.common import AttachmentOut, AttachmentUpdate, StandardResponse
from datalake.models import Attachment, Category

router = APIRouter()

# Поддерживаем PDF, изображения и любые текстовые форматы
_IMAGE_MIME = {"image/jpeg", "image/png"}


def _guess_mime(file: UploadFile) -> str:
    return (
            mimetypes.guess_type(file.filename)[0]
            or file.content_type
            or "application/octet-stream"
    )


def _is_text_mime(mime: str) -> bool:
    return mime.startswith("text/")


def _iter_file(file: UploadFile, chunk_size: int = 1024 * 1024):
    return iter(lambda: file.file.read(chunk_size), b"")


@router.post("/", response_model=AttachmentOut, status_code=201)
async def create_attachment(
        category_id: int = Form(...),
        description: str | None = Form(None),
        keywords: str | None = Form(None),
        content: str | None = Form(None),
        file: UploadFile | None = FastAPIFile(None),
        current_user=Depends(require_permission("datalake.add_attachment")),
):
    if not content and not file:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "Нужно передать либо текст (content), либо файл."
        )

    cat = await sync_to_async(
        Category.objects.filter(id=category_id).select_related("pool").first
    )()
    if not cat:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Категория не найдена")
    pool = cat.pool

    att = Attachment(
        pool=pool,
        category=cat,
        description=description or "",
        keywords=keywords or "",
        content=content or "",
    )
    if file:
        mime = _guess_mime(file)
        # Разрешаем PDF, любые text/* и изображения
        if not (mime == "application/pdf" or _is_text_mime(mime) or mime in _IMAGE_MIME):
            raise HTTPException(
                status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
                f"MIME-тип '{mime}' не поддерживается."
            )
        att.file.save(
            file.filename,        # оригинальное имя, попадёт в upload_to
            file.file,            # file-like object
            save=False,           # потом сами вызовем att.save()
        )
        att.mime_type = mime
    else:
        # Только текстовое содержимое
        att.mime_type = "text/plain"

    await sync_to_async(att.full_clean)()
    await sync_to_async(att.save)()

    out = AttachmentOut.model_validate(att)
    out.file_url = att.file.url if att.file else None
    out.content = att.content or None
    return out


@router.get("/{category_id}", response_model=List[AttachmentOut])
async def list_attachments(
        category_id: int,
        current_user=Depends(require_permission("datalake.view_attachment")),
):
    qs = await sync_to_async(list)(
        Attachment.objects.filter(category_id=category_id)
    )
    result: List[AttachmentOut] = []
    for a in qs:
        out = AttachmentOut.model_validate(a)
        out.file_url = a.file.url if a.file else None
        out.content = a.content or None
        result.append(out)
    return result


@router.put("/{attachment_id}", response_model=AttachmentOut)
async def update_attachment(
        attachment_id: int,
        data: AttachmentUpdate,
        current_user=Depends(require_permission("datalake.change_attachment")),
):
    att = await sync_to_async(
        Attachment.objects.filter(id=attachment_id).first
    )()
    if not att:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Attachment not found")
    for field, val in data.model_dump(exclude_none=True).items():
        setattr(att, field, val)
    await sync_to_async(att.save)()
    out = AttachmentOut.model_validate(att)
    out.file_url = att.file.url if att.file else None
    out.content = getattr(att, "content", None)
    return out


@router.delete(
    "/{attachment_id}",
    status_code=status.HTTP_200_OK,
    response_model=StandardResponse,
    summary="attachments:delete",
    dependencies=[Depends(require_permission("datalake.delete_attachment"))],
)
async def delete_attachment(attachment_id: int):
    deleted, _ = await sync_to_async(
        Attachment.objects.filter(id=attachment_id).delete
    )()
    if deleted == 0:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Attachment not found")
    return StandardResponse(success=True, message="Attachment deleted")

