from datetime import datetime
from typing import Dict, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

# POOL

class PoolBase(BaseModel):
    name: str
    description: Optional[str] = None
    keywords: Optional[str] = None
    # В выходных/базовых моделях допускаем None — это защищает от старых данных
    year: Optional[int] = None
    revision: Optional[int] = 1

class PoolCreate(PoolBase):
    # На создании — строго требуем
    year: int
    revision: int = 1

# На обновлении делаем поля частичными (типично для PATCH/PUT в REST)
class PoolUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    keywords: Optional[str] = None
    year: Optional[int] = None
    revision: Optional[int] = None

class PoolOut(PoolBase):
    id: int
    created_at: datetime
    updated_at: datetime
    model_config = ConfigDict(from_attributes=True)

# CATEGORY
class CategoryBase(BaseModel):
    path: str
    title: str
    description: Optional[str] = None
    keywords: Optional[str] = None
    properties: Dict = Field(default_factory=dict)

class CategoryOut(CategoryBase):
    id: int
    pool_id: int

    model_config = ConfigDict(from_attributes=True)

    @model_validator(mode='before')
    def normalize_input(cls, data):
        # Обработка Django-модели
        if hasattr(data, 'path') and hasattr(data, 'id') and hasattr(data, 'pool_id'):
            p = data.path
            if isinstance(p, (list, tuple)):
                p = '.'.join(p)
            return {
                'id': data.id,
                'pool_id': data.pool_id,
                'path': p,
                'title': data.title,
                'description': data.description,
                'keywords': data.keywords,
                'properties': data.properties,
            }
        # Обработка словаря с path в виде списка
        if isinstance(data, dict) and 'path' in data and isinstance(data['path'], (list, tuple)):
            data['path'] = '.'.join(data['path'])
        return data

# ATTACHMENT
class AttachmentCreate(BaseModel):
    category_id: int
    description: Optional[str] = None
    keywords: Optional[str] = None
    content: Optional[str] = None  # Текстовое содержимое вложения

    @model_validator(mode='after')
    def ensure_content_present(cls, values):
        if values.content is None:
            raise ValueError('Необходимо указать текстовое содержимое "content" для текстовой вложки')
        return values

class AttachmentUpdate(BaseModel):
    description: Optional[str] = None
    keywords: Optional[str] = None
    content: Optional[str] = None

class AttachmentOut(BaseModel):
    id: int
    pool_id: int
    category_id: int
    description: Optional[str] = None
    keywords: Optional[str] = None
    mime_type: Optional[str] = None
    content: Optional[str] = None
    file_url: Optional[str] = None
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)

class SearchRequest(BaseModel):
    query: str
    pool_id: Optional[int] = None
