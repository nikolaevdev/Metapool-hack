import csv
import pandas as pd
from django.db import transaction
from celery import shared_task
from datalake.models import Pool, Category

@shared_task
def import_pools_from_csv(csv_path: str, chunk_size: int = 500):
    created = 0
    batch = []
    cats = {c.title: c for c in Category.objects.all()}
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            title = (row.get("title") or "").strip()
            prompt = (row.get("prompt") or "").strip()
            ctitle = (row.get("category_title") or "").strip()
            cat = cats.get(ctitle)
            if not cat and ctitle:
                cat = Category.objects.create(title=ctitle)
                cats[ctitle] = cat
            batch.append(Pool(title=title, prompt=prompt, category=cat))
            if len(batch) >= chunk_size:
                with transaction.atomic():
                    Pool.objects.bulk_create(batch, batch_size=chunk_size, ignore_conflicts=True)
                created += len(batch)
                batch = []
    if batch:
        with transaction.atomic():
            Pool.objects.bulk_create(batch, batch_size=chunk_size, ignore_conflicts=True)
        created += len(batch)
    return {"created": created, "source": csv_path}

@shared_task
def import_pools_from_excel(xlsx_path: str, chunk_size: int = 500):
    df = pd.read_excel(xlsx_path).fillna("")
    created = 0
    batch = []
    cats = {c.title: c for c in Category.objects.all()}
    for _, row in df.iterrows():
        title = str(row.get("title") or "").strip()
        prompt = str(row.get("prompt") or "").strip()
        ctitle = str(row.get("category_title") or "").strip()
        cat = cats.get(ctitle)
        if not cat and ctitle:
            cat = Category.objects.create(title=ctitle)
            cats[ctitle] = cat
        batch.append(Pool(title=title, prompt=prompt, category=cat))
        if len(batch) >= chunk_size:
            with transaction.atomic():
                Pool.objects.bulk_create(batch, batch_size=chunk_size, ignore_conflicts=True)
            created += len(batch)
            batch = []
    if batch:
        with transaction.atomic():
            Pool.objects.bulk_create(batch, batch_size=chunk_size, ignore_conflicts=True)
        created += len(batch)
    return {"created": created, "source": xlsx_path}
