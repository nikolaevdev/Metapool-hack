# datalake/models.py

import uuid
from pathlib import Path
from django.conf import settings
from django.contrib.postgres.indexes import GinIndex, GistIndex
from django.contrib.postgres.search import SearchVectorField
from django.db import models
from django_ltree_field.fields import LTreeField
from .storage_backends import select_storage

def attachment_upload_path(instance, filename: str) -> str:
    return f"pools/{instance.pool_id}/{instance.category_id}/{uuid.uuid4().hex}_{Path(filename).name}"

class Pool(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    keywords = models.TextField(blank=True)
    year = models.PositiveIntegerField()
    revision = models.PositiveSmallIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("name", "year", "revision")

class Category(models.Model):
    pool = models.ForeignKey(Pool, on_delete=models.CASCADE, related_name="categories")
    path = LTreeField(max_length=255)  # добавили max_length для явного контроля
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    keywords = models.TextField(blank=True)
    properties = models.JSONField(default=dict, blank=True)

    class Meta:
        unique_together = ("pool", "path")
        indexes = [
            GistIndex(fields=["path"], name="category_path_gist"),
        ]
        ordering = ["path"]

class Attachment(models.Model):
    pool = models.ForeignKey(Pool, on_delete=models.CASCADE, related_name="attachments")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="attachments")

    # Либо файл, либо текстовое содержимое
    file = models.FileField(
        upload_to=attachment_upload_path,
        storage=select_storage(),
        blank=True,
        null=True,
    )
    content = models.TextField(
        blank=True,
        help_text="Текстовое содержимое вложения, если нет файла",
    )

    description = models.CharField(max_length=255, blank=True, default="")
    keywords = models.TextField(blank=True, default="")

    # Поле для полнотекстового поиска
    tsvector = SearchVectorField(null=True, blank=True)
    embedding_id = models.UUIDField(default=uuid.uuid4, unique=True, editable=False)
    mime_type = models.CharField(max_length=128, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            GinIndex(fields=["tsvector"]),
            GinIndex(name="attachment_keywords_trgm", fields=["keywords"], opclasses=["gin_trgm_ops"]),
        ]

    def clean(self):
        # Валидируем: должно быть либо file, либо content
        if not self.file and not self.content:
            raise ValidationError("Укажите либо файл, либо текстовое содержимое.")
        super().clean()


