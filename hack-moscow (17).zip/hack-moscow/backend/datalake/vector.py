# datalake/vector.py
import logging
from functools import lru_cache
from typing import List
from uuid import UUID

import torch
from django.conf import settings
from qdrant_client import QdrantClient, models as qm
from sentence_transformers import SentenceTransformer

log = logging.getLogger(__name__)

# Берём параметры через Django settings во избежание «ломких» импортов модулем
QDRANT_HOST = settings.QDRANT_HOST
QDRANT_PORT = settings.QDRANT_PORT

# 1. Загружаем модель и делаем динамическую 8-бит квантовку
_base_model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

# берём первый модуль (Transformer) и квантуем его auto_model
transformer_module = _base_model[0]  # SentenceTransformer реализует __getitem__
quantized_auto = torch.quantization.quantize_dynamic(
    transformer_module.auto_model,
    {torch.nn.Linear},
    dtype=torch.qint8
)
transformer_module.auto_model = quantized_auto

# 2. Кеш последних 128 эмбеддингов в памяти
@lru_cache(maxsize=128)
def _cached_encode(text: str) -> List[float]:
    return _base_model.encode(text, normalize_embeddings=True).tolist()

# 3. Клиент Qdrant (self-hosted, без API-ключа)
_client = QdrantClient(host=QDRANT_HOST, port=QDRANT_PORT)
_COLLECTION = "attachments"

def _ensure_collection():
    existing = [c.name for c in _client.get_collections().collections]
    if _COLLECTION not in existing:
        log.info("Creating Qdrant collection %s", _COLLECTION)
        _client.create_collection(
            collection_name=_COLLECTION,
            vectors_config=qm.VectorParams(
                size=_base_model.get_sentence_embedding_dimension(),
                distance=qm.Distance.COSINE
            ),
        )
_ensure_collection()

def embed_text(text: str) -> List[float]:
    """Возвращает квантованный эмбеддинг для текста (с кешем)."""
    return _cached_encode(text)

def upsert_embedding(
        uid: UUID,
        vector: List[float],
        pool_id: int,
        category_id: int,
        attachment_id: int,
):
    _client.upsert(
        collection_name=_COLLECTION,
        points=[
            qm.PointStruct(
                id=str(uid),
                vector=vector,
                payload={
                    "pool_id": pool_id,
                    "category_id": category_id,
                    "attachment_id": attachment_id,
                },
            )
        ],
    )

def similarity_search(
        query: str,
        pool_id: int,
        limit: int = 5,
        score_threshold: float = 0.2,
) -> List[int]:
    """Ищем по векторному пространству Qdrant, возвращаем attachment_id."""
    vec = embed_text(query)
    flt = qm.Filter(
        must=[qm.FieldCondition(key="pool_id", match=qm.MatchValue(value=pool_id))]
    )
    hits = _client.search(
        collection_name=_COLLECTION,
        query_vector=vec,
        query_filter=flt,
        limit=limit,
    )
    return [
        hit.payload["attachment_id"]
        for hit in hits
        if hit.score is not None and hit.score >= score_threshold
    ]
