from __future__ import annotations
import json
import redis
from celery.signals import task_prerun, task_postrun, task_success, task_failure
from django.conf import settings

def _pub(event: dict):
    try:
        r = redis.from_url(settings.REDIS_URL)
        r.publish(settings.TASKS_CHANNEL, json.dumps(event, ensure_ascii=False))
    except Exception:
        pass

@task_prerun.connect
def on_prerun(task_id=None, task=None, sender=None, **kw):
    _pub({'event':'prerun','task_id': task_id, 'name': getattr(sender,'name', str(sender))})

@task_success.connect
def on_success(result=None, sender=None, **kw):
    _pub({'event':'success','task_id': kw.get('task_id'), 'name': getattr(sender,'name', str(sender)), 'result': result})

@task_failure.connect
def on_failure(exception=None, traceback=None, sender=None, **kw):
    _pub({'event':'failure','task_id': kw.get('task_id'), 'name': getattr(sender,'name', str(sender)), 'error': str(exception)})

@task_postrun.connect
def on_postrun(sender=None, **kw):
    _pub({'event':'postrun','task_id': kw.get('task_id'), 'name': getattr(sender,'name', str(sender))})
