# datalake/storage_backends.py
from functools import lru_cache
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from importlib import import_module

@lru_cache()
def select_storage():
    if settings.USE_S3:
        module_name, cls_name = "storages.backends.s3boto3.S3Boto3Storage".rsplit(".", 1)
        S3 = getattr(import_module(module_name), cls_name)
        return S3(
            bucket_name=settings.AWS_STORAGE_BUCKET_NAME,
            default_acl="private",
            file_overwrite=False,
        )
    return FileSystemStorage(location=settings.MEDIA_ROOT)

