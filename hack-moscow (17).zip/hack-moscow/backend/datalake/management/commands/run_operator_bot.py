#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Оператор-бот: режим «смены», Telethon-информация, двусторонний диалог, авто-тайм-ауты.
"""

from __future__ import annotations

import asyncio
import logging
import time
from io import BytesIO
from typing import Optional

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ContentType, ParseMode
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.filters.callback_data import CallbackData
from aiogram.types import (
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from asgiref.sync import sync_to_async
from redis.asyncio import Redis

from tg_admission_bot.config import Settings
from tg_admission_bot.redis_queue import RedisQueue
from backend.users.models import Operator

from django.core.management.base import BaseCommand

# ───────────────────────  базовая настройка  ────────────────────────
settings = Settings()
logging.basicConfig(level=logging.INFO,
                    format="[%(asctime)s] [%(levelname)8s] %(name)s – %(message)s")
log = logging.getLogger("operator_bot")

# ───────────────────────  Redis и очереди  ──────────────────────────
REDIS: Redis = Redis.from_url(settings.REDIS_URL, decode_responses=True)
QUEUE        = RedisQueue(settings.REDIS_URL, "operator_queue")
DIALOG_QUEUE = RedisQueue(settings.REDIS_URL, "dialog_queue")

UNANSWERED_TTL      = 10 * 60
DIALOG_INACTIVE_TTL = 30 * 60

R_JOB2CHAT      = "op:job2chat"
R_CHAT2JOB      = "dlg:chat2job"
R_JOB2TEXT      = "op:job2text"     # job_id → текст вопроса   ←--- NEW
R_SESSIONS      = "op:sessions"
R_CURRENT       = "op:current"
R_PENDING       = "op:pending"
R_LAST_ACTIVITY = "dlg:last_activity"
R_ON_SHIFT      = "op:on_shift"

# ───────────────────────  Telegram-боты  ────────────────────────────
op_bot  = Bot(settings.TELEGRAM_OPERATOR_TOKEN.get_secret_value(),
              default=DefaultBotProperties(parse_mode=ParseMode.HTML))
user_bot = Bot(settings.TELEGRAM_TOKEN.get_secret_value(),
               default=DefaultBotProperties(parse_mode=ParseMode.HTML))

# ───────────────────────  Router  ──────────────────────────────────
dp = Dispatcher()
router = Router()
dp.include_router(router)

# ───────────────────────  UI-клавиатуры  ───────────────────────────
SHIFT_IN  = "👷 Войти в смену"
SHIFT_OUT = "⬛ Выйти из смены"

def kb_reply(in_shift: bool) -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=SHIFT_OUT if in_shift else SHIFT_IN)]],
        resize_keyboard=True,
    )

def kb_take(job: str) -> InlineKeyboardMarkup:
    return InlineKeyboardBuilder().button(text="👋 Принять", callback_data=f"op:take:{job}").as_markup()

def kb_working(job: str) -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="↩️ Сдать",   callback_data=f"op:drop:{job}")
    kb.button(text="✅ Закрыть", callback_data=f"op:close:{job}")
    kb.adjust(2)
    return kb.as_markup()

# ───────────────────────  callback-data  ───────────────────────────
class OpAction(CallbackData, prefix="op"):
    action: str
    job_id: str

# ───────────────────────  Авторизация  ─────────────────────────────
async def _auth(uid: int) -> bool:
    return await sync_to_async(Operator.objects.filter(telegram_id=uid, is_active=True).exists)()

# ════════════════════════════  ХЭНДЛЕРЫ  ═══════════════════════════
@router.message(F.text == "/start", F.chat.type == "private")
async def cmd_start(m: Message):
    if not await _auth(m.from_user.id):
        return await m.answer("Нет доступа.")
    shift = await REDIS.sismember(R_ON_SHIFT, str(m.from_user.id))
    await m.answer(f"Добро пожаловать! Смена {'открыта' if shift else 'закрыта'}.",
                   reply_markup=kb_reply(shift))

# ― кнопки смены
@router.message(F.text.in_({SHIFT_IN, SHIFT_OUT}), F.chat.type == "private")
async def on_shift_btn(m: Message):
    if not await _auth(m.from_user.id):
        return
    if m.text == SHIFT_IN:
        await _shift_in(m.from_user.id, m)
    else:
        await _shift_out(m.from_user.id, m)

# ― команды смены
@router.message(Command("shift_in"), F.chat.type == "private")
async def cmd_shift_in(m: Message):
    if await _auth(m.from_user.id):
        await _shift_in(m.from_user.id, m)

@router.message(Command("shift_out"), F.chat.type == "private")
async def cmd_shift_out(m: Message):
    if await _auth(m.from_user.id):
        await _shift_out(m.from_user.id, m)

async def _shift_in(uid: int, ctx: Message):
    uid_s = str(uid)
    if await REDIS.sismember(R_ON_SHIFT, uid_s):
        return await ctx.answer("Смена уже открыта.", reply_markup=kb_reply(True))
    await REDIS.sadd(R_ON_SHIFT, uid_s)
    await ctx.answer("✅ Вы вошли в смену.", reply_markup=kb_reply(True))
    log.info("shift IN %s", uid)

    # ─ отправляем все ожидавшие заявки с вопросом ─
    for job in await REDIS.hkeys(R_PENDING):
        text = await REDIS.hget(R_JOB2TEXT, job) or "—"
        try:
            await op_bot.send_message(
                uid,
                f"🆕 <b>Заявка {job}</b> (ожидает оператора)\n\n{text}",
                reply_markup=kb_take(job),
            )
        except Exception:
            log.exception("DM pending %s to %s", job, uid)

async def _shift_out(uid: int, ctx: Message):
    uid_s = str(uid)
    if not await REDIS.sismember(R_ON_SHIFT, uid_s):
        return await ctx.answer("Смена уже закрыта.", reply_markup=kb_reply(False))
    if await REDIS.hget(R_CURRENT, uid):
        return await ctx.answer("Нельзя выйти — есть активная заявка.", reply_markup=kb_reply(True))
    await REDIS.srem(R_ON_SHIFT, uid_s)
    await ctx.answer("⬛ Смена закрыта.", reply_markup=kb_reply(False))
    log.info("shift OUT %s", uid)

# ― принять / сдать / закрыть
@router.callback_query(OpAction.filter(F.action == "take"))
async def cb_take(q: CallbackQuery, callback_data: OpAction):
    if not await _auth(q.from_user.id):
        return await q.answer("Нет доступа", show_alert=True)
    if not await REDIS.sismember(R_ON_SHIFT, str(q.from_user.id)):
        return await q.answer("Сначала войдите в смену.", show_alert=True)

    job = callback_data.job_id
    if await REDIS.hget(R_SESSIONS, job):
        return await q.answer("Заявку уже принял другой оператор.", show_alert=True)

    await REDIS.hset(R_SESSIONS, job, q.from_user.id)
    await REDIS.hset(R_CURRENT,  q.from_user.id, job)
    await REDIS.hdel(R_PENDING,  job)
    await REDIS.hset(R_LAST_ACTIVITY, job, int(time.time()))

    await q.message.edit_reply_markup(reply_markup=kb_working(job))
    await op_bot.send_message(q.from_user.id, f"✅ Вы приняли заявку {job}.")
    await q.answer()

@router.callback_query(OpAction.filter(F.action == "drop"))
async def cb_drop(q: CallbackQuery, callback_data: OpAction):
    job, uid = callback_data.job_id, q.from_user.id
    await REDIS.hdel(R_SESSIONS, job)
    await REDIS.hdel(R_CURRENT, uid)
    await REDIS.hset(R_PENDING, job, int(time.time()))
    await q.message.edit_reply_markup(reply_markup=kb_take(job))
    await q.answer("Заявка возвращена в пул.")

@router.callback_query(OpAction.filter(F.action == "close"))
async def cb_close(q: CallbackQuery, callback_data: OpAction):
    job, uid = callback_data.job_id, q.from_user.id
    chat_id = await REDIS.hget(R_JOB2CHAT, job)
    await _close_job(job, uid)
    if chat_id:
        await user_bot.send_message(int(chat_id),
                                    "👨‍💼 Оператор завершил консультацию.\nЕсли появятся новые вопросы — напишите.")
    await q.message.edit_reply_markup()
    await q.answer("Диалог закрыт.")

# ― личное сообщение оператора
@router.message(F.chat.type == "private", ~F.via_bot)
async def op_msg(m: Message):
    if not await _auth(m.from_user.id):
        return
    job = await REDIS.hget(R_CURRENT, m.from_user.id)
    if not job:
        return await m.reply("Сначала примите заявку.")
    chat_id = await REDIS.hget(R_JOB2CHAT, job)
    if not chat_id:
        return await m.reply("Заявка уже закрыта.")
    try:
        await _relay(m, int(chat_id))
    except Exception as e:
        log.exception("relay")
        return await m.reply(f"Не удалось отправить: {e}")
    await m.reply("✅ Отправлено.")

# ― /done
@router.message(Command("done"))
async def cmd_done(m: Message):
    job = await REDIS.hget(R_CURRENT, m.from_user.id)
    if not job:
        return await m.reply("Нет активной заявки.")
    chat_id = await REDIS.hget(R_JOB2CHAT, job)
    await _close_job(job, m.from_user.id)
    if chat_id:
        await user_bot.send_message(int(chat_id),
                                    "👨‍💼 Оператор завершил консультацию.\nЕсли появятся новые вопросы — напишите.")
    await m.answer("Диалог закрыт.", reply_markup=kb_reply(True))

# ════════════════════════════  Служебные  ═══════════════════════════
async def _relay(src: Message, dst: int) -> None:
    async def _safe(fn, fid: str, fname: str):
        try:
            await fn(fid)
        except TelegramBadRequest as e:
            if "wrong file identifier" not in str(e).lower():
                raise
            f = await op_bot.get_file(fid)
            buf = BytesIO()
            await op_bot.download_file(f.file_path, destination=buf)
            buf.seek(0)
            await fn(BufferedInputFile(buf.read(), fname))

    kind = src.content_type
    if kind == ContentType.TEXT:
        await user_bot.send_message(dst, src.text)
    elif kind == ContentType.PHOTO:
        await _safe(lambda f: user_bot.send_photo(dst, f, caption=src.caption or ""),
                    src.photo[-1].file_id, "photo.jpg")
    elif kind == ContentType.DOCUMENT:
        await _safe(lambda f: user_bot.send_document(dst, f, caption=src.caption or ""),
                    src.document.file_id, src.document.file_name or "doc")
    elif kind == ContentType.VOICE:
        await _safe(lambda f: user_bot.send_voice(dst, f, caption=src.caption or ""),
                    src.voice.file_id, "voice.ogg")
    elif kind == ContentType.STICKER:
        await user_bot.send_sticker(dst, src.sticker.file_id)
    else:
        await user_bot.send_message(dst, "<i>[неподдерживаемый тип вложения]</i>")

async def _close_job(job: str, operator_id: Optional[int] = None):
    chat_id = await REDIS.hget(R_JOB2CHAT, job)

    await REDIS.hdel(R_SESSIONS, job)
    await REDIS.hdel(R_PENDING,  job)
    await REDIS.hdel(R_JOB2CHAT, job)
    await REDIS.hdel(R_LAST_ACTIVITY, job)
    await REDIS.hdel(R_JOB2TEXT, job)

    if operator_id:
        await REDIS.hdel(R_CURRENT, operator_id)
    if chat_id:
        await REDIS.hdel(R_CHAT2JOB, chat_id)
        await REDIS.delete(f"session:{chat_id}")

# ════════════════════════════  Фоновые задачи  ══════════════════════
async def tickets_listener():
    while True:
        try:
            job = await QUEUE.pop(timeout=5)
            if job:
                await _publish_ticket(job)
        except Exception:
            log.exception("tickets_listener")
            await asyncio.sleep(1)

async def dialog_listener():
    while True:
        try:
            msg = await DIALOG_QUEUE.pop(timeout=5)
            if msg:
                await _forward_from_user(msg)
        except Exception:
            log.exception("dialog_listener")
            await asyncio.sleep(1)

async def overdue_monitor():
    while True:
        await asyncio.sleep(60)
        now = int(time.time())
        for job, ts in (await REDIS.hgetall(R_PENDING)).items():
            if now - int(ts) < UNANSWERED_TTL or await REDIS.hget(R_SESSIONS, job):
                continue
            on_shift = {int(u) for u in await REDIS.smembers(R_ON_SHIFT)}
            if not on_shift:                       # всё ещё никто не дежурит
                continue
            for uid in on_shift:
                try:
                    text = await REDIS.hget(R_JOB2TEXT, job) or "—"
                    await op_bot.send_message(
                        uid,
                        f"⏰ Заявка {job} без ответа {UNANSWERED_TTL//60} мин.\n\n{text}",
                        reply_markup=kb_take(job),
                    )
                except Exception:
                    log.exception("notify %s", uid)
            await REDIS.hset(R_PENDING, job, now)

async def dialog_timeout_monitor():
    while True:
        await asyncio.sleep(60)
        now = int(time.time())
        for job, last in (await REDIS.hgetall(R_LAST_ACTIVITY)).items():
            if now - int(last) < DIALOG_INACTIVE_TTL:
                continue
            op_id   = await REDIS.hget(R_SESSIONS, job)
            chat_id = await REDIS.hget(R_JOB2CHAT, job)
            await _close_job(job, op_id)
            if chat_id:
                await user_bot.send_message(int(chat_id),
                                            "Диалог автоматически закрыт из-за отсутствия активности.")
            if op_id:
                await op_bot.send_message(int(op_id),
                                          "Диалог автоматически закрыт из-за отсутствия активности.")

# ════════════════════════════  Публикация заявки  ═══════════════════
async def _publish_ticket(job: dict):
    job_id  = job["job_id"]
    chat_id = job["chat_id"]
    question = (job.get("transcript") or "") or "<i>— без текста —</i>"

    await REDIS.hset(R_JOB2CHAT, job_id, chat_id)
    await REDIS.hset(R_CHAT2JOB, chat_id, job_id)
    await REDIS.hset(R_JOB2TEXT, job_id, question)       # ←--- сохраняем текст
    await REDIS.hset(R_PENDING, job_id, int(time.time()))
    await REDIS.hset(R_LAST_ACTIVITY, job_id, int(time.time()))

    info_lines = []
    try:
        chat = await user_bot.get_chat(chat_id)
        info_lines.append(f"<b>Имя:</b> {chat.full_name}")
        if chat.username:
            info_lines.append(f"<b>@username:</b> @{chat.username}")
        #info_lines.append(f"<b>ID:</b> <code>{chat.id}</code>")
    except Exception:
        log.exception("get_chat failed")

    info_block = "\n".join(info_lines) if info_lines else "—"

    on_shift = {int(u) for u in await REDIS.smembers(R_ON_SHIFT)}
    for uid in on_shift:
        try:
            await op_bot.send_message(
                uid,
                f"🆕 <b>Заявка {job_id}</b>\n\n{question}\n\n<b>Пользователь</b>\n{info_block}",
                reply_markup=kb_take(job_id),
            )
        except Exception:
            log.exception("DM %s failed", uid)

# ════════════════════════════  Forward от пользователя  ═════════════
async def _forward_from_user(msg: dict):
    job  = msg["job_id"]
    text = msg["text"]
    op_id = await REDIS.hget(R_SESSIONS, job)

    if op_id:
        await op_bot.send_message(int(op_id), f"👤 <b>Пользователь:</b>\n{text}")
    else:
        for uid in {int(u) for u in await REDIS.smembers(R_ON_SHIFT)}:
            try:
                await op_bot.send_message(uid,
                                          f"📨 <b>Новое сообщение в заявке {job}</b>\n{text}",
                                          reply_markup=kb_take(job))
            except Exception:
                log.exception("DM %s failed", uid)
    await REDIS.hset(R_LAST_ACTIVITY, job, int(time.time()))

# ════════════════════════════  Startup  ═════════════════════════════
@dp.startup()
async def on_startup():
    await REDIS.delete(R_JOB2CHAT, R_SESSIONS, R_CURRENT,
                       R_PENDING, R_LAST_ACTIVITY, R_JOB2TEXT)
    asyncio.create_task(tickets_listener())
    asyncio.create_task(dialog_listener())
    asyncio.create_task(overdue_monitor())
    asyncio.create_task(dialog_timeout_monitor())
    log.info("Operator-bot ready")

class Command(BaseCommand):
    help = "Запускает Telegram-бот операторов"

    def handle(self, *args, **kwargs):
        dp.run_polling(op_bot)

