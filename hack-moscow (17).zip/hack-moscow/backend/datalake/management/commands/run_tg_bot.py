#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Запуск абитуриентского бота + пул LLM-воркеров.
"""

from __future__ import annotations

import asyncio
import logging
from typing import List

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from redis.asyncio import Redis

from tg_admission_bot.config import Settings
from tg_admission_bot.redis_queue import RedisQueue
import tg_admission_bot.bot_handlers as bh

from django.core.management.base import BaseCommand

log = logging.getLogger("tg_bot")
logging.basicConfig(level=logging.INFO,
                    format="[%(asctime)s] [%(levelname)8s] %(name)s – %(message)s")


class Command(BaseCommand):
    help = "Запускает Telegram-бот абитуриента и LLM-воркеры."

    def handle(self, *args, **kw):
        asyncio.run(self._main())

    async def _main(self):
        cfg = Settings()

        bot = Bot(
            token=cfg.TELEGRAM_TOKEN.get_secret_value(),
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )
        dp = Dispatcher()

        # хэндлеры
        bh._rds = Redis.from_url(cfg.REDIS_URL, decode_responses=True)
        bh.register_handlers(dp, cfg)

        # воркеры
        llm_q = RedisQueue(cfg.REDIS_URL, cfg.REDIS_QUEUE_NAME)
        stop  = asyncio.Event()
        sem   = asyncio.Semaphore(cfg.MAX_CONCURRENT_REQUESTS)

        async def worker(i: int):
            log.info("LLM-worker-%d start", i)
            while not stop.is_set():
                try:
                    job = await llm_q.pop(timeout=5)
                    if not job:
                        continue
                    async with sem:
                        await bh.process_question(bot, job)
                except asyncio.CancelledError:
                    break
                except Exception:
                    log.exception("worker-%d", i)
            log.info("LLM-worker-%d stop", i)

        tasks: List[asyncio.Task] = [asyncio.create_task(worker(i + 1)) for i in range(cfg.MAX_CONCURRENT_REQUESTS)]

        @dp.shutdown()
        async def _shutdown():
            stop.set()
            await asyncio.gather(*tasks, return_exceptions=True)
            await bot.session.close()

        await dp.start_polling(bot)
