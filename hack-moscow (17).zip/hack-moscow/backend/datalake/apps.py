from django.apps import AppConfig

class DatalakeConfig(AppConfig):
    label = "datalake"
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'datalake'
    verbose_name = 'datalake'

    def ready(self):
        # при старте Django автоматически подключает сигналы
        import datalake.signals  # noqa
