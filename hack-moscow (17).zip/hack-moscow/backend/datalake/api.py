# datalake/api.py
import base64, json
from django.http import JsonResponse, HttpResponseBadRequest
from django.db.models import Q
from django.utils.dateparse import parse_datetime
from .models import Attachment, Pool

def _enc_cursor(created_at, _id):
    payload = json.dumps({"t": created_at.isoformat() if created_at else "", "id": _id}).encode("utf-8")
    return base64.urlsafe_b64encode(payload).decode("ascii")

def _dec_cursor(cursor):
    try:
        data = json.loads(base64.urlsafe_b64decode(cursor.encode("ascii")).decode("utf-8"))
        t = parse_datetime(data.get("t") or "")
        return t, int(data["id"])
    except Exception:
        return None, None

def list_attachments(request, pool_id: int):
    try:
        limit = min(int(request.GET.get("limit", 100)), 500)
    except:
        return HttpResponseBadRequest("limit must be int")
    cursor = request.GET.get("cursor")
    q = request.GET.get("q")
    category_path = request.GET.get("category_path")

    qs = Attachment.objects.filter(pool_id=pool_id).select_related("category").only(
        "id","category_id","mime_type","keywords","created_at"
    ).order_by("-created_at","-id")

    if q:
        qs = qs.filter(Q(keywords__icontains=q) | Q(tsvector__search=q))
    if category_path:
        qs = qs.filter(category__path__descendant=category_path)

    if cursor:
        created_at, aid = _dec_cursor(cursor)
        if created_at:
            qs = qs.filter(Q(created_at__lt=created_at) | Q(created_at=created_at, id__lt=aid))

    items = list(qs[:limit+1])
    next_cursor = None
    if len(items) > limit:
        last = items[limit-1]
        next_cursor = _enc_cursor(last.created_at, last.id)
        items = items[:limit]

    def s(a):
        return {
            "id": a.id,
            "category_id": a.category_id,
            "mime_type": a.mime_type,
            "keywords": a.keywords,
            "created_at": a.created_at.isoformat() if a.created_at else None,
        }

    return JsonResponse({"items": [s(x) for x in items], "next_cursor": next_cursor})

def list_pools(request):
    try:
        limit = min(int(request.GET.get("limit", 50)), 200)
    except:
        return HttpResponseBadRequest("limit must be int")
    cursor = request.GET.get("cursor")
    q = request.GET.get("q")
    year = request.GET.get("year")
    revision = request.GET.get("revision")

    qs = Pool.objects.only("id","name","description","year","revision","updated_at").order_by("-updated_at","-id")
    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(description__icontains=q))
    if year:
        qs = qs.filter(year=year)
    if revision:
        qs = qs.filter(revision=revision)

    if cursor:
        dt, pid = _dec_cursor(cursor)
        if dt:
            qs = qs.filter(Q(updated_at__lt=dt) | Q(updated_at=dt, id__lt=pid))

    items = list(qs[:limit+1])
    next_cursor = None
    if len(items) > limit:
        last = items[limit-1]
        next_cursor = _enc_cursor(last.updated_at, last.id)
        items = items[:limit]

    def s(p):
        return {
            "id": p.id,
            "title": p.name,
            "description": p.description,
            "year": p.year,
            "revision": p.revision,
            "updated_at": p.updated_at.isoformat() if p.updated_at else None
        }

    return JsonResponse({"items": [s(x) for x in items], "next_cursor": next_cursor})
