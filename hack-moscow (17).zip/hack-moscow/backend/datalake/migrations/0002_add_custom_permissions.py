# datalake/migrations/0002_add_custom_permissions.py
from django.db import migrations


def add_custom_permissions(apps, schema_editor):
    Permission = apps.get_model("auth", "Permission")
    ContentType = apps.get_model("contenttypes", "ContentType")
    # исторические модели текущего состояния схемы
    Pool = apps.get_model("datalake", "Pool")
    Category = apps.get_model("datalake", "Category")
    Attachment = apps.get_model("datalake", "Attachment")
    # получаем/создаём ContentType для моделей
    ct_pool = ContentType.objects.get_for_model(Pool)
    ct_category = ContentType.objects.get_for_model(Category)
    ct_attachment = ContentType.objects.get_for_model(Attachment)

    # список всех кодовых имён и человеко-читаемых имён прав
    perms = [
        # Pool
        (ct_pool, "add_pool", "Can add pool"),
        (ct_pool, "view_pool", "Can view pool"),
        (ct_pool, "change_pool", "Can change pool"),
        (ct_pool, "delete_pool", "Can delete pool"),
        (ct_pool, "import_pool", "Can import pool"),
        (ct_pool, "export_pool", "Can export pool"),
        # Category
        (ct_category, "add_category", "Can add category"),
        (ct_category, "view_category", "Can view category"),
        (ct_category, "change_category", "Can change category"),
        (ct_category, "delete_category", "Can delete category"),
        (ct_category, "import_category", "Can import category"),
        (ct_category, "export_category", "Can export category"),
        # Attachment
        (ct_attachment, "add_attachment", "Can add attachment"),
        (ct_attachment, "view_attachment", "Can view attachment"),
        (ct_attachment, "change_attachment", "Can change attachment"),
        (ct_attachment, "delete_attachment", "Can delete attachment"),
        (ct_attachment, "import_attachment", "Can import attachment"),
        (ct_attachment, "export_attachment", "Can export attachment"),
    ]

    for ct, codename, name in perms:
        Permission.objects.get_or_create(
            content_type=ct,
            codename=codename,
            defaults={"name": name},
        )


def remove_custom_permissions(apps, schema_editor):
    Permission = apps.get_model("auth", "Permission")
    codenames = [
        "add_pool", "view_pool", "change_pool", "delete_pool", "import_pool", "export_pool",
        "add_category", "view_category", "change_category", "delete_category", "import_category", "export_category",
        "add_attachment", "view_attachment", "change_attachment", "delete_attachment", "import_attachment", "export_attachment",
    ]
    Permission.objects.filter(codename__in=codenames, content_type__app_label="datalake").delete()


class Migration(migrations.Migration):
    initial = False

    dependencies = [
        ("datalake", "0001_initial"),
        ("auth", "0012_alter_user_first_name_max_length"),
        ("contenttypes", "0002_remove_content_type_name"),
    ]

    operations = [
        migrations.RunPython(add_custom_permissions, remove_custom_permissions),
    ]
