# datalake/signals.py

import logging
import shutil
from typing import Optional

from django.core.files.storage import FileSystemStorage
from django.db.models import Value
from django.db.models.functions import Substr
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver
from django.contrib.postgres.search import SearchVector

from PyPDF2 import PdfReader
from docx import Document

from .models import Attachment
from .vector import embed_text, upsert_embedding

logger = logging.getLogger(__name__)

# Лимит символов, используемый как источник для полнотекстового индекса (tsvector)
MAX_TSV_SOURCE_LEN = 50_000


def _safe_open(field_file) -> bool:
    """
    Безопасно открывает FileField/File для чтения в бинарном режиме.
    Возвращает True, если файл успешно открыт.
    """
    try:
        field_file.open(mode="rb")
        field_file.seek(0)
        return True
    except Exception as e:
        logger.error("Не удалось открыть файл вложения: %s", e)
        return False


def _read_pdf_text(field_file) -> str:
    """
    Извлекает текст из PDF при помощи PyPDF2.
    """
    try:
        reader = PdfReader(field_file)
        pages = [page.extract_text() or "" for page in reader.pages]
        return "\n".join(pages)
    except Exception as e:
        logger.error("Ошибка чтения PDF: %s", e)
        return ""


def _read_docx_text(field_file) -> str:
    """
    Извлекает текст из DOCX при помощи python-docx.
    """
    try:
        doc = Document(field_file)
        return "\n".join(p.text for p in doc.paragraphs if p.text)
    except Exception as e:
        logger.error("Ошибка чтения DOCX: %s", e)
        return ""


def _read_plain_text(field_file, encoding_candidates: Optional[list[str]] = None) -> str:
    """
    Читает текстовые файлы (text/*). Пытается декодировать в UTF-8,
    при неудаче — пробует указанные кодировки, затем — «как есть» с игнором ошибок.
    """
    if encoding_candidates is None:
        encoding_candidates = ["utf-8", "cp1251", "latin-1"]

    try:
        raw = field_file.read()
    except Exception as e:
        logger.error("Ошибка чтения потока файла: %s", e)
        return ""

    for enc in encoding_candidates:
        try:
            return raw.decode(enc)
        except Exception:
            continue

    # Последняя попытка — максимально щадящая
    try:
        return raw.decode(errors="ignore")
    except Exception:
        return ""


def _extract_text(att: Attachment) -> str:
    """
    Извлекает текст для векторизации и полнотекстового поиска.

    Источники:
      1) Если у вложения есть файл:
         - PDF (application/pdf) — PyPDF2
         - DOCX (office openxml) — python-docx
         - Любые text/* — двоичное чтение и декодирование
         - DOC (application/msword) — НЕ поддерживается; будет лог и возврат пустой строки
      2) Если файл отсутствует или не удалось извлечь — используется поле `content`.
      3) При любых ошибках возвращается пустая строка.
    """
    field_file = getattr(att, "file", None)
    has_file = bool(field_file and getattr(field_file, "name", None))

    if has_file:
        mime = (att.mime_type or "").lower()

        if not _safe_open(field_file):
            # Падать не будем — попробуем content
            pass
        else:
            try:
                # PDF
                if mime == "application/pdf":
                    text = _read_pdf_text(field_file)
                    if text:
                        return text

                # DOCX
                elif mime in (
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/msword+xml",
                ) or field_file.name.lower().endswith(".docx"):
                    text = _read_docx_text(field_file)
                    if text:
                        return text

                # DOC (устаревший бинарный формат Word) — сознательно не поддерживается без textract
                elif mime == "application/msword" or field_file.name.lower().endswith(".doc"):
                    logger.warning(
                        "Attachment %s: формат .doc (application/msword) не поддерживается без textract. "
                        "Документ будет пропущен при извлечении текста.",
                        getattr(att, "id", "<?>"),
                    )
                    # Возвращаем пустую строку, чтобы сработал fallback на content ниже.

                # Любые text/*
                elif mime.startswith("text/"):
                    text = _read_plain_text(field_file)
                    if text:
                        return text

                else:
                    logger.info(
                        "Attachment %s: MIME-тип '%s' не поддерживается для извлечения текста.",
                        getattr(att, "id", "<?>"),
                        att.mime_type,
                    )
            except Exception as e:
                logger.error("Attachment %s: ошибка при чтении файла – %s", getattr(att, "id", "<?>"), e)
            finally:
                try:
                    field_file.close()
                except Exception:
                    pass

    # fallback: content field
    if getattr(att, "content", None):
        return att.content

    logger.info("Attachment %s: нет файла и поле content пустое, пропускаем.", getattr(att, "id", "<?>"))
    return ""


@receiver(post_save, sender=Attachment)
def on_attach_save(sender, instance: Attachment, created, **kwargs):
    """
    1) Обновляет полнотекстовый индекс (tsvector).
    2) Строит эмбеддинг и записывает/обновляет его в векторном хранилище.
    """
    # 1) tsvector
    try:
        # Берём только первые 50 000 символов, чтобы гарантированно не превысить лимиты
        Attachment.objects.filter(id=instance.id).update(
            tsvector=(
                # описание – самый высокий вес
                    SearchVector(Value((instance.description or "")[:10_000]), weight="A", config="russian")
                    # ключевые слова
                    + SearchVector(Value((instance.keywords or "")[:5_000]), weight="B", config="russian")
                    # первые 50 000 символов контента
                    + SearchVector(
                Substr(Value(instance.content or ""), 1, MAX_TSV_SOURCE_LEN), weight="B", config="russian"
            )
                    # название категории – низкий вес
                    + SearchVector(Value((getattr(instance.category, "name", "") or "")[:2_000]), weight="D", config="russian")
            )
        )
    except Exception as e:
        logger.error("Attachment %s: не удалось обновить tsvector – %s", instance.id, e)

    # 2) Векторный индекс
    try:
        text = _extract_text(instance)
        if not text:
            return

        vec = embed_text(text)
        upsert_embedding(
            uid=instance.embedding_id,
            vector=vec,
            pool_id=instance.pool_id,
            category_id=instance.category_id,
            attachment_id=instance.id,
        )
        logger.info("Attachment %s: эмбеддинг сохранён в Qdrant.", instance.id)
    except Exception as e:
        logger.exception("Attachment %s: ошибка векторного индексирования – %s", instance.id, e)


@receiver(post_delete, sender=Attachment)
def delete_file_on_attachment_delete(sender, instance: Attachment, **kwargs):
    """
    Удаляет физический файл из хранилища при удалении Attachment.
    Вызывается и при прямом удалении, и при каскадном (удаление Pool/Category).
    Для локального FileSystemStorage дополнительно чистит пустые папки …/pools/<pool_id>/…
    """
    f = getattr(instance, "file", None)
    if not f:
        return

    storage = f.storage
    try:
        if storage.exists(f.name):
            storage.delete(f.name)
            logger.info("Файл %s удалён из хранилища", f.name)
    except Exception as e:
        logger.error("Не удалось удалить файл %s – %s", f.name, e)

    # Для локального FileSystemStorage почистим каталог пула
    if isinstance(storage, FileSystemStorage):
        dir_path = storage.path(f"pools/{instance.pool_id}")
        try:
            shutil.rmtree(dir_path, ignore_errors=True)
        except Exception:
            pass


