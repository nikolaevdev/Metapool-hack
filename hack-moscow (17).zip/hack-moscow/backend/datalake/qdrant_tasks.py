import os
from celery import shared_task
from qdrant_client import QdrantClient
from qdrant_client.http import models as qm
from sentence_transformers import SentenceTransformer

from datalake.models import Attachment, Pool

MODEL_NAME = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
QDRANT_URL = os.getenv("QDRANT_URL", "http://qdrant:6333")
QDRANT_API_KEY = os.getenv("QDRANT_API_KEY")

def get_client():
    return QdrantClient(url=QDRANT_URL, api_key=QDRANT_API_KEY)

def get_model():
    return SentenceTransformer(MODEL_NAME)

def ensure_collection(name: str, size: int):
    c = get_client()
    try:
        c.get_collection(name)
    except Exception:
        c.recreate_collection(name, vectors_config=qm.VectorParams(size=size, distance=qm.Distance.COSINE))

@shared_task
def index_pool_attachments(pool_id: int, collection: str = "attachments", batch_size: int = 256):
    model = get_model()
    dim = model.get_sentence_embedding_dimension()
    ensure_collection(collection, dim)
    c = get_client()

    qs = Attachment.objects.filter(pool_id=pool_id).only("id", "title", "content").order_by("id")
    buf_ids, buf_payloads, buf_texts = [], [], []
    count = 0
    for a in qs.iterator(chunk_size=1000):
        txt = ((a.title or "") + " " + (a.content or "")).strip()
        if not txt:
            continue
        buf_ids.append(str(a.id))
        buf_payloads.append({"attachment_id": a.id, "pool_id": pool_id, "title": a.title})
        buf_texts.append(txt)
        if len(buf_texts) >= batch_size:
            vecs = model.encode(buf_texts, normalize_embeddings=True)
            points = [qm.PointStruct(id=buf_ids[i], vector=vecs[i].tolist(), payload=buf_payloads[i]) for i in range(len(buf_ids))]
            c.upsert(collection_name=collection, points=points, wait=True)
            count += len(points)
            buf_ids, buf_payloads, buf_texts = [], [], []
    if buf_texts:
        vecs = model.encode(buf_texts, normalize_embeddings=True)
        points = [qm.PointStruct(id=buf_ids[i], vector=vecs[i].tolist(), payload=buf_payloads[i]) for i in range(len(buf_ids))]
        c.upsert(collection_name=collection, points=points, wait=True)
        count += len(points)
    return {"indexed": count, "collection": collection, "pool": pool_id}


def _chunk_text(text: str, max_words: int = 180, overlap: int = 40):
    words = (text or "").split()
    if not words:
        return []
    chunks = []
    i = 0
    while i < len(words):
        chunk = words[i:i+max_words]
        chunks.append(" ".join(chunk))
        i += max_words - overlap if max_words > overlap else max_words
    return chunks

@shared_task
def index_all_pools(collection: str = "pool_chunks", chunk_words: int = 180, overlap: int = 40, batch_size: int = 256):
    """
    Индексирует пулы: title/prompt + все attachments, чанкуя текст и сохраняя в payload pool_id/attachment_id/type.
    """
    from backend.datalake.models import Pool, Attachment
    model = get_model()
    dim = model.get_sentence_embedding_dimension()
    ensure_collection(collection, dim)
    c = get_client()

    def upsert(points):
        if points:
            c.upsert(collection_name=collection, points=points, wait=True)

    total = 0
    buf = []

    qs_p = Pool.objects.select_related("category").only("id", "title", "prompt", "category").order_by("id")
    for p in qs_p.iterator(chunk_size=500):
        items = []
        if p.title:
            items += [(p.title, {"type":"title"})]
        if p.prompt:
            items += [(" ".join(_chunk_text(p.prompt, chunk_words, overlap)), {"type":"prompt"})] if len(p.prompt.split())>chunk_words else [(p.prompt, {"type":"prompt"})]

        att_qs = Attachment.objects.filter(pool_id=p.id).only("id","title","content").order_by("id")
        for a in att_qs.iterator(chunk_size=1000):
            base = (a.title or "") + " " + (a.content or "")
            for idx, ch in enumerate(_chunk_text(base, chunk_words, overlap) or []):
                payload = {"model":"pool", "pool_id": p.id, "attachment_id": a.id, "chunk": idx, "type": "attachment", "title": a.title}
                items.append((ch, payload))

        # vectorize items in batches
        texts = [t for t,_ in items]
        payloads = [pl for _,pl in items]
        if not texts:
            continue
        vecs = model.encode(texts, normalize_embeddings=True)
        points = []
        for i,(text,payload) in enumerate(zip(texts,payloads)):
            pid = f"pool-{p.id}-idx-{i}"
            full_payload = {"pool_id": p.id, **payload}
            points.append(qm.PointStruct(id=pid, vector=vecs[i].tolist(), payload=full_payload))
            if len(points) >= batch_size:
                upsert(points); total += len(points); points = []
        upsert(points); total += len(points)

    return {"indexed_points": total, "collection": collection}


from django.db import transaction

def _delete_by_pool(collection: str, pool_id: int):
    c = get_client()
    flt = qm.Filter(should=[qm.FieldCondition(key="pool_id", match=qm.MatchValue(value=int(pool_id)))])
    c.delete(collection_name=collection, points_selector=flt, wait=True)

@shared_task
def reindex_pool(pool_id: int, collections: list[str] | None = None, chunk_words: int = 180, overlap: int = 40, batch_size: int = 256):
    from backend.datalake.models import Pool, Attachment
    collections = collections or ["pool_chunks"]
    model = get_model()
    dim = model.get_sentence_embedding_dimension()
    for col in collections:
        ensure_collection(col, dim)
        _delete_by_pool(col, pool_id)

    c = get_client()

    def _chunk_text(text: str, max_words: int = 180, overlap: int = 40):
        words = (text or "").split()
        if not words:
            return []
        chunks = []
        i = 0
        while i < len(words):
            chunk = words[i:i+max_words]
            chunks.append(" ".join(chunk))
            i += max_words - overlap if max_words > overlap else max_words
        return chunks

    try:
        p = Pool.objects.select_related("category").only("id","title","prompt","category").get(id=pool_id)
    except Pool.DoesNotExist:
        return {"reindexed": 0, "reason": "pool_not_found", "pool_id": pool_id}

    items = []
    if p.title:
        items.append((p.title, {"type":"title"}))
    if p.prompt:
        pr = p.prompt
        chunks = _chunk_text(pr, chunk_words, overlap) or [pr]
        for idx, ch in enumerate(chunks):
            items.append((ch, {"type":"prompt","chunk":idx}))

    att_qs = Attachment.objects.filter(pool_id=p.id).only("id","title","content").order_by("id")
    for a in att_qs.iterator(chunk_size=1000):
        base = (a.title or "") + " " + (a.content or "")
        for idx, ch in enumerate(_chunk_text(base, chunk_words, overlap) or []):
            items.append((ch, {"type":"attachment","attachment_id": a.id, "chunk": idx, "title": a.title}))

    texts = [t for t,_ in items]
    payloads = [pl for _,pl in items]
    if not texts:
        return {"reindexed": 0, "pool_id": pool_id}

    vecs = model.encode(texts, normalize_embeddings=True)
    total = 0
    for col in collections:
        points = []
        for i,(text,payload) in enumerate(zip(texts,payloads)):
            pid = f"pool-{pool_id}-idx-{i}"
            full_payload = {"pool_id": pool_id, "category_id": getattr(p.category, "id", None), **payload}
            points.append(qm.PointStruct(id=pid, vector=vecs[i].tolist(), payload=full_payload))
            if len(points) >= batch_size:
                c.upsert(collection_name=col, points=points, wait=True)
                total += len(points)
                points = []
        if points:
            c.upsert(collection_name=col, points=points, wait=True)
            total += len(points)

    return {"reindexed": total, "pool_id": pool_id, "collections": collections}
