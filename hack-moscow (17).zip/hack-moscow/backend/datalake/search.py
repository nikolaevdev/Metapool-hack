"""datalake/search.py
Полностью доработанный модуль продвинутого поиска вложений по пулам данных.
Исправлена ошибка смешения типов при конкатенации полей разных типов (TextField и CharField).
"""

from __future__ import annotations

import re
from typing import List, Optional, Set

from django.db.models import F, Value, TextField
from django.db.models.functions import Concat, Coalesce
from django.contrib.postgres.search import (
    SearchQuery,
    SearchRank,
    TrigramSimilarity,
)

from .models import Attachment, Pool
from .vector import similarity_search

# ---------------------------------------------------------------------------
# Настройки
# ---------------------------------------------------------------------------

# Расширенный список стоп‑слов для русского (при необходимости дополняйте)
_RU_STOP: Set[str] = {
    "и", "в", "во", "не", "что", "он", "на", "я", "с", "со", "как", "а", "то",
    "все", "она", "так", "его", "но", "да", "ты", "к", "у", "же", "вы", "за",
    "бы", "по", "только", "ее", "мне", "было", "вот", "от", "меня", "еще",
    "нет", "о", "из", "ему", "теперь", "когда", "даже", "ну", "ли", "если",
    "уже", "или", "ни", "быть", "был", "него", "до", "вас", "нибудь", "опять",
    "уж", "вам", "ведь", "там", "потом", "себя", "ничего", "ей", "может",
    "они", "тут", "где", "есть", "надо", "ней", "для", "мы", "тебя", "их",
    "чем", "была", "сам", "чтоб", "без", "будто", "чего", "раз", "тоже",
    "себе", "под", "будет", "ж", "тогда", "кто", "этот", "того", "потому",
    "этого", "какой", "совсем", "ним", "здесь", "этом", "один", "почти",
    "мой", "тем", "чтобы", "нее", "сейчас", "были", "куда", "зачем", "всех",
    "никогда", "можно", "при", "наконец", "два", "об", "другой", "хоть",
    "после", "над", "больше", "тот", "через", "эти", "нас", "про", "всего",
    "них", "какая", "много", "разве", "три", "эту", "моя", "впрочем", "хорошо",
    "свою", "этой", "перед", "иногда", "лучше", "чуть", "том", "нельзя",
    "такой", "им", "более", "всегда", "конечно", "всю", "между",
}
_MIN_TOKENS = 2
_RANK_MIN = 0.45
_TRI_MIN = 0.35
_TOP_K = 3

# ---------------------------------------------------------------------------
# Утилиты
# ---------------------------------------------------------------------------

def _tokenize(raw: str) -> List[str]:
    return re.findall(r"[\w\d]+", raw.lower())


def _clean(raw: str) -> str:
    return " ".join(t for t in _tokenize(raw) if t not in _RU_STOP)


def _is_query_simple(cleaned: str) -> bool:
    return len(cleaned.split()) < _MIN_TOKENS

# ---------------------------------------------------------------------------
# Стратегии поиска
# ---------------------------------------------------------------------------

def _ft_search(pool_id: int, tsq: SearchQuery) -> List[Attachment]:
    return list(
        Attachment.objects.filter(pool_id=pool_id)
        .annotate(rank=SearchRank(F("tsvector"), tsq))
        .filter(rank__gte=_RANK_MIN)
        .order_by("-rank")[:_TOP_K]
    )


def _tri_search(pool_id: int, query: str, remain: int) -> List[Attachment]:
    return list(
        Attachment.objects.filter(pool_id=pool_id)
        .annotate(
            target=Concat(
                # Явно указываем output_field для всех частей
                Coalesce(F("description"), Value("", output_field=TextField()), output_field=TextField()),
                Value(" ", output_field=TextField()),
                Coalesce(F("keywords"), Value("", output_field=TextField()), output_field=TextField()),
                output_field=TextField(),
            ),
            sim=TrigramSimilarity("target", query),
        )
        .filter(sim__gte=_TRI_MIN)
        .order_by("-sim")[:remain]
    )


def _vector_search(pool_id: int, query: str, remain: int, seen_ids: Set[int]) -> List[Attachment]:
    vector_ids = [i for i in similarity_search(query, pool_id) if i not in seen_ids][:remain]
    if not vector_ids:
        return []
    qs = Attachment.objects.filter(id__in=vector_ids)
    mapping = {a.id: a for a in qs}
    return [mapping[i] for i in vector_ids if i in mapping]

# ---------------------------------------------------------------------------
# Основные функции
# ---------------------------------------------------------------------------

def search_in_pool(pool_id: int, query: str) -> List[Attachment]:
    cleaned = _clean(query)
    if _is_query_simple(cleaned):
        return []
    tsq = SearchQuery(cleaned, config="russian", search_type="plain")

    results: List[Attachment] = _ft_search(pool_id, tsq)
    seen_ids: Set[int] = {a.id for a in results}

    if len(results) < _TOP_K:
        tri_needed = _TOP_K - len(results)
        tri_results = _tri_search(pool_id, cleaned, tri_needed)
        for a in tri_results:
            if a.id not in seen_ids:
                results.append(a)
                seen_ids.add(a.id)

    if len(results) < _TOP_K:
        vec_needed = _TOP_K - len(results)
        results += _vector_search(pool_id, query, vec_needed, seen_ids)

    return results


def search_pools(query: str, pool_id: Optional[int] = None) -> List[Attachment]:
    if _is_query_simple(_clean(query)):
        return []
    if pool_id is None:
        latest = Pool.objects.order_by("-created_at").first()
        if not latest:
            return []
        pool_id = latest.id
    return search_in_pool(pool_id, query)
