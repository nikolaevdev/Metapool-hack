#!/usr/bin/env bash
set -e
cd /app
echo "[worker] Waiting for DB/Redis (if needed)..."
# basic wait can be added here
echo "[worker] Starting Celery worker..."
exec celery -A datalake.celery:app worker -l info
