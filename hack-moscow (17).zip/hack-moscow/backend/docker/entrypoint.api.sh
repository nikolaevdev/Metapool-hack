#!/usr/bin/env bash
set -e
cd /app
echo "[entrypoint] Applying migrations..."
python backend/manage.py migrate --noinput
echo "[entrypoint] Collecting static..."
python backend/manage.py collectstatic --noinput || true
echo "[entrypoint] Starting Gunicorn..."
exec gunicorn fastapi_app.main:app -k uvicorn.workers.UvicornWorker -c /app/gunicorn_conf.py
