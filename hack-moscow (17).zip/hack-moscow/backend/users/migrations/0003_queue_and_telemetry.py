
from django.db import migrations

CREATE_TELEMETRY = r"""
CREATE TABLE IF NOT EXISTS telemetry_events (
    ts TIMESTAMPTZ NOT NULL DEFAULT now(),
    id BIGSERIAL NOT NULL,
    category TEXT NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    PRIMARY KEY (ts, id)
) PARTITION BY RANGE (ts);

-- дефолтная партиция (страховочная)
CREATE TABLE IF NOT EXISTS telemetry_events_default
    PARTITION OF telemetry_events DEFAULT;

-- индексы создаём на партиции (на родителе нельзя)
CREATE INDEX IF NOT EXISTS telemetry_events_default_ts_idx  ON telemetry_events_default (ts);
CREATE INDEX IF NOT EXISTS telemetry_events_default_cat_idx ON telemetry_events_default (category);
"""

CREATE_QUEUE = r"""
CREATE TABLE IF NOT EXISTS queue_jobs (
    id BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    locked_at TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'queued', -- queued|in_progress|done|failed
    attempts INT NOT NULL DEFAULT 0,
    payload JSONB NOT NULL
);
CREATE INDEX IF NOT EXISTS queue_jobs_status_idx ON queue_jobs(status, created_at);
"""

DROP_TELEMETRY = "DROP TABLE IF EXISTS telemetry_events CASCADE;"
DROP_QUEUE = "DROP TABLE IF EXISTS queue_jobs;"

class Migration(migrations.Migration):

    dependencies = [
        ('users', '0002_operatoridentity'),
    ]

    operations = [
        migrations.RunSQL(sql=CREATE_TELEMETRY, reverse_sql=DROP_TELEMETRY),
        migrations.RunSQL(sql=CREATE_QUEUE, reverse_sql=DROP_QUEUE),
    ]
