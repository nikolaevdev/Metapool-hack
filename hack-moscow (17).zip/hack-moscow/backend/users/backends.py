from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model

User = get_user_model()

class EmailOrUsernameModelBackend(ModelBackend):
    """
    Позволяет логиниться по email или username.
    """
    def authenticate(self, request, username=None, password=None, **kwargs):
        lookup = username or kwargs.get(User.USERNAME_FIELD)
        user = None
        # сначала по email
        if lookup:
            try:
                user = User.objects.get(email__iexact=lookup)
            except User.DoesNotExist:
                pass
        # затем по username
        if user is None and lookup:
            try:
                user = User.objects.get(username__iexact=lookup)
            except User.DoesNotExist:
                return None
        if user and user.check_password(password) and self.user_can_authenticate(user):
            return user
        return None
