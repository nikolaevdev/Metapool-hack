# users/models.py
from django.db import models
from django.utils import timezone
from django_otp.plugins.otp_totp.models import TOTPDevice
from django.contrib.auth.models import AbstractUser, Permission

class User(AbstractUser):
    """
    Кастомная модель пользователя на базе AbstractUser.
    username, password, is_staff, is_active, is_superuser, groups, user_permissions,
    last_login и date_joined уже есть в AbstractUser.
    """
    email      = models.EmailField('email address', unique=True)
    phone      = models.CharField(max_length=20, blank=True)
    avatar     = models.ImageField(upload_to='avatars/', blank=True, null=True)
    birth_date = models.DateField(blank=True, null=True)
    is_blocked = models.BooleanField(default=False)

    REQUIRED_FIELDS = ['username']
    USERNAME_FIELD  = 'email'

    def __str__(self):
        return self.email

    @property
    def is_twofa_enabled(self) -> bool:
        return TOTPDevice.objects.filter(user=self, confirmed=True).exists()


class Role(models.Model):
    """
    Дополнительная модель ролей (помимо Django Group).
    """
    name        = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    permissions = models.ManyToManyField(
        Permission,
        blank=True,
        related_name='roles',
        verbose_name='Права доступа'
    )

    class Meta:
        verbose_name = 'Роль'
        verbose_name_plural = 'Роли'

    def __str__(self):
        return self.name


class UserRole(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_roles')
    role = models.ForeignKey(Role, on_delete=models.CASCADE, related_name='role_users')

    class Meta:
        unique_together = ('user', 'role')
        verbose_name = 'Пользователь-Роль'
        verbose_name_plural = 'Пользователи-Роли'

    def __str__(self):
        return f'{self.user.email} ← {self.role.name}'


class RegistrationCode(models.Model):
    code       = models.CharField(max_length=64, unique=True)
    is_used    = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    def __str__(self):
        return self.code


class AuditLog(models.Model):
    user      = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action    = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Аудит-запись'
        verbose_name_plural = 'Аудит-журнал'
        ordering = ['-timestamp']

    def __str__(self):
        return f'[{self.timestamp:%Y-%m-%d %H:%M:%S}] {self.user}: {self.action}'

class Operator(models.Model):
    """
    Пользователь, которому разрешено отвечать через operator-бота.
    """
    user        = models.OneToOneField(User, on_delete=models.CASCADE)
    telegram_id = models.BigIntegerField(unique=True, db_index=True)
    is_active   = models.BooleanField(default=True)

    class Meta:
        permissions = [
            ("manage_operator", "Can add / delete operators"),
        ]

    def __str__(self) -> str:
        return f"{self.user.email} ({self.telegram_id})"


class OperatorIdentity(models.Model):
    """
    Канальные идентификаторы оператора (telegram/vk/webchat/...). Позволяет хранить несколько Id на одного оператора.
    """
    PROVIDER_CHOICES = [
        ("telegram", "Telegram"),
        ("vk", "VK"),
        ("webchat", "WebChat"),
    ]
    operator    = models.ForeignKey(Operator, on_delete=models.CASCADE, related_name="identities")
    provider    = models.CharField(max_length=32, choices=PROVIDER_CHOICES, default="telegram")
    external_id = models.CharField(max_length=128, db_index=True)
    is_active   = models.BooleanField(default=True)

    class Meta:
        unique_together = ("provider", "external_id")

    def __str__(self) -> str:
        return f"{self.provider}:{self.external_id} -> {self.operator.user.email}"
