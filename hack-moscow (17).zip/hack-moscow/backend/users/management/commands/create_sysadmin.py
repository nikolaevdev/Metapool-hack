from django.core.management.base import BaseCommand, CommandError
from backend.users.models import User, Role, UserRole

class Command(BaseCommand):
    help = 'Создаёт пользователя-администратора и назначает ему роль "Системный администратор" со всеми правами.'

    def add_arguments(self, parser):
        parser.add_argument('--email', required=True, type=str, help='Email нового пользователя')
        parser.add_argument('--username', required=True, type=str, help='Username нового пользователя')
        parser.add_argument('--password', required=True, type=str, help='Пароль для нового пользователя')

    def handle(self, *args, **options):
        email = options['email']
        username = options['username']
        password = options['password']

        if User.objects.filter(email=email).exists():
            self.stdout.write(self.style.WARNING(f'⚠ Пользователь с email {email} уже существует.'))
            return

        # 1) Создаём пользователя
        user = User.objects.create_user(
            email=email,
            username=username,
            password=password
        )
        # 2) Делаем его staff и superuser
        user.is_staff = True
        user.is_superuser = True
        user.save()

        # 3) Создаём роль "Системный администратор", если её нет
        role, created = Role.objects.get_or_create(
            name='Системный администратор',
            defaults={'description': 'Роль с полным набором прав.'}
        )
        if created:
            self.stdout.write(self.style.SUCCESS(f'✅ Роль "{role.name}" была создана.'))

        # 4) Назначаем роль пользователю
        ur, ur_created = UserRole.objects.get_or_create(user=user, role=role)
        if ur_created:
            self.stdout.write(self.style.SUCCESS(
                f'✅ Пользователь {email} назначен на роль "{role.name}".'
            ))
        else:
            self.stdout.write(self.style.WARNING(
                f'⚠ Пользователь {email} уже имеет роль "{role.name}".'
            ))

        self.stdout.write(self.style.SUCCESS(
            f'🎉 Пользователь-администратор {email} успешно создан.'
        ))
