from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType

class Command(BaseCommand):
    help = (
        "Создаёт Permission. "
        "Необходимо указать --name, --codename и один из вариантов: "
        "--content_type_id или (--app_label и --model)."
    )

    def add_arguments(self, parser):
        parser.add_argument(
            '--name',
            required=True,
            help='Полное название права (name)'
        )
        parser.add_argument(
            '--codename',
            required=True,
            help='Кодовое имя права (codename)'
        )
        group = parser.add_mutually_exclusive_group(required=True)
        group.add_argument(
            '--content_type_id',
            type=int,
            help='ID записи в django_content_type'
        )
        group.add_argument(
            '--app_label',
            help='Имя приложения (app_label) для ContentType'
        )
        parser.add_argument(
            '--model',
            help='Имя модели (model) для ContentType; обязательно при указании --app_label'
        )

    def handle(self, *args, **options):
        name = options['name']
        codename = options['codename']
        content_type = None

        # Выбор способа получения ContentType
        if options['content_type_id']:
            try:
                content_type = ContentType.objects.get(pk=options['content_type_id'])
            except ContentType.DoesNotExist:
                raise CommandError(f"ContentType с id={options['content_type_id']} не найден")
        else:
            app_label = options['app_label']
            model = options.get('model')
            if not model:
                raise CommandError("При указании --app_label обязательно указывать --model")
            try:
                content_type = ContentType.objects.get(app_label=app_label, model=model)
            except ContentType.DoesNotExist:
                raise CommandError(f"ContentType для {app_label}.{model} не найден")

        # Создаём или берём существующее право
        perm, created = Permission.objects.get_or_create(
            codename=codename,
            content_type=content_type,
            defaults={'name': name}
        )

        if created:
            self.stdout.write(self.style.SUCCESS(
                f"Permission '{codename}' успешно создан для {content_type.app_label}.{content_type.model}"
            ))
        else:
            self.stdout.write(self.style.WARNING(
                f"Permission '{codename}' уже существует для {content_type.app_label}.{content_type.model}"
            ))