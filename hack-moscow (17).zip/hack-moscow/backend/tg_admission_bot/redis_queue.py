import json, asyncio, uuid
import redis.asyncio as redis
from typing import Any

class RedisQueue:
    def __init__(self, url: str, name: str):
        self._r = redis.from_url(url, decode_responses=True)
        self._name = name

    async def push(self, item: dict[str, Any]) -> str:
        """Кладём задание в конец очереди, возвращаем job-id."""
        jid = item.setdefault("job_id", str(uuid.uuid4()))
        await self._r.rpush(self._name, json.dumps(item))
        return jid

    async def pop(self, timeout: int = 5) -> dict[str, Any] | None:
        """Блокирующее извлечение; None, если timeout."""
        res = await self._r.blpop(self._name, timeout=timeout)
        if res:
            return json.loads(res[1])
        return None

    async def push_operator_request(self, chat_id: int, transcript: str = "") -> str:
        """
        Спец-очередь для hand-off оператору.
        """
        job = {
            "job_id": str(uuid.uuid4()),
            "chat_id": chat_id,
            "transcript": transcript or "",
        }
        await self._r.rpush("operator_queue", json.dumps(job))
        return job["job_id"]
