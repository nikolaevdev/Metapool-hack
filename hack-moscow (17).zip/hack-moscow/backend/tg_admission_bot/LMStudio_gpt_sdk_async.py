"""
Синхронная обёртка над локальным API LM Studio
для работы с моделью по спецификации OpenAI-like (/v1/chat/completions).
"""

from __future__ import annotations

import logging
import os
from typing import List, Dict, Any

import requests
from pydantic import SecretStr
from tg_admission_bot.config import Settings

logger = logging.getLogger(__name__)

# ---------- параметры из окружения (.env) ----------
settings = Settings()

# URL и маршрут к вашему локальному серверу LM Studio
LM_STUDIO_URL = settings.LM_STUDIO_URL or "http://127.0.0.1:1234"
# Имя модели (например, "gemma-3-4b-it-qat")
MODEL_NAME = settings.LM_MODEL or "gemma-3-4b-it-qat"

MAX_TOKENS = settings.LM_MAX_TOKENS
TEMPERATURE = float(settings.LM_TEMPERATURE)
# ---------------------------------------------------

def _build_url(endpoint: str = "/v1/chat/completions") -> str:
    """
    Формирует полный URL для запроса.
    """
    base = LM_STUDIO_URL.rstrip("/")
    return f"{base}{endpoint}"

def _extract_secret(value: Any) -> str | None:
    """
    Если значение — SecretStr, возвращает секрет, иначе строку или None.
    """
    if isinstance(value, SecretStr):
        return value.get_secret_value()
    return str(value) if value is not None else None

def _build_headers() -> Dict[str, str]:
    """
    При необходимости добавьте сюда заголовки авторизации.
    """
    headers: Dict[str, str] = {
        "Content-Type": "application/json",
    }
    # Если у LM Studio настроен API-ключ, можно передавать его так:
    # api_key = _extract_secret(settings.LM_API_KEY)
    # if api_key:
    #     headers["Authorization"] = f"Bearer {api_key}"
    return headers

def _build_messages(context: str, question: str, raw_answer: str) -> List[Dict[str, str]]:
    """
    Формирует payload для LM Studio в формате OpenAI-like.
    """
    prompt_header = (
        "Вы — высокоэффективная LLM. Правила работы:\n"
        "1. Прими исходный текст ответа.\n"
        "2. Если исходный текст не содержит содержательного ответа на вопрос "
        "(например, сообщает, что нужных данных нет **или** содержит фразу "
        "'В данном контексте нет информации'), **верни пустую строку**.\n"
        "3. Иначе переформулируй его *максимально лаконично*, сохранив факты.\n"
        "4. Не добавляй новых фактов или мнений.\n"
        "5. Верни только итоговый переформулированный текст (без кавычек).\n"
        "6. Используй только наиболее точные сведения из контекста."
    )

    user_block = (
        f"Контекст:\n«{context}»\n\n"
        f"Вопрос абитуриента:\n«{question}»\n\n"
        f"Переформулируй ответ (или верни пустую строку):\n«{raw_answer}»"
    )

    return [
        {"role": "system", "content": prompt_header},
        {"role": "user",   "content": user_block},
    ]

def rewrite_answer(context: str, question: str, raw_answer: str) -> str:
    """
    Синхронно возвращает «сглаженный» ответ,
    используя локальный LM Studio API.
    """
    url = _build_url("/v1/chat/completions")
    payload = {
        "model": MODEL_NAME,
        "messages": _build_messages(context, question, raw_answer),
        "temperature": TEMPERATURE,
        "max_tokens": MAX_TOKENS,
        "stream": False,
    }

    try:
        response = requests.post(
            url,
            json=payload,
            headers=_build_headers(),
            timeout=60  # при необходимости увеличьте таймаут
        )
        response.raise_for_status()
    except requests.RequestException as e:
        logger.exception("Ошибка при вызове LM Studio API")
        raise RuntimeError(f"LM Studio request failed: {e}") from e

    data = response.json()
    # Ожидаем структуру OpenAI-like: {"choices":[{"message":{"content": "..."}}, ...], ...}
    choices = data.get("choices")
    if not choices:
        logger.error("Пустой ответ от LM Studio: %s", data)
        return ""
    first = choices[0].get("message", {})
    return first.get("content", "").strip()

