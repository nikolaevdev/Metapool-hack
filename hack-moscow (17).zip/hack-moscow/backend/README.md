# Backend Fullstack (Django + FastAPI)

Этот монорепо сохраняет **всю исходную FastAPI-функциональность** (роутеры из `fastapi_app/*`), 
и дополняет проект современными компонентами Django:

- Регистрация/подтверждение email (django-allauth + dj-rest-auth) с шаблонными письмами.
- Политика «обязательная 2FA» (переменная `REQUIRE_2FA`), используется в FastAPI `auth`-роутере.
- Импорт CSV/Excel → Celery задачи (`/api/imports/upload`).
- Индексация в Qdrant (sentence-transformers) — Celery задачи.
- Метрики Prometheus (`/metrics`).
- Dev и Prod Docker с отдельными сервисами `django` и `fastapi`, проксирование через Nginx.

## Запуск (Dev)

```bash
make up
# миграции/админ:
make migrate
make superuser
```

- FastAPI: http://localhost/api/… (Nginx → fastapi:9000)
- Django:   http://localhost/admin/  (если включите admin в INSTALLED_APPS)
- Метрики:  http://localhost/metrics

Импорт:
```bash
curl -H "Authorization: Bearer <TOKEN>" -F "file=@/path/to/pools.xlsx" http://localhost/api/imports/upload
```

## Запуск (Prod)

```bash
make up-prod
make migrate-prod
```

## Примечания

- Пользовательская модель: `users.User` (как в исходниках).
- Allauth письма: `templates/account/email/*`.
- Celery: сервис `celery`; брокер — Redis.
- Qdrant URL/ключ настраиваются через `.env`.


## Унификация FastAPI-ответов и OpenAPI
- Middleware **EnvelopeMiddleware** приводит все JSON-ответы к единому формату.
- Общие схемы: `fastapi_app/schemas/common.py`. Хелперы: `fastapi_app/utils/responses.py`.
- Swagger UI: `/api/docs`, OpenAPI: `/api/openapi.json`.

## HTTP-триггеры для Qdrant
- `POST /api/search/index/pool` — запустить индексацию вложений пула в Qdrant.
- `GET /api/search/tasks/{task_id}` — статус Celery-задачи.

## SPA под `/spa/`
- Dev: прокси на Vite (`frontend`: `http://frontend:5173`).
- Prod: отдача статики из `/usr/share/nginx/html/spa/` (положите туда сборку фронтенда).


## Подробные схемы Swagger
- Добавлены DTO-модели: `fastapi_app/schemas/dto.py` (UserOut, PoolOut, AttachmentOut, CategoryOut, RoleOut, PermissionOut, OperatorOut, RegistrationCodeOut, TokenOut, SearchResponseOut и пагинации).
- В каждый роутер внедрён `response_model=StandardResponse` (документирует конверт). При желании можно для ключевых методов проставить конкретный DTO во вложении `data` — это быстро доработаем.

## Расширенный поиск по пулам
- Индексация всех пулов с чанкингом: `datalake/qdrant_tasks.py::index_all_pools`.
- Новый эндпоинт: `POST /api/search/pool` — гибридный поиск (Postgres BM25 + Qdrant COSINE) с RRF-слиянием и опциональным rerank кросс-энкодером.
- Результаты агрегируются по `pool_id`, в `reason` возвращаются краткие объяснения (тип чанка/заголовок).



## Дополнения (v4)
- Эндпоинты индексации: `POST /api/search/index/all`, `POST /api/search/reindex/pool/{pool_id}`.
- Поиск по конкретному пулу: `POST /api/search/pool/{pool_id}`.
- Языковая детекция (langdetect) и выбор эмбеддинг-модели по языку (`backend/searching/*`).
- Типизированные `response_model` для списков/деталей CRUD роутов (users, pools, categories, attachments).


## ✅ SimpleJWT + Strict 2FA + TOTP + SSE (добавлено)
- `POST /api/auth/login` — логин c политикой обязательной 2FA (см. REQUIRE_2FA)
- `POST /api/auth/refresh` — обновление access по refresh
- `GET  /api/auth/me` — профиль и права
- `POST /api/auth/totp/enroll`, `POST /api/auth/totp/confirm?code=...`, `GET /api/auth/totp/devices`, `DELETE /api/auth/totp/devices/{id}`
- `GET  /api/tasks/stream` — SSE-стрим событий Celery через Redis

### Настройка
- В `settings.py` подключены `django_otp`, `django_otp.plugins.otp_totp`, `django_otp.middleware.OTPMiddleware`
- `SIMPLE_JWT` сконфигурирован, ключ — `SIMPLE_JWT_SIGNING_KEY` (если не указан — используется `SECRET_KEY`)
- `.env` — включите `REQUIRE_2FA=1`, настройте `REDIS_URL`, `TASKS_CHANNEL`

### Примечания
- Если у Вас уже были токены/роуты авторизации — используйте новые эндпоинты параллельно или перенаправьте фронт на них.


## ▶️ Docker (prod)
```bash
# собрать и поднять
docker compose -f docker-compose.prod.yml build
docker compose -f docker-compose.prod.yml up -d
# миграции
docker compose -f docker-compose.prod.yml exec api python backend/manage.py migrate
```

- API слушает `:8000` (Gunicorn+UvicornWorkers).
- SSE: `GET /api/tasks/stream` (проксировать через Nginx — поддерживает keep-alive/SSE по умолчанию).
- Celery worker использует Redis (`REDIS_URL` из `.env`).

## ▶️ Docker (dev, без копирования кода в образ)
```bash
docker compose -f docker-compose.dev.yml up
```
- Код монтируется с диска (`./:/app`), `uvicorn --reload`.
- Воркеры Celery аналогично.

## Nginx (опционально)
Для прод-окружения можно поставить обратный прокси:
- проксировать `/api/` на `api:8000`,
- включить заголовки для SSE (`proxy_set_header Connection ''; proxy_http_version 1.1;`).
