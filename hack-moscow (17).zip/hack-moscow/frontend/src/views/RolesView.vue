<template>
    <div class="p-6">
        <!-- Навигационные табы -->
        <div class="text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:text-gray-400 dark:border-gray-700 mb-6">
            <ul class="flex flex-wrap -mb-px">
                <li class="me-2">
                    <a
                            href="#"
                            @click.prevent="activeTab = 'roles'"
                            :class="[
              'inline-block p-4 border-b-2 rounded-t-lg',
              activeTab === 'roles'
                ? 'text-blue-600 border-blue-600 dark:text-blue-500 dark:border-blue-500'
                : 'border-transparent hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300'
            ]"
                    >
                        Роли
                    </a>
                </li>
                <li class="me-2">
                    <a
                            href="#"
                            @click.prevent="activeTab = 'permissions'"
                            :class="[
              'inline-block p-4 border-b-2 rounded-t-lg',
              activeTab === 'permissions'
                ? 'text-blue-600 border-blue-600 dark:text-blue-500 dark:border-blue-500'
                : 'border-transparent hover:text-gray-600 hover:border-gray-300 dark:hover:text-gray-300'
            ]"
                    >
                        Права
                    </a>
                </li>
            </ul>
        </div>

        <!-- Контент табов -->
        <div v-if="activeTab === 'roles'">
            <RoleTable />
        </div>
        <div v-else>
            <PermissionTable />
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref } from 'vue';

    import RoleTable from '../components/RoleTable.vue';
    import PermissionTable from '../components/PermissionTable.vue';
    // import { useHead } from '@vueuse/head';
    // useHead({
    //   title: 'Роли и Права - Админ Панель',
    // });

    const activeTab = ref<'roles' | 'permissions'>('roles');
</script>

<style scoped>
    /* При необходимости можно добавить дополнительные стили */
</style>
