<!-- src/components/UsersView.vue -->
<template>
    <div class="p-6">
        <h1 class="text-2xl font-semibold text-gray-800 dark:text-white mb-4">Управление пользователями</h1>
        <UserTable />
    </div>
</template>

<script setup lang="ts">
    import UserTable from '../components/UserTable.vue';

    // import { useHead } from '@vueuse/head';
    // useHead({
    //   title: 'Пользователи - Админ Панель',
    // });
</script>

<style scoped>
    /* При необходимости можно добавить дополнительные стили */
</style>