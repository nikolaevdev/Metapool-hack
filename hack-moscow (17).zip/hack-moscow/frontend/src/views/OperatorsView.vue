<!-- src/components/OperatorsView.vue -->
<template>
    <div class="p-6">
        <h1 class="text-2xl font-semibold text-gray-800 dark:text-white mb-4">
            Управление операторами
        </h1>
        <OperatorTable />
    </div>
</template>

<script setup lang="ts">
    import OperatorTable from '../components/OperatorTable.vue';
</script>

<style scoped>
    /* дополнительные стили при необходимости */
</style>
