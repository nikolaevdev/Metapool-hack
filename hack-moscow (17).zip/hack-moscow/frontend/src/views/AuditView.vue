<template>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">
            Журнал аудита
        </h1>
        <AuditLogTable />
    </div>
</template>

<script setup>
    import AuditLogTable from '../components/AuditLogTable.vue';
    // import { useHead } from '@vueuse/head';
    // useHead({
    //   title: 'Журнал Аудита - Админ Панель',
    // });
</script>
