<template>
  <div class="p-6">
    <h1 class="text-2xl font-semibold mb-4">Подключить 2FA (TOTP)</h1>
    <div class="bg-white border rounded p-4">
      <div v-if="qr_png" class="mb-4"><img :src="qr_png" alt="QR"></div>
      <p class="text-sm text-gray-600">Секрет: <code>{{ secret }}</code></p>
      <div class="mt-4 flex items-center gap-2">
        <input v-model="code" class="input w-40" placeholder="Код 123456" />
        <button class="btn" @click="confirm">Подтвердить</button>
      </div>
    </div>
  </div>
</template>
<script>
import { totpEnroll, totpConfirm } from '@/api'
export default{
  name:'TOTPEnrollView', data(){ return { qr_png:null, secret:null, code:'' } },
  async mounted(){ const r = await totpEnroll(); this.qr_png = r?.qr_png; this.secret = r?.secret },
  methods:{ async confirm(){ await totpConfirm(this.code); this.$router.push('/spa/security/2fa') } }
}
</script>
<style scoped>
.input{ padding:.5rem .75rem; border:1px solid #e5e7eb; border-radius:.5rem; }
.btn{ padding:.5rem .75rem; border:1px solid #e5e7eb; border-radius:.5rem; background:white }
</style>
