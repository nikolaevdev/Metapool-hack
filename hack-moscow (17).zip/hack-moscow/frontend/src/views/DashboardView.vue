<template>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">
            Панель управления
        </h1>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6">
                <div class="flex items-center">
                    <div class="p-3 bg-blue-500 rounded-full text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.084-1.28-.237-1.887M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.653.084-1.28.237-1.887m11.526 1.857A3 3 0 0014.474 18H9.526a3 3 0 00-2.833 2.143m6.306-6.306a7 7 0 10-9.9 0 7 7 0 009.9 0zM12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <div class="ml-4">
                        <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">Пользователи</p>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ usersCount }}</p>
                    </div>
                </div>
            </div>

            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6">
                <div class="flex items-center">
                    <div class="p-3 bg-green-500 rounded-full text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                    </div>
                    <div class="ml-4">
                        <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">Роли</p>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ rolesCount }}</p>
                    </div>
                </div>
            </div>

            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6">
                <div class="flex items-center">
                    <div class="p-3 bg-yellow-500 rounded-full text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 17v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2m14 0v-2a4 4 0 00-4-4h-1m-4-6h.01M12 12h.01M12 12a2 2 0 100-4 2 2 0 000 4zm7 0a2 2 0 100-4 2 2 0 000 4zm-7 1a1 1 0 100-2 1 1 0 000 2z" />
                        </svg>
                    </div>
                    <div class="ml-4">
                        <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">Записей аудита (сегодня)</p>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ auditTodayCount }}</p>
                    </div>
                </div>
            </div>
            <!-- Пулы -->
            <div class="bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6">
                <div class="flex items-center">
                    <div class="p-3 bg-purple-500 rounded-full text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 2C7.589 2 4 3.79 4 6s3.589 4 8 4 8-1.79 8-4-3.589-4-8-4z" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4 6v6c0 2.21 3.589 4 8 4s8-1.79 8-4V6" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M4 12v6c0 2.21 3.589 4 8 4s8-1.79 8-4v-6" />
                        </svg>
                    </div>
                    <div class="ml-4">
                        <p class="text-lg font-semibold text-gray-700 dark:text-gray-200">Пулы</p>
                        <p class="text-2xl font-bold text-gray-900 dark:text-white">{{ poolsCount }}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-8 bg-white dark:bg-gray-800 shadow-lg rounded-lg p-6">
            <h2 class="text-xl font-semibold text-gray-700 dark:text-white mb-4">Быстрые действия</h2>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                <router-link v-if="hasPermission('view_user')" to="/users" class="block p-4 text-center bg-blue-50 hover:bg-blue-100 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg smooth-transition">
                    <UserGroupIcon class="h-10 w-10 mx-auto mb-2 text-blue-500 dark:text-blue-400"/>
                    <span class="font-medium text-gray-700 dark:text-gray-200">Пользователи</span>
                </router-link>
                <router-link v-if="hasPermission('view_role')" to="/roles" class="block p-4 text-center bg-green-50 hover:bg-green-100 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg smooth-transition">
                    <ShieldCheckIcon class="h-10 w-10 mx-auto mb-2 text-green-500 dark:text-green-400"/>
                    <span class="font-medium text-gray-700 dark:text-gray-200">Роли</span>
                </router-link>
                <router-link to="/audit" class="block p-4 text-center bg-yellow-50 hover:bg-yellow-100 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg smooth-transition">
                    <DocumentTextIcon class="h-10 w-10 mx-auto mb-2 text-yellow-500 dark:text-yellow-400"/>
                    <span class="font-medium text-gray-700 dark:text-gray-200">Аудит</span>
                </router-link>
                <router-link to="/profile" class="block p-4 text-center bg-indigo-50 hover:bg-indigo-100 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg smooth-transition">
                    <UserCircleIcon class="h-10 w-10 mx-auto mb-2 text-indigo-500 dark:text-indigo-400"/>
                    <span class="font-medium text-gray-700 dark:text-gray-200">Мой Профиль</span>
                </router-link>
                <router-link to="/pools" v-if="hasPermission('view_pool')" class="block p-4 text-center bg-indigo-50 hover:bg-indigo-100 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-lg smooth-transition">
                    <FolderOpenIcon class="h-10 w-10 mx-auto mb-2 text-indigo-500 dark:text-indigo-400"/>
                    <span class="font-medium text-gray-700 dark:text-gray-200">Пуллы данных</span>
                </router-link>
            </div>
        </div>

    </div>
</template>

<script setup>
    import { computed, onMounted, ref } from 'vue';
    import { useStore } from 'vuex';
    import { UserGroupIcon, ShieldCheckIcon, DocumentTextIcon, UserCircleIcon, FolderOpenIcon } from '@heroicons/vue/24/outline';

    import api from '../api';

    const store = useStore();

    // Пример получения данных для дашборда
    // Вам нужно будет реализовать загрузку этих данных в соответствующих хранилищах
    const usersCount = computed(() => store.getters['user/allUsers']?.length || 0); // Простая заглушка, лучше получать total от API
    const rolesCount = computed(() => store.getters['role/allRoles']?.length || 0); // Аналогично
    const auditTodayCount = ref(0); // Это потребует специального запроса к API
    const poolsCount = ref(0);

    const hasPermission = (permission) => store.getters['auth/hasPermission'](permission);

    onMounted(async () => {
        // Загрузка данных, если они еще не загружены
        if (store.getters['user/allUsers']?.length === 0 && hasPermission('view_user')) {
            await store.dispatch('user/fetchUsers', { limit: 1 });
        }
        if (store.getters['role/allRoles']?.length === 0 && hasPermission('view_role')) {
            await store.dispatch('role/fetchRoles');
        }
        // Загрузка количества записей аудита за сегодня
        try {
            const today = new Date();
            const dateFrom = new Date(today.setHours(0,0,0,0)).toISOString();
            const dateTo = new Date(today.setHours(23,59,59,999)).toISOString();
            // Предполагаем, что API вернет массив или объект с total
            const auditResponse = await store.dispatch('audit/fetchAuditLogs', { date_from: dateFrom, date_to: dateTo, limit: 1 });
            auditTodayCount.value = store.getters['audit/auditPagination'].total || 0;
        } catch (error) {
            console.error("Failed to fetch today's audit count:", error);
        }

        try {
            const response = await api.getPools();
            poolsCount.value = Array.isArray(response.data) ? response.data.length : 0;
        } catch (error) {
            console.error('Не удалось загрузить количество пулов:', error);
        }
    });
</script>

<style scoped>
    /* Дополнительные стили для дашборда, если нужны */
</style>
