<template><div class="p-6">
  <h1 class="text-2xl font-semibold mb-4">Подтвердить 2FA</h1>
  <div class="bg-white border rounded p-4">
    <input v-model="code" class="input w-40" placeholder="Код 123456" />
    <button class="btn ml-2" @click="confirm">Подтвердить</button>
  </div>
</div></template>
<script>
import { totpConfirm } from '@/api'
export default{ name:'TOTPConfirmView', data(){ return { code:'' } }, methods:{ async confirm(){ await totpConfirm(this.code); this.$router.push('/spa/security/2fa') } } }
</script>
<style scoped>
.input{ padding:.5rem .75rem; border:1px solid #e5e7eb; border-radius:.5rem; }
.btn{ padding:.5rem .75rem; border:1px solid #e5e7eb; border-radius:.5rem; background:white }
</style>
