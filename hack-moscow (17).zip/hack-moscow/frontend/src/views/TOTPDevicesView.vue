<template>
  <div class="p-6">
    <h1 class="text-2xl font-semibold mb-4">2FA устройства</h1>
    <div class="mb-3"><RouterLink class="btn" to="/spa/security/2fa/enroll">Добавить устройство</RouterLink></div>
    <div class="bg-white rounded border">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-50"><tr><th class="px-3 py-2 text-left">ID</th><th class="px-3 py-2 text-left">Название</th><th></th></tr></thead>
        <tbody>
          <tr v-for="d in devices" :key="d.id" class="border-t">
            <td class="px-3 py-2">{{ d.id }}</td>
            <td class="px-3 py-2">{{ d.name || 'TOTP' }}</td>
            <td class="px-3 py-2 text-right"><button class="btn" @click="remove(d.id)">Удалить</button></td>
          </tr>
          <tr v-if="!devices.length"><td colspan="3" class="px-3 py-6 text-center text-gray-500">Нет устройств</td></tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
<script>
import { totpDevices, totpRemove } from '@/api'
export default {
  name:'TOTPDevicesView', data(){ return { devices: [] } },
  async mounted(){ this.devices = await totpDevices() || [] },
  methods:{ async remove(id){ if(!confirm('Удалить устройство?')) return; await totpRemove(id); this.devices = await totpDevices() || [] } }
}
</script>
<style scoped>
.btn{ padding:.4rem .7rem; border:1px solid #e5e7eb; border-radius:.5rem; background:white }
</style>
