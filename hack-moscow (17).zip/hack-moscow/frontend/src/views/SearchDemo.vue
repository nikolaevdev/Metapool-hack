<template>
    <div class="p-6">
        <h1 class="text-2xl font-semibold mb-4">Демонстрация продвинутого поиска по пулам</h1>

        <div class="flex items-center mb-4">
            <label for="pool" class="mr-2 font-medium">Пул:</label>
            <select
                    id="pool"
                    v-model="selectedPool"
                    class="border rounded p-2 mr-4"
            >
                <option :value="null">Последний созданный</option>
                <option
                        v-for="pool in pools"
                        :key="pool.id"
                        :value="pool.id"
                >
                    {{ pool.name }}
                </option>
            </select>

            <input
                    v-model="query"
                    @keyup.enter="performSearch"
                    type="text"
                    placeholder="Введите запрос"
                    class="flex-1 border rounded p-2 mr-4"
            />

            <button
                    @click="performSearch"
                    class="bg-blue-600 text-white rounded px-4 py-2 hover:bg-blue-700"
            >
                Искать
            </button>
        </div>

        <div v-if="searched && results.length === 0" class="text-gray-600">
            Ничего не найдено.
        </div>

        <ul v-if="results.length" class="space-y-4">
            <li
                    v-for="item in results"
                    :key="item.id"
                    class="border rounded p-4 shadow-sm"
            >
                <p><strong>ID вложения:</strong> {{ item.id }}</p>
                <p><strong>Описание:</strong> {{ item.description }}</p>
                <p v-if="item.content">
                    <strong>Содержимое (фрагмент):</strong>
                    {{ item.content.substring(0, 200) }}...
                </p>
                <a
                        v-if="item.file_url"
                        :href="item.file_url"
                        target="_blank"
                        class="text-blue-600 underline"
                >
                    Открыть файл
                </a>
            </li>
        </ul>
    </div>
</template>

<script setup>
    import { ref, onMounted } from 'vue'
    import api from '../api';

    import axios from 'axios'

    const pools = ref([])
    const selectedPool = ref(null)
    const query = ref('')
    const results = ref([])
    const searched = ref(false)

    onMounted(async () => {
        try {
            const resp = await api.getPools()
            pools.value = resp.data
        } catch (e) {
            console.error('Ошибка загрузки списка пулов:', e)
        }
    })

    async function performSearch() {
        if (!query.value.trim()) return

        // Формируем тело запроса
        const payload = { query: query.value }
        if (selectedPool.value) {
            payload.pool_id = selectedPool.value
        }

        try {
            // Отправляем POST на /pools_search/
            const resp = await api.postSearch(payload)
            results.value = resp.data
        } catch (e) {
            console.error('Ошибка при поиске:', e)
            results.value = []
        } finally {
            searched.value = true
        }
    }
</script>

<style scoped>
    /* при необходимости можно добавить дополнительные стили */
</style>
