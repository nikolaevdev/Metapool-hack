<!-- ========== src/views/PoolsView.vue ========== -->
<template>
    <div class="p-4">
        <!-- Нет пулов -->
        <div
                v-if="!pools.length && !isLoading"
                class="flex items-center justify-center h-[60vh]">
            <button
                    type="button"
                    class="btn btn-blue text-lg font-semibold"
                    @click="openPoolModal">
                Добавить пул
            </button>
        </div>

        <!-- Список пулов -->
        <div v-else>
            <button
                    type="button"
                    class="btn btn-blue absolute top-4 right-4"
                    @click="openPoolModal">
                Добавить новый пул
            </button>

            <ul class="space-y-2 mt-12">
                <li
                        v-for="p in pools"
                        :key="p.id"
                        @click="select(p)"
                        :class="['p-4 rounded cursor-pointer', selectedPool?.id === p.id ? 'bg-blue-50' : 'bg-white dark:bg-gray-800']">
                    {{ p.title }}
                </li>
            </ul>

            <!-- Управление категориями -->
            <div class="mt-6">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-xl font-semibold">Категории</h2>
                    <button
                            type="button"
                            class="btn btn-blue"
                            :disabled="!selectedPool"
                            @click="openCategoryModal">
                        Добавить категорию
                    </button>
                </div>

                <!-- Подсказка, если нет пула -->
                <div
                        v-if="!selectedPool"
                        role="alert"
                        class="text-sm text-red-600">
                    Сначала создайте пул
                </div>

                <!-- Само дерево категорий -->
                <CategoryTree
                        v-if="selectedPool"
                        :nodes="treeData"
                        @add="onAddCategory"
                        @delete="onDeleteCategory"
                        @attach="onAttachFile"
                />
            </div>
        </div>

        <!-- Модалка создания пула -->
        <div
                id="createPoolModal"
                tabindex="-1"
                aria-hidden="true"
                class="fixed inset-0 z-50 hidden overflow-y-auto p-4">
            <div class="relative m-auto max-w-md">
                <div class="rounded-lg bg-white p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-xl font-semibold">Новый пул</h3>
                        <button type="button" @click="modalPool.hide()">
                            <span class="sr-only">Закрыть</span>✕
                        </button>
                    </div>
                    <input
                            v-model="newPoolTitle"
                            type="text"
                            placeholder="Название пула"
                            class="w-full mb-4 border rounded px-3 py-2"
                    />
                    <div class="flex justify-end space-x-2">
                        <button class="btn btn-blue" @click="createPool">
                            Подтвердить
                        </button>
                        <button class="border rounded px-4 py-2" @click="modalPool.hide()">
                            Отменить
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Модалка создания категории -->
        <div
                id="createCategoryModal"
                tabindex="-1"
                aria-hidden="true"
                class="fixed inset-0 z-50 hidden overflow-y-auto p-4">
            <div class="relative m-auto max-w-md">
                <div class="rounded-lg bg-white p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-xl font-semibold">Новая категория</h3>
                        <button type="button" @click="modalCat.hide()">✕</button>
                    </div>
                    <input
                            v-model="newCategory.title"
                            type="text"
                            placeholder="Название категории"
                            class="w-full mb-2 border rounded px-3 py-2"
                    />
                    <select
                            v-model="newCategory.parentId"
                            class="w-full mb-4 border rounded px-3 py-2">
                        <option :value="null">Без родителя</option>
                        <option
                                v-for="c in flatCategories"
                                :key="c.id"
                                :value="c.id">
                            {{ c.title }}
                        </option>
                    </select>
                    <div class="flex justify-end space-x-2">
                        <button class="btn btn-blue" @click="createCategory">Подтвердить</button>
                        <button class="border rounded px-4 py-2" @click="modalCat.hide()">Отменить</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Модалка вложения файла -->
        <div
                id="attachFileModal"
                tabindex="-1"
                aria-hidden="true"
                class="fixed inset-0 z-50 hidden overflow-y-auto p-4">
            <div class="relative m-auto max-w-lg">
                <div class="rounded-lg bg-white p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-xl font-semibold">Прикрепить файл</h3>
                        <button type="button" @click="modalAttach.hide()">✕</button>
                    </div>
                    <!-- Dropzone -->
                    <div class="flex items-center justify-center mb-4">
                        <label
                                for="dropzone-file"
                                class="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed rounded-lg cursor-pointer">
                            <svg class="w-8 h-8 mb-2" fill="none" viewBox="0 0 20 16" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"/>
                            </svg>
                            <p class="text-sm mb-1"><span class="font-semibold">Нажмите для загрузки</span> или перетащите</p>
                            <p class="text-xs">PDF, PNG, JPG (MAX. 800×400px)</p>
                            <input id="dropzone-file"
                                   type="file"
                                   class="hidden"
                                   @change="onFileChange"/>
                        </label>
                    </div>
                    <input
                            v-model="attachDesc"
                            type="text"
                            placeholder="Описание"
                            class="w-full mb-2 border rounded px-3 py-2"
                    />
                    <input
                            v-model="attachKeys"
                            type="text"
                            placeholder="Ключевые слова"
                            class="w-full mb-4 border rounded px-3 py-2"
                    />
                    <div class="flex justify-end space-x-2">
                        <button class="btn btn-blue" @click="uploadAttachment">Загрузить</button>
                        <button class="border rounded px-4 py-2" @click="modalAttach.hide()">Отменить</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
    import { defineComponent, ref, computed, onMounted } from "vue";
    import { Modal, type ModalInterface } from "flowbite";
    import { useStore } from "vuex";
    import CategoryTree from "../components/CategoryTree.vue";

    interface Cat {
    id: number;
    title: string;
    parentId: number | null;
    }

    export default defineComponent({
    name: "PoolsView",
    components: { CategoryTree },
    setup() {
    const store = useStore();
    const pools = computed(() => store.getters["pools/pools"]);
    const selectedPool = computed(() => store.getters["pools/selectedPool"]);
    const flatCats = computed<Cat[]>(() => store.getters["pools/categories"]);
    const isLoading = computed(() => store.getters["pools/isLoading"]);

    // Формируем вложенное дерево
    const treeData = computed(() => {
    const map = new Map<number, any>();
    flatCats.value.forEach(c => map.set(c.id, { ...c, children: [] }));
    const roots: any[] = [];
    map.forEach(node => {
    if (node.parentId) map.get(node.parentId).children.push(node);
    else roots.push(node);
    });
    return roots;
    });

    // Для селекта родителя
    const flatCategories = computed(() => flatCats.value);

    // Модалки
    let modalPool: ModalInterface;
    let modalCat: ModalInterface;
    let modalAttach: ModalInterface;

    onMounted(() => {
    store.dispatch("pools/fetchPools");
    // создаём экземпляры Flowbite Modal
    modalPool = new Modal(
    document.querySelector("#createPoolModal")!,
    { backdrop: "dynamic", closable: true },
    { id: "createPoolModal", override: true }
    );
    modalCat = new Modal(
    document.querySelector("#createCategoryModal")!,
    { backdrop: "dynamic", closable: true },
    { id: "createCategoryModal", override: true }
    );
    modalAttach = new Modal(
    document.querySelector("#attachFileModal")!,
    { backdrop: "dynamic", closable: true },
    { id: "attachFileModal", override: true }
    );
    });

    // Новый пул
    const newPoolTitle = ref("");
    const openPoolModal = () => modalPool.show();
    const createPool = async () => {
    await store.dispatch("pools/createPool", { title: newPoolTitle.value });
    newPoolTitle.value = "";
    modalPool.hide();
    };

    // Выбор пула
    const select = (p: any) => {
    store.commit("pools/SET_SELECTED_POOL", p);
    store.dispatch("pools/fetchCategories");
    };

    // Новая категория
    const newCategory = ref<{ title: string; parentId: number | null }>({
    title: "",
    parentId: null,
    });
    const openCategoryModal = () => selectedPool.value
    ? modalCat.show()
    : null;
    const createCategory = async () => {
    await store.dispatch("pools/createCategory", {
    poolId: selectedPool.value.id,
    payload: newCategory.value,
    });
    newCategory.value = { title: "", parentId: null };
    modalCat.hide();
    };

    // Удаление категории
    const onDeleteCategory = async (node: Cat) => {
    await store.dispatch("pools/deleteCategory", node.id);
    };

    // Добавить вложение
    const selectedCat = ref<Cat | null>(null);
    const attachDesc = ref("");
    const attachKeys = ref("");
    const onAttachFile = (node: Cat) => {
    selectedCat.value = node;
    modalAttach.show();
    };
    const fileToUpload = ref<File | null>(null);
    const onFileChange = (e: Event) => {
    const files = (e.target as HTMLInputElement).files;
    if (files?.[0]) fileToUpload.value = files[0];
    };
    const uploadAttachment = async () => {
    if (!fileToUpload.value || !selectedCat.value) return;
    const fd = new FormData();
    fd.append("file", fileToUpload.value);
    fd.append("description", attachDesc.value);
    fd.append("keywords", attachKeys.value);
    await store.dispatch("pools/uploadAttachment", {
    categoryId: selectedCat.value.id,
    formData: fd,
    });
    attachDesc.value = "";
    attachKeys.value = "";
    fileToUpload.value = null;
    modalAttach.hide();
    };

    // Добавление подкатегории
    const onAddCategory = (node: Cat) => {
    newCategory.value.parentId = node.id;
    openCategoryModal();
    };

    return {
    pools,
    selectedPool,
    treeData,
    flatCategories,
    isLoading,
    newPoolTitle,
    openPoolModal,
    createPool,
    select,
    newCategory,
    openCategoryModal,
    createCategory,
    onAddCategory,
    onDeleteCategory,
    onAttachFile,
    attachDesc,
    attachKeys,
    onFileChange,
    uploadAttachment,
    };
    },
    });
</script>
