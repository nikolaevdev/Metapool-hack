<template>
    <div class="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-600 dark:from-gray-800 dark:via-gray-900 dark:to-black px-4">
        <div class="w-full max-w-md p-8 space-y-8 bg-white dark:bg-gray-800 shadow-2xl rounded-xl">
            <div class="text-center">
                <h1 class="text-4xl font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-5xl">
                    MetaPool
                </h1>
                <p class="mt-3 text-base text-gray-500 dark:text-gray-400">
                    Пожалуйста, войдите в свой аккаунт.
                </p>
            </div>
            <LoginForm />
        </div>
    </div>
</template>

<script setup>
    import LoginForm from '../components/LoginForm.vue';
    // Можно добавить мета-теги для страницы, если используется какая-либо библиотека для этого
    // import { useHead } from '@vueuse/head';
    // useHead({
    //   title: 'Вход - Админ Панель',
    // });
</script>

<style scoped>
    /* Можно добавить кастомные стили, если Tailwind недостаточно */
</style>
