<!-- src/components/DataManagement/DataManagement.vue -->
<template>
    <div class="container mx-auto px-4 py-8 dark:bg-gray-900">
        <h1 class="text-3xl font-bold text-gray-800 dark:text-white mb-6">Пулы данных</h1>
        <div class="flex gap-6">
            <!-- Sidebar: список пулов -->
            <aside
                    class="w-64 bg-white dark:bg-gray-800 dark:border dark:border-gray-700 rounded-lg shadow-sm p-4 sticky top-24 h-fit"
            >
                <div class="flex flex-col gap-4">
                    <button
                            @click="openCreatePool"
                            class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition"
                    >Создать пул</button>
                    <button
                            @click="openSearchPools"
                            class="border border-gray-300 dark:border-gray-600 bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 px-4 py-2 rounded-lg transition"
                    >Поиск пулов</button>
                    <button
                            @click="openImportExport"
                            class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition"
                    >Импорт/Экспорт</button>
                    <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                        <h3 class="font-semibold text-gray-900 dark:text-gray-100 mb-3">Пулы данных</h3>
                        <div class="space-y-2">
                            <div
                                    v-for="pool in pools"
                                    :key="pool.id"
                                    @click="onSelectPool(pool)"
                                    class="p-3 rounded-lg cursor-pointer flex flex-col transition-colors"
                                    :class="selectedPool?.id === pool.id
                  ? 'bg-indigo-50 dark:bg-indigo-900/20 border-l-4 border-indigo-500'
                  : 'hover:bg-gray-50 dark:hover:bg-gray-700'"
                            >
                                <h4 class="font-medium text-gray-800 dark:text-gray-100 truncate">{{ pool.name }}</h4>
                                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1 truncate">{{ pool.description }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Main: детали пула -->
            <main class="flex-1">
                <PoolDetail
                        v-if="selectedPool"
                        :pool="selectedPool"
                        :categories="categories"
                        :dataItems="dataItems"
                        :selectedCategory="selectedCategory"
                        @back="clearSelection"
                        @editPool="openEditPool"
                        @selectCategory="onSelectCategory"
                        @addData="openAddData"
                        @addCategory="openCategoryForm"
                        @editCategory="openEditCategory"
                        @editData="openEditData"
                        @deleteData="handleDeleteDataItem"
                />
                <div
                        v-else
                        class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-12 text-center"
                >
                    <p class="text-gray-600 dark:text-gray-400">Выберите пул данных слева, чтобы начать работу</p>
                </div>
            </main>
        </div>

        <!-- Модальные окна -->
        <EditPoolModal
                modalId="createPoolModal"
                ref="createPoolModal"
                title="Создать новый пул данных"
                @save="handleCreatePool"
        />
        <EditPoolModal
                modalId="editPoolModal"
                ref="editPoolModal"
                :pool="selectedPool"
                @save="handleUpdatePool"
                @delete="handleDeletePool"
        />
        <SearchPoolsModal
                modalId="searchPoolsModal"
                ref="searchPoolsModal"
                :pools="pools"
                @select="onSelectPool"
        />
        <EditCategoryModal
                modalId="editCategoryModal"
                ref="editCategoryModal"
                :category="selectedCategory"
                @save="handleUpdateCategory"
                @delete="handleDeleteCategory"
        />
        <EditDataItemModal
                modalId="editDataModal"
                ref="editDataModal"
                :item="editItem"
                @save="handleUpdateDataItem"
                @delete="handleDeleteDataItem"
        />
        <CategoryFormModal
                modalId="categoryFormModal"
                ref="categoryFormModal"
                :parentCategory="selectedCategory"
                @save="handleCreateCategory"
        />
        <DataFormModal
                modalId="dataFormModal"
                ref="dataFormModal"
                :categoryId="selectedCategory?.id"
                :poolId="selectedPool?.id"
                @save="handleCreateDataItem"
        />
        <ImportExportModal
                modalId="importExportModal"
                ref="importExportModal"
                :pools="pools"
                @importPools="handleImportPools"
                @exportPools="handleExportPools"
        />
    </div>
</template>

<script setup>

    import { ref, onMounted } from 'vue'
    import { useRouter } from 'vue-router'
    import api from '../api'

    import VirtualList from 'vue-virtual-scroller'

    const nextCursor = ref(null)
    const loadingMore = ref(false)
    async function loadMore(fetchFn){
        if(loadingMore.value || !nextCursor.value) return;
        loadingMore.value = true;
        const { items, next_cursor } = await fetchFn(nextCursor.value)
        nextCursor.value = next_cursor
        loadingMore.value = false;
    }

    import PoolDetail from '../components/DataManagement/PoolDetail.vue'
    import EditPoolModal from '../components/DataManagement/EditPoolModal.vue'
    import SearchPoolsModal from '../components/DataManagement/SearchPoolsModal.vue'
    import EditCategoryModal from '../components/DataManagement/EditCategoryModal.vue'
    import EditDataItemModal from '../components/DataManagement/EditDataItemModal.vue'
    import CategoryFormModal from '../components/DataManagement/CategoryFormModal.vue'
    import DataFormModal from '../components/DataManagement/DataFormModal.vue'
    import ImportExportModal from '../components/DataManagement/ImportExportModal.vue'

    const router = useRouter()

    // state
    const pools = ref([])
    const selectedPool = ref(null)
    const categories = ref([])
    const dataItems = ref([])
    const selectedCategory = ref(null)
    const editItem = ref(null)

    // modal refs
    const createPoolModal = ref(null)
    const editPoolModal = ref(null)
    const searchPoolsModal = ref(null)
    const editCategoryModal = ref(null)
    const editDataModal = ref(null)
    const categoryFormModal = ref(null)
    const dataFormModal = ref(null)
    const importExportModal = ref(null)

    onMounted(fetchPools)

    async function fetchPools() {
        const { data } = await api.getPools()
        pools.value = data
    }

    async function onSelectPool(pool) {
        selectedPool.value = pool
        selectedCategory.value = null
        const { data: cats } = await api.getCategories(pool.id)
        categories.value = cats
        dataItems.value = []  // очистка предыдущих данных
    }

    async function onSelectCategory(cat) {
        selectedCategory.value = cat
        const { data: atts } = await api.getAttachments(cat.id)
        dataItems.value = atts
    }

    function clearSelection() {
        selectedPool.value = null
        selectedCategory.value = null
    }

    // Pool CRUD
    function openCreatePool() { createPoolModal.value.show() }
    function openEditPool()   { selectedPool.value && editPoolModal.value.show() }
    function openSearchPools(){ searchPoolsModal.value.show() }

    async function handleCreatePool(payload) {
        const { data } = await api.createPool(payload)
        pools.value.unshift(data)  // добавить в начало списка
    }

    async function handleUpdatePool(payload) {
        const { data } = await api.updatePool(selectedPool.value.id, payload)
        const idx = pools.value.findIndex(p => p.id === data.id)
        if (idx !== -1) pools.value.splice(idx, 1, data)
        selectedPool.value = data
    }

    async function handleDeletePool() {
        await api.deletePool(selectedPool.value.id)
        pools.value = pools.value.filter(p => p.id !== selectedPool.value.id)
        clearSelection()
        router.push({ name: 'pools' })
    }

    // Category CRUD
    function openCategoryForm() { categoryFormModal.value.show() }
    function openEditCategory(cat){ selectedCategory.value=cat; editCategoryModal.value.show() }

    async function handleCreateCategory(payload) {
        const { data } = await api.createCategory(selectedPool.value.id, payload)
        categories.value.push(data)
    }

    async function handleUpdateCategory(payload) {
        const { data } = await api.updateCategory(selectedCategory.value.id, payload)
        const idx = categories.value.findIndex(c => c.id === data.id)
        if (idx !== -1) categories.value.splice(idx, 1, data)
        selectedCategory.value = data
    }

    async function handleDeleteCategory() {
        await api.deleteCategory(selectedCategory.value.id)
        categories.value = categories.value.filter(c => c.id !== selectedCategory.value.id)
        selectedCategory.value = null
    }

    // DataItem CRUD
    function openAddData()     { dataFormModal.value.show() }
    function openEditData(item){ editItem.value=item; editDataModal.value.show() }

    async function handleCreateDataItem({ file, content, description, keywords }) {
        const form = new FormData()
        if (file)    form.append('file', file)
        if (content) form.append('content', content)
        form.append('description', description||'')
        form.append('keywords',    keywords||'')
        form.append('category_id', selectedCategory.value.id)
        const { data } = await api.uploadAttachment(selectedCategory.value.id, form)
        dataItems.value.push(data)
    }

    async function handleUpdateDataItem(payload) {
        const { data } = await api.updateAttachment(editItem.value.id, payload)
        const idx = dataItems.value.findIndex(i=>i.id===data.id)
        if (idx!==-1) dataItems.value.splice(idx,1,data)
        editItem.value = data
    }

    async function handleDeleteDataItem(item) {
        const id = item?.id ?? editItem.value?.id
        if (!id) return
        await api.deleteAttachment(id)
        dataItems.value = dataItems.value.filter(i=>i.id!==id)
        if (selectedCategory.value?.id===item.category_id) {
            // убрать из текущей категории
            dataItems.value = dataItems.value.filter(i=>i.category_id!==item.category_id)
        }
    }

    // Import/Export
    function openImportExport() { importExportModal.value.show() }

    async function handleExportPools() {
        const { data } = await api.exportPools()
        const blob = new Blob([JSON.stringify(data)], { type:'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url; a.download='pools_export.json'; a.click()
        URL.revokeObjectURL(url)
    }

    async function handleImportPools(file) {
        const form = new FormData()
        form.append('file', file)
        await api.importPools(form)
        await fetchPools()
    }
</script>




