<template>
    <section class="mx-auto max-w-4xl px-4 py-8">
        <!-- Профиль -->
        <div
                class="mb-6 rounded-lg border border-gray-200 bg-white p-6 shadow-sm dark:border-gray-600 dark:bg-gray-700"
        >
            <h2 class="mb-4 text-2xl font-semibold text-gray-900 dark:text-white">
                Профиль
            </h2>

            <dl class="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                    <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                        Имя
                    </dt>
                    <dd class="text-lg font-semibold text-gray-900 dark:text-white">
                        {{ profile.firstName }}
                    </dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                        Фамилия
                    </dt>
                    <dd class="text-lg font-semibold text-gray-900 dark:text-white">
                        {{ profile.lastName }}
                    </dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                        E-mail
                    </dt>
                    <dd class="text-lg font-semibold text-gray-900 dark:text-white">
                        {{ profile.email }}
                    </dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500 dark:text-gray-400">
                        2FA
                    </dt>
                    <dd
                            class="inline-flex items-center space-x-2 text-lg font-semibold"
                    >
                        <span
                                :class="[
                                'inline-block h-2 w-2 rounded-full',
                                profile.isTwofaEnabled
                                    ? 'bg-emerald-500'
                                    : 'bg-red-500',
                            ]"
                        ></span>
                        <span
                                class="text-gray-900 dark:text-white"
                        >{{ profile.isTwofaEnabled ? 'Включена' : 'Выключена' }}</span
                        >
                    </dd>
                </div>
            </dl>

            <!-- Управляющие кнопки -->
            <div class="mt-6 flex flex-wrap gap-4">
                <button
                        type="button"
                        class="rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-medium text-white hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        @click="openEdit()"
                >
                    Редактировать
                </button>

                <button
                        type="button"
                        class="rounded-lg border border-gray-300 bg-white px-5 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-4 focus:ring-gray-200 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white dark:focus:ring-gray-700"
                        @click="open2FA()"
                >
                    {{ profile.isTwofaEnabled ? 'Управление 2FA' : 'Включить 2FA' }}
                </button>
            </div>
        </div>

        <!-- Модальные окна -->
        <ProfileForm
                ref="profileFormRef"
                :initial-profile="profile"
                @saved="fetchProfile"
        />
        <TwoFAModal
                ref="twoFAModalRef"
                :is-enabled="profile.isTwofaEnabled"
                @updated="fetchProfile"
        />
    </section>
</template>

<script setup lang="ts">
    import { ref, computed, watch, onMounted, defineProps, defineEmits, defineExpose } from 'vue';
    import { initFlowbite } from 'flowbite';
    import { useStore } from 'vuex';
    import ProfileEditModal from '@/components/ProfileForm.vue'; // модалка из предыдущего шага
    import TwoFAModal from '@/components/TwoFAModal.vue'

    const store = useStore();

    /** Текущий пользователь из authStore */
    const me = computed<any>(() => store.getters['auth/me'] || null);

    interface Profile {
        id: number;
        firstName: string;
        lastName: string;
        email: string;
        isTwofaEnabled: boolean;
    }

    const profile = ref<Profile>({
        id: 0,
        firstName: '',
        lastName: '',
        email: '',
        isTwofaEnabled: false,
    });

    const profileFormRef = ref<InstanceType<typeof ProfileForm> | null>(null);
    const twoFAModalRef = ref<InstanceType<typeof TwoFAModal> | null>(null);

    async function fetchProfile() {
        try {
            const { data } = await api.getProfile();
            profile.value = data;
        } catch (e) {
            console.error('Не удалось загрузить профиль', e);
        }
    }

    function openEdit() {
        profileFormRef.value?.open();
    }

    function open2FA() {
        twoFAModalRef.value?.open();
    }

    onMounted(() => {
        initFlowbite();
        fetchProfile();
    });
</script>