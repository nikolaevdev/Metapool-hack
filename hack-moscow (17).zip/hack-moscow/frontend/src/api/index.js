// src/api/index.js
import axios from "axios";
import store from "../store";

export const apiClient = axios.create({
baseURL: import.meta.env.VITE_API_URL || '/api',
headers: { Accept: "application/json" },
// все запросы посылают cookie (где лежит refresh_token)
withCredentials: true,
});

// Вставляем access_token в заголовки
apiClient.interceptors.request.use((config) => {
    const token = localStorage.getItem("access_token");
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Пути, которые не должны вызывать автorefresh
const AUTH_ROUTES_TO_IGNORE = [
    "/auth/login",
    "/auth/refresh",
    "/auth/logout",
];

apiClient.interceptors.response.use(
    (response) => response,
    async (error) => {
        const originalRequest = error.config;

        // при 401, если это не системный эндпоинт и ещё не делали retry
        if (
        error.response?.status === 401 &&
        !originalRequest._retry &&
        !AUTH_ROUTES_TO_IGNORE.some((p) =>
        originalRequest.url.includes(p)
        )
        ) {
            originalRequest._retry = true;
            try {
                // попробуем обновить access_token через refresh_token из cookie
                const newToken = await store.dispatch("auth/refreshToken");
                if (newToken) {
                    originalRequest.headers.Authorization = `Bearer ${newToken}`;
                    return apiClient(originalRequest);
                }
            } catch (refreshErr) {
                console.error("Token refresh failed:", refreshErr);
                // при неудаче logout внутри refreshToken
            }
        }

        import('../utils/notify').then(m => m.notify({type:'error', title:'Ошибка', message: (error?.message || 'Запрос отклонён')})).catch(()=>{});
        return Promise.reject(error);
    }
);

export default {
    // ---------- Auth ----------
    login: (credentials) => apiClient.post("/auth/login", credentials),
    logout: () => apiClient.post("/auth/logout"),
    refreshToken: () => apiClient.post("/auth/refresh"),

    // ---------- Profile & Permissions ----------
    getAuthProfile: () => apiClient.get("/auth/me"),
    getUserPermissions: () => apiClient.get("/auth/permissions"),

    getProfile: () => apiClient.get("/profile"),
    updateProfile: (data) => apiClient.put("/profile", data),

    // ---------- 2FA ----------
    enable2FA: (data) => apiClient.post("/profile/2fa/init", data),
    verify2FA: (data) => apiClient.post("/profile/2fa/verify", data),
    disable2FA: (data) => apiClient.post("/profile/2fa/disable", data),

    // ---------- Users ----------
    getUsers: (params) => apiClient.get("/users/", { params }),
    getUser: (id) => apiClient.get(`/users/${id}/`),
    createUser: (data) => apiClient.post("/users/", data),
    updateUser: (id, data) => apiClient.put(`/users/${id}/`, data),
    deleteUser: (id) => apiClient.delete(`/users/${id}/`),

    // ---------- Roles ----------
    // Roles
    getRoles: () => apiClient.get("/roles/"),
    getRole: id => apiClient.get(`/roles/${id}`),
    createRole: data => apiClient.post("/roles/", data),
    updateRole: (id, data) => apiClient.put(`/roles/${id}`, data),
    deleteRole: id => apiClient.delete(`/roles/${id}`),

    // Permissions
    getAllPermissions: () => apiClient.get("/permissions/"),
    createPermission: data => apiClient.post("/permissions/", data),
    updatePermission: (id, data) => apiClient.put(`/permissions/${id}`, data),
    deletePermission: id => apiClient.delete(`/permissions/${id}`),

    // ---------- Permissions (для админки) ----------
    getAllPermissions: () => apiClient.get("/permissions/"),

    // ---------- Audit Logs ----------
    getAuditLogs: (filters) => apiClient.get("/audit/", { params: filters }),

    // Pools
    getPools: (params) => apiClient.get("/pools/", { params }),
    getPool: (id) => apiClient.get(`/pools/${id}`),
    createPool: (data) => apiClient.post("/pools/", data),
    updatePool: (id, data) => apiClient.put(`/pools/${id}`, data),
    deletePool: (id) => apiClient.delete(`/pools/${id}`),

    // ---------- Import / Export ----------
    // Export a single pool as JSON blob
    exportPool: (id) => apiClient.get(`/pools/${id}/export`, { responseType: "blob" }),

    // Import into existing or new pool
    importPools: (formData) => apiClient.post("/pools/import", formData, {
        headers: { "Content-Type": "multipart/form-data" },
    }),

    // Categories
    getCategories: (poolId) => apiClient.get(`/categories/`, { params: { pool_id: poolId } }),
    createCategory: (poolId, data) => apiClient.post(`/categories/`, data, { params: { pool_id: poolId } }),
    updateCategory: (id, data) => apiClient.put(`/categories/${id}`, data),
    deleteCategory: (id) => apiClient.delete(`/categories/${id}`),

    // Attachments
    uploadAttachment(categoryId, data = {}) {
        const formData = new FormData();

        // обязательный параметр
        formData.append("category_id", categoryId);

        // текстовые поля (description, keywords, content)
        Object.entries(data).forEach(([key, value]) => {
            if (value !== undefined && value !== null && key !== "file") {
            formData.append(key, value);
            }
        });

        // файл, если передан
        if (data.file) {
            formData.append("file", data.file);      // File | Blob
        }

        // Axios присвоит boundary и Content-Type сам
        return apiClient.post("/attachments/", formData);
    },
    getAttachments(categoryId) {
        return apiClient.get(`/attachments/${categoryId}`);
    },
    updateAttachment(id, payload) {
        return apiClient.put(`/attachments/${id}`, payload);
    },
    deleteAttachment(id) {
        return apiClient.delete(`/attachments/${id}`);
    },

    // Search within a pool
    postSearch: (data) => apiClient.post('/pools_search/', data),

    getOperators: (params) => apiClient.get("/operators/", { params }),
    createOperator: (data) => apiClient.post("/operators/", data),
    deleteOperator: (id) => apiClient.delete(`/operators/${id}`),

};

export const fetchMe = () => apiClient.get('/auth/me');


export const totpEnroll = () => apiClient.post('/auth/totp/enroll');
export const totpConfirm = (code) => apiClient.post('/auth/totp/confirm?code='+encodeURIComponent(code));
export const totpDevices = () => apiClient.get('/auth/totp/devices');
export const totpRemove = (id) => apiClient.delete(`/auth/totp/devices/${id}`);


export const createAttachmentWithFile = (payload, file) => {
  const form = new FormData();
  Object.entries(payload || {}).forEach(([k,v]) => { if(v!==undefined && v!==null) form.append(k, v) })
  if (file) form.append('file', file);
  return apiClient.post('/attachments', form);
};
