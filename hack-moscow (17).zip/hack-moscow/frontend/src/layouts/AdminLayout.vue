<template>
    <div class="h-screen bg-gray-100 dark:bg-gray-900 font-sans">
        <!-- ================= NAVIGATION BAR ================= -->
        <nav class="fixed top-0 z-40 w-full bg-white border-b border-gray-200 dark:bg-gray-800 dark:border-gray-700">
            <div class="px-3 py-3 lg:px-5 lg:pl-3">
                <div class="flex items-center justify-between">
                    <div class="flex items-center justify-start">
                        <!-- Sidebar toggle button (mobile) -->
                        <button
                                @click="toggleSidebar"
                                class="inline-flex items-center p-2 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
                        >
                            <span class="sr-only">Open sidebar</span>
                            <Bars3Icon class="w-6 h-6" aria-hidden="true" />
                        </button>
                        <!-- Logo -->
                        <router-link to="/dashboard" class="flex ms-2 md:me-24 items-center">
                            <img src="https://flowbite.com/docs/images/logo.svg" class="h-8 me-3" alt="Admin Panel Logo" />
                            <span class="self-center text-xl font-semibold sm:text-2xl whitespace-nowrap dark:text-white">
                MetaPool
              </span>
                        </router-link>
                    </div>
                    <div class="flex items-center">
                        <!-- Theme toggle -->
                        <button @click="toggleDarkMode" class="text-gray-500 dark:text-gray-400 focus:outline-none mr-4">
                            <SunIcon v-if="isDarkMode" class="h-6 w-6" aria-hidden="true" />
                            <MoonIcon v-else class="h-6 w-6" aria-hidden="true" />
                        </button>
                        <!-- User dropdown -->
                        <div class="relative">
                            <button
                                    @click="dropdownOpen = !dropdownOpen"
                                    class="flex text-sm bg-gray-800 rounded-full focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600"
                            >
                                <span class="sr-only">Open user menu</span>
                                <img class="w-8 h-8 rounded-full" :src="userAvatar" alt="User avatar" />
                            </button>
                            <transition
                                    enter-active-class="transition ease-out duration-100"
                                    enter-from-class="transform opacity-0 scale-95"
                                    enter-to-class="transform opacity-100 scale-100"
                                    leave-active-class="transition ease-in duration-75"
                                    leave-from-class="transform opacity-100 scale-100"
                                    leave-to-class="transform opacity-0 scale-95"
                            >
                                <div
                                        v-if="dropdownOpen"
                                        class="absolute right-0 mt-2 w-48 bg-white divide-y divide-gray-100 rounded-sm shadow-sm dark:bg-gray-700 dark:divide-gray-600"
                                >
                                    <div class="px-4 py-3">
                                        <p class="text-sm text-gray-900 dark:text-white">
                                            {{ currentUser?.username || 'User' }}
                                        </p>
                                        <p class="text-sm font-medium text-gray-900 truncate dark:text-gray-300">
                                            {{ currentUser?.email || 'email@example.com' }}
                                        </p>
                                    </div>
                                    <ul class="py-1 text-sm text-gray-700 dark:text-gray-200">
                                        <li>
                                            <router-link
                                                    to="/dashboard"
                                                    @click="dropdownOpen = false"
                                                    class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"
                                            >
                                                Дашборд
                                            </router-link>
                                        </li>
                                        <li>
                                            <router-link
                                                    to="/profile"
                                                    @click="dropdownOpen = false"
                                                    class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white"
                                            >
                                                Профиль
                                            </router-link>
                                        </li>
                                        <li>
                                            <a
                                                    href="#"
                                                    @click.prevent="handleLogout"
                                                    class="block px-4 py-2 text-red-500 hover:bg-gray-100 dark:hover:bg-gray-600"
                                            >
                                                Выход
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </transition>
                        </div>
                    </div>
                </div>
            </div>
        </nav>

        <!-- ================= DESKTOP SIDEBAR ================= -->
        <aside
                :class="[
        'fixed top-0 left-0 z-30 h-screen bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-600 transition-all duration-300 ease-in-out md:block hidden',
        sidebarOpen ? 'w-64' : 'w-20'
      ]"
        >
            <div class="h-full px-3 pb-4 overflow-y-auto pt-20">
                <ul class="space-y-2 font-medium">
                    <li v-for="item in visibleMenuItems" :key="item.name">
                        <router-link
                                :to="item.path"
                                class="flex items-center p-2 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group"
                                active-class="bg-gray-100 dark:bg-gray-700"
                        >
                            <component
                                    :is="item.icon"
                                    class="w-6 h-6 text-gray-400 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                                    active-class="text-gray-900 dark:text-white"
                            />
                            <span v-if="sidebarOpen" class="ms-3">{{ item.title }}</span>
                        </router-link>
                    </li>
                </ul>
            </div>
        </aside>

        <!-- ================= MOBILE SIDEBAR ================= -->
        <aside
                :class="[
        'fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-800 transform transition-transform duration-300 ease-in-out md:hidden',
        mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      ]"
        >
            <div class="flex items-center justify-between h-20 px-6 border-b border-gray-200">
                <router-link to="/dashboard" class="text-xl font-semibold text-gray-700 dark:text-gray-300">
                    MetaPool
                </router-link>
                <button @click="mobileSidebarOpen = false" class="text-gray-500 dark:text-gray-400 focus:outline-none">
                    <XMarkIcon class="h-6 w-6" aria-hidden="true" />
                </button>
            </div>
            <nav class="flex-grow px-3 py-4 overflow-y-auto">
                <ul class="space-y-2 font-medium">
                    <li v-for="item in visibleMenuItems" :key="item.name + '-mobile'">
                        <router-link
                                :to="item.path"
                                @click="mobileSidebarOpen = false"
                                class="flex items-center p-2 text-gray-900 rounded-sm dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group"
                                active-class="bg-blue-500 text-white dark:bg-blue-600 dark:text-white"
                        >
                            <component
                                    :is="item.icon"
                                    class="w-5 h-5 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white"
                                    aria-hidden="true"
                            />
                            <span class="ms-3">{{ item.title }}</span>
                        </router-link>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- ================= OVERLAY (MOBILE) ================= -->
        <div
                :class="[
        'fixed inset-0 z-30 bg-black bg-opacity-50 transition-opacity md:hidden',
        mobileSidebarOpen ? 'opacity-50 pointer-events-auto' : 'opacity-0 pointer-events-none'
      ]"
                @click="mobileSidebarOpen = false"
        ></div>

        <!-- ================= CONTENT AREA ================= -->
        <div :class="sidebarOpen ? 'md:ml-64' : 'md:ml-20'" class="pt-16">
            <main class="overflow-x-hidden overflow-y-auto">
                    <router-view v-slot="{ Component, route }">
                        <transition name="fade-page" mode="out-in">
                            <div :key="route.name">
                                <component :is="Component" />
                            </div>
                        </transition>
                    </router-view>
            </main>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed, onMounted, onUnmounted, watch, markRaw } from 'vue';
    import { useStore } from 'vuex';
    import { useRouter, useRoute } from 'vue-router';
    import {
    HomeIcon,
    UserGroupIcon,
    ShieldCheckIcon,
    DocumentTextIcon,
    UserCircleIcon,
    Bars3Icon,
    XMarkIcon,
    SunIcon,
    MoonIcon
    } from '@heroicons/vue/24/outline';
    import { initFlowbite } from "flowbite";

    const store = useStore();
    const router = useRouter();

    const sidebarOpen = ref(true);
    const mobileSidebarOpen = ref(false);
    const dropdownOpen = ref(false);
    const isDarkMode = ref(localStorage.getItem('darkMode') === 'true');

    const currentUser = computed(() => store.getters['auth/currentUser']);
    const userAvatar = computed(() =>
    currentUser.value?.avatar_url
    ? currentUser.value.avatar_url
    : `https://ui-avatars.com/api/?name=${currentUser.value?.username || 'User'}&background=random`
    );

    const menuItems = [
        { name: 'Dashboard', title: 'Дашборд', path: '/dashboard', icon: markRaw(HomeIcon) },
        { name: 'Profile', title: 'Профиль', path: '/profile', icon: markRaw(UserCircleIcon) },
        { name: 'Users', title: 'Пользователи', path: '/users', icon: markRaw(UserGroupIcon), permission: 'view_user' },
        { name: 'Roles', title: 'Роли и Права', path: '/roles', icon: markRaw(ShieldCheckIcon), permission: 'view_role' },
        { name: 'Audit', title: 'Журнал Аудита', path: '/audit', icon: markRaw(DocumentTextIcon) },
        { name: 'MetaPool', title: 'Пуллы данных', path: '/pools', icon: markRaw(DocumentTextIcon), permission: 'view_pool' },
        { name: 'Operators', title: 'Операторы', path: '/operators', icon: markRaw(DocumentTextIcon), permission: 'manage_operator' },

    ];

    const hasPermission = perm => store.getters['auth/hasPermission'](perm);
    const visibleMenuItems = computed(() =>
    menuItems.filter(i => !i.permission || hasPermission(i.permission))
    );

    const handleLogout = async () => {
        await store.dispatch('auth/logout');
        dropdownOpen.value = false;
        mobileSidebarOpen.value = false;
        router.push('/login');
    };

    const toggleSidebar = () => {
        if (window.innerWidth < 768) {
            mobileSidebarOpen.value = !mobileSidebarOpen.value;
        } else {
            sidebarOpen.value = !sidebarOpen.value;
        }
    };

    const toggleDarkMode = () => {
        isDarkMode.value = !isDarkMode.value;
        document.documentElement.classList.toggle('dark', isDarkMode.value);
        localStorage.setItem('darkMode', String(isDarkMode.value));
    };

    const onResize = () => {
        if (window.innerWidth >= 768) mobileSidebarOpen.value = false;
    };

    const handleClickOutside = e => {
        const dropdown = document.querySelector('.dropdown-menu');
        if (
        dropdownOpen.value &&
        dropdown &&
        !dropdown.contains(e.target) &&
        !e.target.closest('button')
        ) {
            dropdownOpen.value = false;
        }
    };

    onMounted(() => {
        document.documentElement.classList.toggle('dark', isDarkMode.value);
        window.addEventListener('resize', onResize, { passive: true });
        document.addEventListener('click', handleClickOutside, true);
        onResize();
        initFlowbite();
    });

    onUnmounted(() => {
        window.removeEventListener('resize', onResize);
        document.removeEventListener('click', handleClickOutside, true);
    });

    watch(dropdownOpen, open => {
        if (open) document.addEventListener('click', handleClickOutside, true);
        else document.removeEventListener('click', handleClickOutside, true);
    });
</script>

<style scoped>
    .fade-page-enter-active,
    .fade-page-leave-active {
        transition: opacity 0.2s ease-out;
    }
    .fade-page-enter-from,
    .fade-page-leave-to {
        opacity: 0;
    }
</style>

