// src/main.js
import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "./assets/main.css";

// Flowbite Vue
// Инициализация Flowbite JS (для dropdown, tabs и т.п.)
import { initFlowbite } from "flowbite";
import Notifications from '@kyvg/vue3-notification'

const app = createApp(App);

app.use(store);
app.use(router);
app.use(Notifications);

// Если в другой вкладке удалили access_token — делаем logout
window.addEventListener("storage", (event) => {
    if (event.key === "access_token" && !event.newValue) {
        store.dispatch("auth/logout");
    }
});

// Инициализируем авторизацию и монтируем приложение
store.dispatch("auth/initAuth").then(() => {
    app.mount("#app");
    initFlowbite();
});

