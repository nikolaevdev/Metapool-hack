import { createRouter, createWebHistory } from 'vue-router';
import store from '../store'; // Хранилище Vuex
import AdminLayout from '../layouts/AdminLayout.vue';
import DashboardView from '../views/DashboardView.vue';
import LoginView from '../views/LoginView.vue';
import ProfileView from '../views/ProfileView.vue';
import UsersView from '../views/UsersView.vue';
import RolesView from '../views/RolesView.vue';
import AuditView from '../views/AuditView.vue';
import DataManagement from "../views/DataManagement.vue";
import NotFoundView from '../views/NotFoundView.vue';
import SearchDemo from "../views/SearchDemo.vue";
import Operators from "../views/OperatorsView.vue";
import TOTPDevicesView from "../views/TOTPDevicesView.vue";
import TOTPEnrollView from "../views/TOTPEnrollView.vue";
import TOTPConfirmView from "../views/TOTPConfirmView.vue";

const routes = [
    {
        path: '/login',
        name: 'login',
        component: LoginView,
        meta: { requiresGuest: true } // Доступно только неаутентифицированным
    },
    {
        path: '/',
        component: AdminLayout, // Основной макет для защищенных страниц
        meta: { requiresAuth: true }, // Эти маршруты требуют аутентификации
        redirect: '/dashboard', // По умолчанию перенаправляем на дашборд
        children: [
            { path: 'security/2fa', name: '2FA', component: TOTPDevicesView, meta: { requiresAuth: true } },
            { path: 'security/2fa/enroll', name: '2FAEnroll', component: TOTPEnrollView, meta: { requiresAuth: true } },
            { path: 'security/2fa/confirm', name: '2FAConfirm', component: TOTPConfirmView, meta: { requiresAuth: true } },
            {
                path: 'dashboard',
                name: 'Dashboard',
                component: DashboardView,
            },
            {
                path: 'profile',
                name: 'Profile',
                component: ProfileView,
            },
            {
                path: 'users',
                name: 'Users',
                component: UsersView,
                meta: { requiresPermission: 'view_user' } // Пример права
            },
            {
                path: 'roles',
                name: 'Roles',
                component: RolesView,
                meta: { requiresPermission: 'view_role' } // Пример права
            },
            {
                path: 'audit',
                name: 'Audit',
                component: AuditView,
                // Пример права, если нужно: meta: { requiresPermission: 'view_log' }
            },
            {
                path: 'pools',
                name: 'Pools',
                component: DataManagement,
                meta: { requiresPermission: 'view_pool' },
            },
            {
                path: 'search',
                name: 'Search',
                component: SearchDemo,
            },
            {
                path: 'operators',
                name: 'Operators',
                component: Operators,
            },
        ]
    },
    {
        path: '/:pathMatch(.*)*',
        name: 'NotFound',
        component: NotFoundView,
        meta: { title: 'Страница не найдена' }
    },
];

const router = createRouter({
history: createWebHistory('/spa/'), // Используем HTML5 History API
routes,
scrollBehavior(to, from, savedPosition) {
    // Прокрутка вверх при переходе на новую страницу
    if (savedPosition) {
        return savedPosition;
    } else {
        return { top: 0 };
    }
}
});

// Навигационный страж (Navigation Guard)
router.beforeEach(async (to, from, next) => {
const isAuthenticated = store.getters['auth/isAuthenticated'];
const userPermissions = store.getters['auth/userPermissions']; // Получаем права из Vuex

// Если состояние пользователя еще не инициализировано (например, после перезагрузки с токеном)
if (store.state.auth.accessToken && !store.state.auth.user && store.state.auth.status !== 'loading') {
await store.dispatch('auth/initAuth'); // Дожидаемся инициализации
// После initAuth, isAuthenticated и userPermissions могут измениться, поэтому получаем их заново
// isAuthenticated = store.getters['auth/isAuthenticated'];
// userPermissions = store.getters['auth/userPermissions'];
// Однако, лучше полагаться на то, что isAuthenticated вернет актуальное значение после initAuth
}


const requiredPermission = to.meta.requiresPermission;

if (to.meta.requiresAuth) {
if (!isAuthenticated) {
// Если маршрут требует аутентификации, а пользователь не вошел,
// перенаправляем на страницу логина. Сохраняем путь для редиректа после логина.
next({ name: 'login', query: { redirect: to.fullPath } });
} else {
// Пользователь аутентифицирован. Проверяем права, если они требуются.
if (requiredPermission) {
// Используем getter hasPermission из authStore
const hasAccess = store.getters['auth/hasPermission'](requiredPermission);
if (hasAccess) {
// permissions check
const need = to.meta && to.meta.permission
if (store && store.state && store.state.auth) {
  const perms = store.state.auth.permissions || []
  if (!perms.length && store.state.auth.accessToken) {
    try { await store.dispatch('auth/loadMe') } catch(e){}
  }
  if (need) {
    const have = (store.state.auth.permissions || []).includes(need)
    if (!have) return next({ name: 'dashboard' })
  }
}
next();
 // Доступ разрешен
} else {
console.warn(`Доступ запрещен: недостаточно прав (${requiredPermission}) для маршрута ${to.path}`);
// Пользователь аутентифицирован, но не имеет прав.
// Можно перенаправить на страницу "Доступ запрещен" или на дашборд.
next({ name: 'Dashboard' }); // Или на специальную страницу ошибки доступа
}
} else {
// permissions check
const need = to.meta && to.meta.permission
if (store && store.state && store.state.auth) {
  const perms = store.state.auth.permissions || []
  if (!perms.length && store.state.auth.accessToken) {
    try { await store.dispatch('auth/loadMe') } catch(e){}
  }
  if (need) {
    const have = (store.state.auth.permissions || []).includes(need)
    if (!have) return next({ name: 'dashboard' })
  }
}
next();
 // Маршрут требует аутентификации, но не специфичных прав
}
}
} else if (to.meta.requiresGuest) {
// Если маршрут для гостей (например, /login), а пользователь уже вошел,
// перенаправляем на дашборд.
if (isAuthenticated) {
next({ name: 'Dashboard' });
} else {
// permissions check
const need = to.meta && to.meta.permission
if (store && store.state && store.state.auth) {
  const perms = store.state.auth.permissions || []
  if (!perms.length && store.state.auth.accessToken) {
    try { await store.dispatch('auth/loadMe') } catch(e){}
  }
  if (need) {
    const have = (store.state.auth.permissions || []).includes(need)
    if (!have) return next({ name: 'dashboard' })
  }
}
next();

}
} else {
// Для маршрутов без специальных мета-полей (например, страница 404)
// permissions check
const need = to.meta && to.meta.permission
if (store && store.state && store.state.auth) {
  const perms = store.state.auth.permissions || []
  if (!perms.length && store.state.auth.accessToken) {
    try { await store.dispatch('auth/loadMe') } catch(e){}
  }
  if (need) {
    const have = (store.state.auth.permissions || []).includes(need)
    if (!have) return next({ name: 'dashboard' })
  }
}
next();

}
});

export default router;
