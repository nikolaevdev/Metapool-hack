export function notify(payload){
  try { window.dispatchEvent(new CustomEvent('notify', { detail: payload })) } catch{}
}
