// ========== src/store/pools.js ==========
import api from "../api";
import { createStore } from "vuex";

export default {
    namespaced: true,
    state: () => ({
        pools: [],
        selectedPool: null,
        categories: [],
        status: "", // 'loading' | 'success' | 'error'
    }),
    mutations: {
        SET_STATUS(state, s) { state.status = s; },
        SET_POOLS(state, list) { state.pools = list; },
        SET_SELECTED_POOL(state, p) { state.selectedPool = p; },
        SET_CATEGORIES(state, cats) { state.categories = cats; },
        ADD_POOL(state, p) { state.pools.unshift(p); },
        REMOVE_POOL(state, id) {
            state.pools = state.pools.filter(x => x.id !== id);
            if (state.selectedPool?.id === id) state.selectedPool = null;
        },
    },
    actions: {
        async fetchPools({ commit }) {
            commit("SET_STATUS", "loading");
            try {
                const { data } = await api.getPools();
                commit("SET_POOLS", data);
                commit("SET_STATUS", "success");
            } catch (e) {
                commit("SET_STATUS", "error");
                console.error(e);
            }
        },
        async createPool({ commit }, payload) {
            commit("SET_STATUS", "loading");
            const { data } = await api.createPool(payload);
            commit("ADD_POOL", data);
            commit("SET_STATUS", "success");
            return data;
        },
        async deletePool({ commit }, id) {
            commit("SET_STATUS", "loading");
            await api.deletePool(id);
            commit("REMOVE_POOL", id);
            commit("SET_STATUS", "success");
        },
        async fetchCategories({ commit, state }) {
            if (!state.selectedPool) return;
            commit("SET_STATUS", "loading");
            const { data } = await api.getCategories(state.selectedPool.id);
            commit("SET_CATEGORIES", data);
            commit("SET_STATUS", "success");
        },
        async createCategory({ dispatch }, { poolId, payload }) {
            await api.createCategory(poolId, payload);
            // пересоберём дерево
            return dispatch("fetchCategories");
        },
        async deleteCategory({ dispatch }, id) {
            await api.deleteCategory(id);
            return dispatch("fetchCategories");
        },
        async uploadAttachment({ dispatch, state }, { categoryId, formData }) {
            await api.uploadAttachment(categoryId, formData);
            // можно обновить вложения, если понадобится
            return dispatch("fetchCategories");
        },
    },
    getters: {
        pools: s => s.pools,
        selectedPool: s => s.selectedPool,
        categories: s => s.categories,
        isLoading: s => s.status === "loading",
    },
};
