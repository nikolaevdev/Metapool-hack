// src/store/roleStore.js

import api from '../api';

const state = {
    // Роли
    roles: [],             // список всех ролей
    selectedRole: null,    // подробности выбранной роли

    // Права
    permissions: [],        // все доступные в системе права
    selectedPermission: null, // подробности выбранного права

    // статус операций ('loading' | 'success' | 'error')
    status: '',
};

const mutations = {
    // Общий статус
    SET_STATUS(state, status) {
        state.status = status;
    },

    // --- Мутации для ролей ---
    SET_ROLES(state, roles) {
        state.roles = roles;
    },
    SET_SELECTED_ROLE(state, role) {
        state.selectedRole = role;
    },
    ADD_ROLE(state, role) {
        state.roles.unshift(role);
    },
    UPDATE_ROLE(state, updated) {
        const idx = state.roles.findIndex(r => r.id === updated.id);
        if (idx !== -1) {
            state.roles.splice(idx, 1, updated);
        }
        if (state.selectedRole?.id === updated.id) {
            state.selectedRole = updated;
        }
    },
    REMOVE_ROLE(state, id) {
        state.roles = state.roles.filter(r => r.id !== id);
        if (state.selectedRole?.id === id) {
            state.selectedRole = null;
        }
    },

    // --- Мутации для прав ---
    SET_PERMISSIONS(state, perms) {
        state.permissions = perms;
    },
    SET_SELECTED_PERMISSION(state, perm) {
        state.selectedPermission = perm;
    },
    ADD_PERMISSION(state, perm) {
        state.permissions.unshift(perm);
    },
    UPDATE_PERMISSION(state, updated) {
        const idx = state.permissions.findIndex(p => p.id === updated.id);
        if (idx !== -1) {
            state.permissions.splice(idx, 1, updated);
        }
        if (state.selectedPermission?.id === updated.id) {
            state.selectedPermission = updated;
        }
    },
    REMOVE_PERMISSION(state, id) {
        state.permissions = state.permissions.filter(p => p.id !== id);
        if (state.selectedPermission?.id === id) {
            state.selectedPermission = null;
        }
    },
};

const actions = {
    // --- Роли ---

    // Загрузить все роли
    async fetchRoles({ commit }) {
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.getRoles();
            commit('SET_ROLES', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (err) {
            commit('SET_STATUS', 'error');
            commit('SET_ROLES', []);
            console.error('fetchRoles error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Загрузить одну роль
    async fetchRole({ commit, state }, roleId) {
        commit('SET_STATUS', 'loading');
        try {
            // Если есть API GET /roles/{id}, можно использовать:
            // const { data } = await api.getRole(roleId);
            // иначе ищем в локальном списке:
            const role = state.roles.find(r => r.id === Number(roleId));
            if (!role) throw new Error(`Role ${roleId} not found`);
            commit('SET_SELECTED_ROLE', { ...role });
            commit('SET_STATUS', 'success');
            return role;
        } catch (err) {
            commit('SET_STATUS', 'error');
            commit('SET_SELECTED_ROLE', null);
            console.error('fetchRole error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Создать роль (с правами)
    async createRole({ commit }, roleData) {
        // roleData = { name, description, permissions: [id1, id2, ...] }
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.createRole(roleData);
            commit('ADD_ROLE', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (err) {
            commit('SET_STATUS', 'error');
            console.error('createRole error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Обновить роль и её права
    async updateRole({ commit }, { roleId, roleData }) {
        // roleData = { name?, description?, permissions? }
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.updateRole(roleId, roleData);
            commit('UPDATE_ROLE', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (err) {
            commit('SET_STATUS', 'error');
            console.error('updateRole error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Удалить роль
    async deleteRole({ commit }, roleId) {
        commit('SET_STATUS', 'loading');
        try {
            await api.deleteRole(roleId);
            commit('REMOVE_ROLE', roleId);
            commit('SET_STATUS', 'success');
        } catch (err) {
            commit('SET_STATUS', 'error');
            console.error('deleteRole error:', err.response?.data || err.message);
            throw err;
        }
    },

    // --- Права ---

    // Загрузить все права
    async fetchPermissions({ commit }) {
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.getAllPermissions();
            commit('SET_PERMISSIONS', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (err) {
            commit('SET_STATUS', 'error');
            commit('SET_PERMISSIONS', []);
            console.error('fetchPermissions error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Загрузить одно право
    async fetchPermission({ commit, state }, permId) {
        commit('SET_STATUS', 'loading');
        try {
            // Если есть API GET /permissions/{id}, можно:
            // const { data } = await api.getPermission(permId);
            // иначе:
            const perm = state.permissions.find(p => p.id === Number(permId));
            if (!perm) throw new Error(`Permission ${permId} not found`);
            commit('SET_SELECTED_PERMISSION', { ...perm });
            commit('SET_STATUS', 'success');
            return perm;
        } catch (err) {
            commit('SET_STATUS', 'error');
            commit('SET_SELECTED_PERMISSION', null);
            console.error('fetchPermission error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Создать право
    async createPermission({ commit }, permData) {
        // permData = { name, codename, description }
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.createPermission(permData);
            commit('ADD_PERMISSION', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (err) {
            commit('SET_STATUS', 'error');
            console.error('createPermission error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Обновить право
    async updatePermission({ commit }, { permissionId, permData }) {
        // permData = { description? }
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.updatePermission(permissionId, permData);
            commit('UPDATE_PERMISSION', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (err) {
            commit('SET_STATUS', 'error');
            console.error('updatePermission error:', err.response?.data || err.message);
            throw err;
        }
    },

    // Удалить право
    async deletePermission({ commit }, permId) {
        commit('SET_STATUS', 'loading');
        try {
            await api.deletePermission(permId);
            commit('REMOVE_PERMISSION', permId);
            commit('SET_STATUS', 'success');
        } catch (err) {
            commit('SET_STATUS', 'error');
            console.error('deletePermission error:', err.response?.data || err.message);
            throw err;
        }
    },
};

const getters = {
    // Роли
    allRoles: state => state.roles,
    selectedRole: state => state.selectedRole,

    // Права
    allSystemPermissions: state => state.permissions,
    selectedPermission: state => state.selectedPermission,

    // Статус
    roleStatus: state => state.status,
};

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters,
};

