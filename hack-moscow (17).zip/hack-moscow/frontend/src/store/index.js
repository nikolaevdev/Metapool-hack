import { createStore } from 'vuex';
import auth from './authStore';
import user from './userStore';
import role from './roleStore';
import audit from './auditStore';
import pools from './poolsStore';

export default createStore({
    modules: {
        auth,
        user,
        role,
        audit,
        pools,
    },
    // Можно включить строгий режим для разработки, чтобы избежать мутаций вне мутаций Vuex
    // strict: import.meta.env.DEV,
});
