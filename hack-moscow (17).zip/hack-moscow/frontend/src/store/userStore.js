import api from '../api';

const state = {
    users: [],
    selectedUser: null,
    status: '',      // 'loading', 'success', 'error'
    pagination: {},  // если нужно
};

const mutations = {
    SET_STATUS(state, s) { state.status = s; },
    SET_USERS(state, list) { state.users = list; },
    SET_SELECTED_USER(state, u) { state.selectedUser = u; },
    ADD_USER(state, u) { state.users.unshift(u); },
    UPDATE_USER(state, u) {
        const i = state.users.findIndex(x => x.id === u.id);
        if (i !== -1) state.users.splice(i, 1, u);
        if (state.selectedUser?.id === u.id) state.selectedUser = u;
    },
    REMOVE_USER(state, id) {
        state.users = state.users.filter(x => x.id !== id);
        if (state.selectedUser?.id === id) state.selectedUser = null;
    },
    SET_PAGINATION(state, p) { state.pagination = p; },
};

const actions = {
    async fetchUsers({ commit }, params = {}) {
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.getUsers(params);
            commit('SET_USERS', data.items ?? data);
            if (data.total) {
                commit('SET_PAGINATION', {
                    total: data.total,
                    currentPage: data.page,
                    perPage: data.per_page,
                    totalPages: Math.ceil(data.total / data.per_page),
                });
            }
            commit('SET_STATUS', 'success');
            return data;
        } catch (e) {
            commit('SET_STATUS', 'error');
            commit('SET_USERS', []);
            console.error('fetchUsers:', e.response?.data || e.message);
            throw e;
        }
    },

    async fetchUser({ commit }, id) {
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.getUser(id);
            commit('SET_SELECTED_USER', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (e) {
            commit('SET_STATUS', 'error');
            commit('SET_SELECTED_USER', null);
            console.error('fetchUser:', e.response?.data || e.message);
            throw e;
        }
    },

    async createUser({ commit }, payload) {
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.createUser(payload);
            commit('ADD_USER', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (e) {
            commit('SET_STATUS', 'error');
            console.error('createUser:', e.response?.data || e.message);
            throw e;
        }
    },

    async updateUser({ commit }, { userId, userData }) {
        commit('SET_STATUS', 'loading');
        try {
            const { data } = await api.updateUser(userId, userData);
            commit('UPDATE_USER', data);
            commit('SET_STATUS', 'success');
            return data;
        } catch (e) {
            commit('SET_STATUS', 'error');
            console.error('updateUser:', e.response?.data || e.message);
            throw e;
        }
    },

    async deleteUser({ commit }, id) {
        commit('SET_STATUS', 'loading');
        try {
            await api.deleteUser(id);
            commit('REMOVE_USER', id);
            commit('SET_STATUS', 'success');
        } catch (e) {
            commit('SET_STATUS', 'error');
            console.error('deleteUser:', e.response?.data || e.message);
            throw e;
        }
    },
};

const getters = {
    allUsers: (s) => s.users,
    selectedUser: (s) => s.selectedUser,
    userStatus: (s) => s.status,
    userPagination: (s) => s.pagination,
};

export default {
    namespaced: true,
    state, mutations, actions, getters,
};