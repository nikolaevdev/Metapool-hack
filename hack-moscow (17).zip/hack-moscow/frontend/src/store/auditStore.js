// src/store/modules/audit.js
import api from '../api';

const state = {
    auditLogs: [],
    status: '',              // 'loading' | 'success' | 'error'
    filters: {
        user_id: null,
        action: '',
        date_from: null,       // YYYY-MM-DDTHH:mm:ss
        date_to: null,         // YYYY-MM-DDTHH:mm:ss
        skip: 0,
        limit: 25,
    },
    pagination: {
        total: 0,
        currentPage: 1,
        perPage: 25,
        totalPages: 1,
    },
};

const mutations = {
    SET_STATUS(state, status) {
        state.status = status;
    },
    SET_AUDIT_LOGS(state, { logs, total }) {
        state.auditLogs = logs;
        state.pagination.total = total;
        state.pagination.perPage = state.filters.limit;
        state.pagination.currentPage = Math.floor(state.filters.skip / state.filters.limit) + 1;
        state.pagination.totalPages = Math.ceil(total / state.filters.limit) || 1;
    },
    SET_AUDIT_FILTERS(state, newFilters) {
        // При изменении любых фильтров (кроме skip/limit) сбрасываем skip
        const { skip, limit, ...restOld } = state.filters;
        const { skip: newSkip, limit: newLimit, ...restNew } = newFilters;
        const filtersChanged = Object.keys(restNew).some(
            key => restNew[key] !== restOld[key]
        );
        if (filtersChanged && typeof newFilters.skip === 'undefined') {
            state.filters.skip = 0;
        }
        state.filters = { ...state.filters, ...newFilters };
    },
    CLEAR_AUDIT_LOGS(state) {
        state.auditLogs = [];
        state.pagination = {
            total: 0,
            currentPage: 1,
            perPage: state.filters.limit,
            totalPages: 1,
        };
    },
};

const actions = {
    async fetchAuditLogs({ commit, state }, newFilters = {}) {
        commit('SET_STATUS', 'loading');
        commit('SET_AUDIT_FILTERS', newFilters);

        try {
            const response = await api.getAuditLogs(state.filters);

            let logs = [];
            let total = 0;

            // Проверка статуса ответа от сервера
            if (response.data.status === 'ok' && response.data.data) {
                const responseData = response.data.data;

                // Обработка данных по новому формату (объект с items и total)
                if (Array.isArray(responseData.items) && typeof responseData.total === 'number') {
                    logs = responseData.items;
                    total = responseData.total;
                }
                // Резервная обработка для старого формата (массив)
                else if (Array.isArray(responseData)) {
                    logs = responseData;
                    const totalHeader = response.headers?.['x-total-count'];
                    if (totalHeader) {
                        total = parseInt(totalHeader, 10);
                    } else {
                        total = logs.length;
                        console.warn(
                            'Audit logs: X-Total-Count header not found. ' +
                            'Пагинация будет точной только до текущей страницы.'
                        );
                    }
                } else {
                    console.warn('Audit logs: неожиданный формат ответа от API.');
                }
            } else {
                console.warn('Audit logs: API вернул ошибку:', response.data);
            }

            commit('SET_AUDIT_LOGS', { logs, total });
            commit('SET_STATUS', 'success');
            return logs;
        } catch (err) {
            commit('SET_STATUS', 'error');
            commit('CLEAR_AUDIT_LOGS');

            const errorMessage = err.response?.data || err.message;
            console.error('Не удалось загрузить аудит:', errorMessage);

            throw err;
        }
    },

    changeAuditPage({ dispatch, state }, pageNumber) {
        const newSkip = (pageNumber - 1) * state.filters.limit;
        return dispatch('fetchAuditLogs', { skip: newSkip });
    },

    changeAuditLimit({ dispatch }, newLimit) {
        return dispatch('fetchAuditLogs', { limit: newLimit, skip: 0 });
    },
};

const getters = {
    getAuditLogs: state => state.auditLogs,
    auditStatus: state => state.status,
    auditFilters: state => state.filters,
    auditPagination: state => state.pagination,
};

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters,
};
