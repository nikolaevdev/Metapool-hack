// src/store/modules/authStore.js
import api from "../api";
import router from "../router";

/**
 * Ожидаемый ответ от api.fetchMe():
 * {
 *   status: "ok",
 *   data: {
 *     user: {...},
 *     permissions: string[] | undefined,
 *     codenames: string[] | undefined
 *   },
 *   meta: {}
 * }
 */

const state = () => ({
    accessToken: localStorage.getItem("access_token") || null,
    user: JSON.parse(localStorage.getItem("user_profile") || "null"),
    permissions: JSON.parse(localStorage.getItem("user_permissions") || "[]"),
    status: "", // '', 'loading', 'success', 'error', 'require_2fa'
    qrCodeUrlFor2FA: null,
    twoFASecret: null,
});

const mutations = {
    SET_STATUS(state, status) {
        state.status = status;
    },
    SET_ACCESS_TOKEN(state, token) {
        state.accessToken = token || null;
        if (token) {
            localStorage.setItem("access_token", token);
        } else {
            localStorage.removeItem("access_token");
        }
    },
    SET_USER(state, user) {
        state.user = user || null;
        if (user) {
            localStorage.setItem("user_profile", JSON.stringify(user));
        } else {
            localStorage.removeItem("user_profile");
        }
    },
    SET_PERMISSIONS(state, permissions) {
        const list = Array.isArray(permissions) ? permissions : [];
        state.permissions = list;
        localStorage.setItem("user_permissions", JSON.stringify(list));
    },
    CLEAR_AUTH_DATA(state) {
        state.accessToken = null;
        state.user = null;
        state.permissions = [];
        state.qrCodeUrlFor2FA = null;
        state.twoFASecret = null;

        localStorage.removeItem("access_token");
        localStorage.removeItem("user_profile");
        localStorage.removeItem("user_permissions");
        localStorage.removeItem("refresh_token");
    },

    // 2FA (опционально — если поддерживается на бэке)
    SET_QR_2FA(state, url) {
        state.qrCodeUrlFor2FA = url || null;
    },
    SET_2FA_SECRET(state, secret) {
        state.twoFASecret = secret || null;
    },
};

const actions = {
    /**
     * Единая точка загрузки профиля и прав
     * Берём список прав из data.codenames || data.permissions
     */
    async loadMe({ commit }) {
        try {
            const resp = await api.getAuthProfile(); // <-- при необходимости замените на api.getAuthProfile()
            const envelope = resp?.data ?? resp ?? {};
            const me = envelope.data ?? envelope;

            commit("SET_USER", me.user || null);
            commit("SET_PERMISSIONS", me.codenames || me.permissions || []);
            return me;
        } catch (e) {
            // не трогаем токен, чтобы можно было повторить попытку
            console.warn("Не удалось загрузить профиль /auth/me:", e);
            throw e;
        }
    },

    /**
     * Логин:
     * ожидается ответ с access_token (+возможно refresh_token)
     * Если сервер требует 2FA, статус ставим в 'require_2fa' и возвращаем флаг
     */
    async login({ commit, dispatch }, credentials) {
        commit("SET_STATUS", "loading");
        try {
            const resp = await api.login(credentials);
            const envelope = resp?.data ?? resp ?? {};
            const payload = envelope.data ?? envelope;
            const meta = envelope.meta ?? {};
            const access =
            payload.access_token ?? payload.access ?? payload.token ?? null;
            const refresh =
            payload.refresh_token ?? payload.refresh ?? null;

            if (!access) {
                throw new Error("Отсутствует токен доступа в ответе сервера");
            }

            commit("SET_ACCESS_TOKEN", access);
            if (typeof refresh === "string") {
                try {
                    localStorage.setItem("refresh_token", refresh);
                } catch (_) {}
            }

            const otpRequired =
            meta.require_2fa || meta.otp_required || payload.require_2fa;

            if (otpRequired) {
                commit("SET_STATUS", "require_2fa");
                return { require_2fa: true, access };
            }

            await dispatch("loadMe");
            commit("SET_STATUS", "success");
            return payload;
        } catch (err) {
            commit("CLEAR_AUTH_DATA");
            commit("SET_STATUS", "error");
            throw err;
        }
    },

    /**
    * Обновление профиля пользователя
    * payload: { id, first_name, last_name, email }
    */
    async updateProfile({ state, commit }, payload) {
        const { id, ...body } = payload;
        const resp = await api.updateUser(id, body);
        const updated = resp?.data ?? resp ?? {};

        // Если редактируется текущий пользователь — обновим локально,
        // чтобы UI сразу отразил изменения (а потом loadMe это закрепит).
        if (state.user && Number(state.user.id) === Number(id)) {
          const merged = {
                ...state.user,
                first_name: body.first_name ?? state.user.first_name,
            last_name:  body.last_name  ?? state.user.last_name,
            email:      body.email      ?? state.user.email,
          };
          commit('SET_USER', merged);
        }
        return updated;
    },

    /**
     * Выход
     */
    async logout({ commit }) {
        try {
            // не обязателен; если есть эндпоинт — хорошо бы вызвать
            if (typeof api.logout === "function") {
                await api.logout();
            }
        } catch (_) {
            // игнор — мы всё равно локально чистим сессию
        } finally {
            commit("CLEAR_AUTH_DATA");
            // при необходимости — редирект на страницу логина
            try {
                if (router?.currentRoute?.name !== "login") {
                    router.push({ name: "login" }).catch(() => {});
                }
            } catch (_) {}
        }
    },

    /**
     * Обёртки для совместимости — теперь просто проксируют на loadMe
     */
    async fetchProfile({ dispatch }) {
        return dispatch("loadMe");
    },
    async fetchPermissions() {
        // больше не нужен — права приходят в /auth/me
        return;
    },
    async fetchProfileAndPermissions({ dispatch }) {
        return dispatch("loadMe");
    },

    /**
     * Инициализация при старте приложения
     * Если есть токен — поднимаем профиль и права
     */
    async initAuth({ state, commit, dispatch }) {
        if (state.accessToken && !state.user) {
            commit("SET_STATUS", "loading");
            try {
                await dispatch("loadMe");
                commit("SET_STATUS", "success");
            } catch (e) {
                commit("CLEAR_AUTH_DATA");
                commit("SET_STATUS", "error");
            }
        }
    },

    /**
     * Ниже — необязательные экшены для 2FA (если у Вас есть такие эндпоинты).
     * Можете удалить, если не используете.
     */
    async start2FASetup({ commit }) {
        if (typeof api.start2FASetup !== "function") return;
        const resp = await api.start2FASetup();
        const data = resp?.data ?? resp ?? {};
        commit("SET_QR_2FA", data.qr || data.qr_code_url || null);
        commit("SET_2FA_SECRET", data.secret || null);
        return data;
    },
    async confirm2FA({ commit }, { code }) {
        if (typeof api.confirm2FA !== "function") return;
        const resp = await api.confirm2FA({ code });
        commit("SET_QR_2FA", null);
        commit("SET_2FA_SECRET", null);
        return resp?.data ?? resp ?? {};
    },
    async disable2FA({ commit }) {
        if (typeof api.disable2FA !== "function") return;
        const resp = await api.disable2FA();
        commit("SET_QR_2FA", null);
        commit("SET_2FA_SECRET", null);
        return resp?.data ?? resp ?? {};
    },
};

const getters = {
    isAuthenticated: (s) => Boolean(s.accessToken),
    authStatus: (s) => s.status,
    me: (s) => s.user,
    permissions: (s) => s.permissions,
    hasPermission:
    (s) =>
    (perm) =>
    Array.isArray(s.permissions) && s.permissions.includes(perm),
    hasAnyPermission:
    (s) =>
    (list) =>
    Array.isArray(list) &&
    Array.isArray(s.permissions) &&
    list.some((p) => s.permissions.includes(p)),

    // если на бэке есть поле is_twofa_enabled в user
    isTwoFaEnabled: (s) => s.user?.is_twofa_enabled ?? false,
    qrCodeFor2FASetup: (s) => s.qrCodeUrlFor2FA,
    secretFor2FASetup: (s) => s.twoFASecret,
};

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters,
};



