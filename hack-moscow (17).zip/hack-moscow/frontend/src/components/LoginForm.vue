<template>
    <form @submit.prevent="handleLogin" class="space-y-6">
        <div
                v-if="loginError"
                class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-200 dark:text-red-800"
                role="alert"
        >
            <span class="font-medium">Ошибка входа!</span> {{ loginError }}
        </div>

        <div>
            <label for="username" class="block mb-2 text-sm font-medium">Имя пользователя или Email</label>
            <input
                    id="username"
                    v-model="credentials.username"
                    type="text"
                    placeholder="yourname / name@example.com"
                    required
                    class="bg-gray-50 border border-gray-300 rounded-lg block w-full p-2.5"
            />
        </div>

        <div>
            <label for="password" class="block mb-2 text-sm font-medium">Пароль</label>
            <input
                    id="password"
                    v-model="credentials.password"
                    type="password"
                    placeholder="••••••••"
                    required
                    class="bg-gray-50 border border-gray-300 rounded-lg block w-full p-2.5"
            />
        </div>

        <div v-if="requiresTotp || credentials.totp_code || useBackup">
            <label
                    for="totp_code"
                    class="block mb-2 text-sm font-medium text-gray-700 dark:text-gray-300"
            >
                Код TOTP или резервный код (2FA)
            </label>

            <div class="flex items-center mb-2">
                <input
                        id="useBackup"
                        type="checkbox"
                        v-model="useBackup"
                        class="h-4 w-4 text-blue-600 border-gray-300 rounded"
                />
                <label
                        for="useBackup"
                        class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300"
                >
                    У меня нет доступа к устройству
                </label>
            </div>

            <div v-if="!useBackup">
                <input
                        v-model="credentials.totp_code"
                        type="text"
                        inputmode="text"
                        pattern="\d{6}|[A-Za-z0-9]{8}"
                        maxlength="8"
                        placeholder="Например: 123456"
                        title="Введите 6-значный код из аутентификатора или 8-символьный резервный код"
                        required
                        class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                        autocomplete="one-time-code">
            </div>
            <div v-else>
                <input
                        id="backup_code"
                        v-model="credentials.backup_code"
                        type="text"
                        inputmode="text"
                        maxlength="8"
                        placeholder="Например: ABCD1234"
                        title="Введите 8-символьный резервный код"
                        required
                        class="bg-gray-50 border border-gray-300 rounded-lg block w-full p-2.5"
                />
            </div>

            <p class="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Для этого аккаунта требуется двухфакторная аутентификация.
            </p>
        </div>

        <button
                type="submit"
                :disabled="loading"
                class="w-full text-white bg-blue-700 hover:bg-blue-800 font-medium rounded-lg px-5 py-3 disabled:opacity-50"
        >
            <span v-if="loading">Вход...</span>
            <span v-else>Войти</span>
        </button>
    </form>
</template>

<script setup lang="ts">
    import { ref, computed } from 'vue';
    import { useStore } from 'vuex';
    import { useRouter, useRoute } from 'vue-router';
    import axios from 'axios';

    interface Credentials {
        username: string;
        password: string;
        totp_code?: string;
        backup_code?: string;
    }

    const store = useStore();
    const router = useRouter();
    const route = useRoute();

    const credentials = ref<Credentials>({
        username: '',
        password: '',
        totp_code: '',
        backup_code: ''
    });
    const loading = computed(() => store.getters['auth/authStatus'] === 'loading');
    const loginError = ref<string>('');
    const requiresTotp = ref<boolean>(false);
    // Новая функциональность: режим резервных кодов
    const useBackup = ref<boolean>(false);

    const handleLogin = async (): Promise<void> => {
        loginError.value = '';
    try {
        // Сбор данных для входа
        const payload: any = {
            username: credentials.value.username,
            password: credentials.value.password
        };
        if (useBackup.value) {
            payload.backup_code = credentials.value.backup_code;
        } else if (requiresTotp.value || credentials.value.totp_code) {
            payload.totp_code = credentials.value.totp_code;
        }
        await store.dispatch('auth/login', payload);
        const redirect = (route.query.redirect as string) || '/dashboard';
        await router.push(redirect);
    } catch (error: any) {
        // Если требуется 2FA
        if (axios.isAxiosError(error) && error.response?.data?.['2fa_required']) {
            requiresTotp.value = true;
            return;
        }
        // Если есть детальная ошибка
        if (axios.isAxiosError(error) && typeof error.response?.data?.detail === 'string') {
            loginError.value = error.response.data.detail;
            return;
        }
        // Общая ошибка
        loginError.value = 'Неизвестная ошибка при входе';
    }
    };
</script>


