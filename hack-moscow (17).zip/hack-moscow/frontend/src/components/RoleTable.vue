<!-- src/components/RoleTable.vue -->
<template>
    <div class="bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden">
        <div class="p-4 sm:p-6 border-b dark:border-gray-700 flex justify-between items-center">
            <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Список ролей</h2>
            <button
                    v-if="canCreateRole"
                    @click="openCreateRoleModal"
                    type="button"
                    class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:focus:ring-blue-800"
            >
                <PlusIcon class="h-5 w-5 inline-block mr-1 -ml-1" />
                Создать роль
            </button>
        </div>

        <div v-if="loadingRoles" class="p-6 text-center text-gray-500 dark:text-gray-400">
            Загрузка ролей...
        </div>
        <div v-else-if="!roles.length" class="p-6 text-center text-gray-500 dark:text-gray-400">
            Роли не найдены.
        </div>
        <div v-else class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th class="px-6 py-3">ID</th>
                    <th class="px-6 py-3">Название</th>
                    <th class="px-6 py-3">Описание</th>
                    <th class="px-6 py-3">Кол-во прав</th>
                    <th class="px-6 py-3 text-right">Действия</th>
                </tr>
                </thead>
                <tbody>
                <tr
                        v-for="r in roles"
                        :key="r.id"
                        class="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                    <td class="px-6 py-4">{{ r.id }}</td>
                    <td class="px-6 py-4">{{ r.name }}</td>
                    <td class="px-6 py-4">{{ r.description }}</td>
                    <td class="px-6 py-4">{{ r.permissions.length }}</td>
                    <td class="px-6 py-4 text-right space-x-2">
                        <button
                                v-if="canEditRole"
                                @click="openEditRoleModal(r)"
                                type="button"
                                class="text-blue-600 hover:underline p-1"
                        >
                            <PencilIcon class="h-5 w-5 inline" />
                        </button>
                        <button
                                v-if="canDeleteRole"
                                @click="confirmDeleteRole(r.id)"
                                type="button"
                                class="text-red-600 hover:underline p-1"
                        >
                            <TrashIcon class="h-5 w-5 inline" />
                        </button>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>

        <div
                id="roleModal"
                ref="modalEl"
                tabindex="-1"
                aria-hidden="true"
                class="fixed inset-0 z-50 hidden overflow-y-auto p-4"
        >
            <div class="relative mx-auto max-w-2xl h-full">
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
                    <div class="flex items-start justify-between p-5 border-b dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            {{ isEditMode ? 'Редактировать роль и права' : 'Создать роль и права' }}
                        </h3>
                        <button
                                @click="hideModal"
                                type="button"
                                class="text-gray-400 hover:bg-gray-200 hover:text-gray-900 rounded-lg p-1.5 dark:hover:bg-gray-600 dark:hover:text-white"
                        >
                            <XMarkIcon class="w-5 h-5" />
                            <span class="sr-only">Закрыть</span>
                        </button>
                    </div>
                    <form @submit.prevent="saveRole" class="p-6 space-y-4">
                        <div>
                            <label
                                    for="role_name"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                                Название *
                            </label>
                            <input
                                    id="role_name"
                                    v-model="roleForm.name"
                                    required
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                            />
                        </div>

                        <div>
                            <label
                                    for="role_description"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                                Описание
                            </label>
                            <textarea
                                    id="role_description"
                                    rows="3"
                                    v-model="roleForm.description"
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                            ></textarea>
                        </div>

                        <fieldset class="pt-3 border-t dark:border-gray-700">
                            <legend class="sr-only">Права доступа</legend>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-2 max-h-60 overflow-y-auto border dark:border-gray-600 rounded-md">
                                <div v-for="perm in allPermissions" :key="perm.id" class="flex items-center mb-4">
                                    <input
                                            type="checkbox"
                                            :id="'role_perm_' + perm.id"
                                            :value="perm.id"
                                            v-model="roleForm.permissions"
                                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500"
                                    />
                                    <label
                                            :for="'role_perm_' + perm.id"
                                            class="ms-2 text-sm font-medium text-gray-900 dark:text-gray-300"
                                    >
                                        {{ perm.name }} ({{ perm.codename }})
                                    </label>
                                </div>
                            </div>
                        </fieldset>

                        <p v-if="errorMsg" class="text-red-500 text-sm">{{ errorMsg }}</p>

                        <div class="flex justify-end space-x-2 pt-4 border-t dark:border-gray-700">
                            <button
                                    @click="hideModal"
                                    type="button"
                                    class="px-4 py-2 text-sm font-medium text-gray-500 bg-white border rounded-lg hover:bg-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                            >
                                Отмена
                            </button>
                            <button
                                    type="submit"
                                    :disabled="saving"
                                    class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300 disabled:opacity-75 dark:focus:ring-blue-800"
                            >
                                <span v-if="saving">Сохранение...</span>
                                <span v-else>{{ isEditMode ? 'Сохранить' : 'Создать' }}</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref, computed, onMounted } from 'vue';
    import { useStore } from 'vuex';
    import { initFlowbite, Modal, type ModalInterface, type ModalOptions } from 'flowbite';
    import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon } from '@heroicons/vue/24/outline';

    const store = useStore();

    const roles = computed(() => store.getters['role/allRoles']);
    const loadingRoles = computed(
    () => store.getters['role/roleStatus'] === 'loading' && !roles.value.length
    );
    const allPermissions = computed(() => store.getters['role/allSystemPermissions']);

    const canCreateRole = computed(() => store.getters['auth/hasPermission']('add_role'));
    const canEditRole = computed(() => store.getters['auth/hasPermission']('change_role'));
    const canDeleteRole = computed(() => store.getters['auth/hasPermission']('delete_role'));

    const modalEl = ref<HTMLElement | null>(null);
    let modal: ModalInterface;

    const isEditMode = ref(false);
    const saving = ref(false);
    const errorMsg = ref('');

    const defaultForm = {
    id: null as number | null,
    name: '',
    description: '',
    permissions: [] as number[],
    };
    const roleForm = ref({ ...defaultForm });

    onMounted(async () => {
    initFlowbite();
    if (modalEl.value) {
    const opts: ModalOptions = { backdrop: 'dynamic', closable: true };
    modal = new Modal(modalEl.value, opts, { override: true });
    }
    await store.dispatch('role/fetchPermissions');
    await store.dispatch('role/fetchRoles');
    });

    function openCreateRoleModal() {
    isEditMode.value = false;
    Object.assign(roleForm.value, defaultForm);
    errorMsg.value = '';
    modal.show();
    }

    function openEditRoleModal(r: any) {
    isEditMode.value = true;
    errorMsg.value = '';
    roleForm.value.id = r.id;
    roleForm.value.name = r.name;
    roleForm.value.description = r.description;
    roleForm.value.permissions = r.permissions.map((p: any) => p.id);
    modal.show();
    }

    function hideModal() {
    modal.hide();
    }

    async function saveRole() {
    saving.value = true;
    try {
    if (isEditMode.value) {
    await store.dispatch('role/updateRole', {
    roleId: roleForm.value.id,
    roleData: {
    name: roleForm.value.name,
    description: roleForm.value.description,
    permissions: roleForm.value.permissions,
    },
    });
    } else {
    await store.dispatch('role/createRole', {
    name: roleForm.value.name,
    description: roleForm.value.description,
    permissions: roleForm.value.permissions,
    });
    }
    await store.dispatch('role/fetchRoles');
    hideModal();
    } catch {
    errorMsg.value = 'Не удалось сохранить роль.';
    } finally {
    saving.value = false;
    }
    }

    async function confirmDeleteRole(id: number) {
    if (!confirm('Вы уверены, что хотите удалить роль?')) return;
    try {
    await store.dispatch('role/deleteRole', id);
    await store.dispatch('role/fetchRoles');
    } catch {
    alert('Не удалось удалить роль.');
    }
    }
</script>

<style scoped>
    /* Дополнительные стили при необходимости */
</style>

