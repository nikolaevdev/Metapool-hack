<template>
  <div class="fixed top-4 right-4 space-y-2 z-50">
    <div v-for="n in notes" :key="n.id" :class="['px-4 py-3 rounded-lg shadow text-sm',
      n.type==='error' ? 'bg-red-600 text-white' : n.type==='warn' ? 'bg-yellow-500 text-white' : 'bg-emerald-600 text-white']">
      <div class="font-medium">{{ n.title }}</div>
      <div>{{ n.message }}</div>
    </div>
  </div>
</template>
<script>
let seq = 1
export default {
  name:'Notifications',
  data(){ return { notes: [] } },
  mounted(){
    window.addEventListener('notify', this.onNotify)
  },
  beforeUnmount(){
    window.removeEventListener('notify', this.onNotify)
  },
  methods:{
    onNotify(e){
      const d = e.detail || {}
      const id = seq++
      const n = { id, type: d.type || 'info', title: d.title || 'Сообщение', message: d.message || '' }
      this.notes.push(n)
      setTimeout(()=>{ this.notes = this.notes.filter(x=>x.id!==id) }, d.ttl || 3500)
    }
  }
}
</script>
