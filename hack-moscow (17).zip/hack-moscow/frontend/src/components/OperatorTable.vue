<!-- src/components/OperatorTable.vue -->
<template>
    <div class="bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden">
        <!-- Заголовок -->
        <div class="p-4 sm:p-6 border-b dark:border-gray-700 flex justify-between items-center">
            <h2 class="text-xl font-semibold text-gray-800 dark:text-white">
                Список операторов
            </h2>
            <button
                    v-if="canManageOperator"
                    @click="openModal(null)"
                    type="button"
                    class="text-white bg-blue-600 hover:bg-blue-700 font-medium rounded-lg text-sm px-4 py-2"
            >
                <PlusIcon class="h-5 w-5 inline-block mr-1 -ml-1" />
                Новый оператор
            </button>
        </div>

        <!-- Таблица операторов -->
        <div class="p-4 sm:p-6">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead class="bg-gray-50 dark:bg-gray-700">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Telegram ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Активен</th>
                    <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Действия</th>
                </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                <tr v-for="op in operators" :key="op.id">
                    <td class="px-6 py-4">{{ op.id }}</td>
                    <td class="px-6 py-4">{{ op.user_id }}</td>
                    <td class="px-6 py-4">{{ op.telegram_id }}</td>
                    <td class="px-6 py-4">
                        <span v-if="op.is_active" class="text-green-600">Да</span>
                        <span v-else class="text-red-600">Нет</span>
                    </td>
                    <td class="px-6 py-4 text-right space-x-2">
                        <!-- Редактировать -->
                        <button
                                v-if="canManageOperator"
                                @click="openModal(op)"
                                type="button"
                                class="text-blue-600 hover:underline p-1"
                        >
                            <PencilIcon class="h-5 w-5 inline-block" />
                        </button>
                        <!-- Удалить -->
                        <button
                                v-if="canManageOperator"
                                @click="confirmDelete(op.id)"
                                type="button"
                                class="text-red-600 hover:underline p-1"
                        >
                            <TrashIcon class="h-5 w-5 inline-block" />
                        </button>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>

        <!-- Модальное окно создания / редактирования -->
        <div
                id="operatorModal"
                ref="modalEl"
                tabindex="-1"
                aria-hidden="true"
                class="fixed inset-0 z-50 hidden overflow-y-auto p-4"
        >
            <div class="relative mx-auto max-w-xl h-full">
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
                    <!-- Заголовок модалки -->
                    <div class="flex items-start justify-between p-5 border-b dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            {{ isEdit ? 'Редактировать оператора' : 'Новый оператор' }}
                        </h3>
                        <button
                                type="button"
                                class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-700 dark:hover:text-white"
                                @click="hideModal"
                        >
                            <XMarkIcon class="h-5 w-5" />
                        </button>
                    </div>
                    <!-- Тело модалки -->
                    <form @submit.prevent="save" class="px-6 py-4 space-y-4">
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                User ID *
                            </label>
                            <input
                                    v-model="form.user_id"
                                    type="number"
                                    required
                                    class="block w-full p-2 rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            />
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                Telegram ID *
                            </label>
                            <input
                                    v-model="form.telegram_id"
                                    type="number"
                                    required
                                    class="block w-full p-2 rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            />
                        </div>
                        <p v-if="error" class="text-red-500 text-sm">{{ error }}</p>
                        <!-- Кнопки модалки -->
                        <div class="flex justify-end space-x-2 pt-4 border-t dark:border-gray-700">
                            <button
                                    type="button"
                                    @click="hideModal"
                                    class="px-4 py-2 text-gray-500 bg-white border border-gray-200 rounded-lg hover:bg-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                            >
                                Отмена
                            </button>
                            <button
                                    type="submit"
                                    :disabled="saving"
                                    class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-75"
                            >
                                {{ saving ? 'Сохранение…' : (isEdit ? 'Сохранить' : 'Создать') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref, computed, onMounted } from 'vue';
    import { useStore } from 'vuex';
    import { initFlowbite, Modal, type ModalInterface, type ModalOptions } from 'flowbite';
    import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon } from '@heroicons/vue/24/outline';
    import api from '../api';

    const store = useStore();

    // Данные операторов
    const operators = ref<any[]>([]);
    const loading = ref(false);

    // Права доступа
    const canManageOperator = computed(
    () => store.getters['auth/hasPermission']('manage_operator')
    );

    // Состояние модалки
    const modalEl = ref<HTMLElement | null>(null);
    let modal: ModalInterface;
    const isEdit = ref(false);
    const saving = ref(false);
    const error = ref<string | null>(null);

    // Данные формы
    const form = ref<{ id: number | null; user_id: number | string; telegram_id: number | string }>({
    id: null,
    user_id: '',
    telegram_id: ''
    });

    // Загрузка списка операторов
    async function fetchOperators() {
    loading.value = true;
    try {
    const response = await api.getOperators();
    operators.value = response.data;
    } finally {
    loading.value = false;
    }
    }

    // Открыть модалку для создания или редактирования
    function openModal(op: any | null) {
    isEdit.value = !!op;
    error.value = null;
    if (op) {
    form.value = { id: op.id, user_id: op.user_id, telegram_id: op.telegram_id };
    } else {
    form.value = { id: null, user_id: '', telegram_id: '' };
    }
    modal.show();
    }

    // Закрыть модалку
    function hideModal() {
    modal.hide();
    }

    // Сохранить (создать или обновить)
    async function save() {
    saving.value = true;
    error.value = null;
    try {
    if (isEdit.value && form.value.id !== null) {
    // Обновление существующего оператора
    await api.updateOperator(form.value.id, {
    user_id: Number(form.value.user_id),
    telegram_id: Number(form.value.telegram_id)
    });np
    } else {
    // Создание нового оператора
    await api.createOperator({
    user_id: Number(form.value.user_id),
    telegram_id: Number(form.value.telegram_id)
    });
    }
    await fetchOperators();
    hideModal();
    } catch (e: any) {
    error.value = e?.response?.data?.message || 'Ошибка при сохранении оператора';
    } finally {
    saving.value = false;
    }
    }

    // Удаление оператора
    async function confirmDelete(id: number) {
    if (!confirm('Удалить оператора?')) return;
    try {
    await api.deleteOperator(id);
    await fetchOperators();
    } catch {
    alert('Не удалось удалить оператора.');
    }
    }

    // Инициализация Flowbite-модалки и начальная загрузка
    onMounted(async () => {
    initFlowbite();
    if (modalEl.value) {
    const opts: ModalOptions = { backdrop: 'dynamic', closable: true };
    modal = new Modal(modalEl.value, opts, { override: true });
    }
    await fetchOperators();
    });
</script>

<style scoped>
    /* Можно добавить дополнительные стили при необходимости */
</style>
