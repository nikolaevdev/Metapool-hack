<script setup lang="ts">
    import { Modal } from 'flowbite';
    import type { ModalInterface, ModalOptions, InstanceOptions } from 'flowbite';
    import { onMounted, onBeforeUnmount, ref } from 'vue';

    const props = defineProps<{
        modelValue: boolean;
    title?: string;
    backdrop?: ModalOptions['backdrop'];
    placement?: ModalOptions['placement'];
    closable?: boolean;
    }>();

    const emit = defineEmits(['update:modelValue', 'show', 'hide']);

    const modalElement = ref<HTMLElement | null>(null);
    let modal: ModalInterface | null = null;

    onMounted(() => {
    if (!modalElement.value) return;

    const options: ModalOptions = {
    placement: props.placement ?? 'center',
    backdrop: props.backdrop ?? 'dynamic',
    closable: props.closable ?? true,
    onShow: () => emit('show'),
    onHide: () => emit('hide'),
    };

    const instanceOptions: InstanceOptions = {
    id: modalElement.value.id,
    override: true,
    };

    modal = new Modal(modalElement.value, options, instanceOptions);

    // синхронизация prop ↔ Flowbite‑инстанс
    if (props.modelValue) modal.show();
    });

    onBeforeUnmount(() => {
    modal?.destroy();
    });

    // отслеживаем изменение v‑model
    watch(
    () => props.modelValue,
    (val) => (val ? modal?.show() : modal?.hide()),
    );
</script>

<template>
    <div
            ref="modalElement"
            :id="`modal${Math.random().toString(36).slice(2)}`"
            tabindex="-1"
            aria-hidden="true"
            class="fixed left-0 right-0 top-0 z-50 hidden h-[calc(100%-1rem)] max-h-full w-full overflow-y-auto overflow-x-hidden p-4 md:inset-0"
    >
        <div class="relative max-h-full w-full max-w-2xl">
            <!-- Content -->
            <div class="relative rounded-lg bg-white shadow-sm dark:bg-gray-700">
                <!-- Header -->
                <div class="flex items-start justify-between rounded-t border-b p-5 dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white lg:text-2xl">
                        {{ title }}
                    </h3>
                    <button
                            v-if="closable !== false"
                            type="button"
                            class="ms-auto inline-flex h-8 w-8 items-center justify-center rounded-lg bg-transparent text-sm text-gray-400 hover:bg-gray-200 hover:text-gray-900 dark:hover:bg-gray-600 dark:hover:text-white"
                            @click="emit('update:modelValue', false)"
                    >
                        <svg class="h-3 w-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>

                <!-- Body -->
                <div class="space-y-6 p-6">
                    <slot />
                </div>

                <!-- Footer -->
                <div class="flex items-center space-x-2 rtl:space-x-reverse rounded-b border-t border-gray-200 p-6 dark:border-gray-600">
                    <slot name="footer" />
                </div>
            </div>
        </div>
    </div>
</template>