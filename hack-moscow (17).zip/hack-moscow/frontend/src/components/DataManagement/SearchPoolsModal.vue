<!-- SearchPoolsModal.vue -->
<template>
    <div
            id="searchPoolsModal"
            tabindex="-1"
            aria-hidden="true"
            class="fixed inset-0 z-50 hidden h-full w-full overflow-y-auto p-4"
    >
        <div class="relative mx-auto max-w-2xl top-20">
            <div class="rounded-lg bg-white dark:bg-gray-800 dark:border dark:border-gray-700 shadow-lg">
                <div class="flex items-center justify-between border-b border-gray-200 dark:border-gray-600 p-5">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-gray-100">Поиск пулов данных</h3>
                    <button
                            @click="hide"
                            class="h-8 w-8 flex items-center justify-center rounded-lg text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 dark:text-gray-300 transition"
                    >✕</button>
                </div>
                <div class="p-6 space-y-4">
                    <input
                            v-model="search"
                            placeholder="Поиск пулов..."
                            class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-indigo-500 focus:border-indigo-500 transition"
                    />
                    <div v-if="!filtered.length" class="text-center text-gray-500 dark:text-gray-400 py-8">Ничего не найдено</div>
                    <div v-else class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div
                                v-for="pool in filtered"
                                :key="pool.id"
                                @click="select(pool)"
                                class="border border-gray-200 dark:border-gray-600 rounded-lg p-4 cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-gray-700"
                        >
                            <h4 class="font-medium text-gray-800 dark:text-gray-100">{{ pool.title ?? pool.name }}</h4>
                            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">{{ pool.description }}</p>
                        </div>
                    </div>
                </div>
                <div class="flex justify-end border-t border-gray-200 dark:border-gray-600 p-6">
                    <button
                            @click="hide"
                            class="px-5 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition"
                    >Закрыть</button>
                </div>
            </div>
        </div>
    </div>
</template>
<script setup>
    import { ref, computed, onMounted } from 'vue'
    import { Modal } from 'flowbite'

    const props = defineProps({ pools: Array })
    const emit = defineEmits(['select'])
    const search = ref('')

    const norm = (v) => (v ?? '').toString().toLowerCase()
    const list = computed(() => Array.isArray(props.pools) ? props.pools : [])

    const filtered = computed(() => {
       const q = norm(search.value)
       return list.value.filter(p => {
         const name = norm(p?.title ?? p?.name)
         const desc = norm(p?.description)
         const keys = norm(p?.keywords)
         return name.includes(q) || desc.includes(q) || keys.includes(q)
       })
    })

    let modalInstance
    onMounted(() => {
        const el = document.getElementById('searchPoolsModal')
        modalInstance = new Modal(el, { placement: 'center', backdrop: 'dynamic' })
    })
    function show() { modalInstance.show() }
    function hide() { modalInstance.hide() }
    function select(pool) { emit('select', pool); hide() }

    defineExpose({ show })
</script>
