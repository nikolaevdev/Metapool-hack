<!-- Updated EditPoolModal.vue -->
<template>
    <div
            :id="modalId"
            tabindex="-1"
            aria-hidden="true"
            class="fixed inset-0 z-50 hidden h-[calc(100%-1rem)] max-h-full w-full overflow-y-auto p-4 md:inset-0"
    >
        <div class="relative w-full max-w-md max-h-full mx-auto">
            <div class="relative rounded-lg bg-white shadow-sm dark:bg-gray-700">
                <!-- Header -->
                <div class="flex items-start justify-between rounded-t border-b p-5 dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        {{ pool ? 'Редактировать пул данных' : 'Создать новый пул данных' }}
                    </h3>
                    <button @click="hide" class="text-gray-400 hover:bg-gray-200 rounded-lg p-1">✕</button>
                </div>
                <form @submit.prevent="onSave" class="p-6 space-y-4">
                    <!-- Название -->
                    <div>
                        <label for="name" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Название пула</label>
                        <input
                                id="name"
                                v-model="form.name"
                                type="text"
                                required
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <!-- Описание -->
                    <div>
                        <label for="description" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Описание</label>
                        <textarea
                                id="description"
                                v-model="form.description"
                                class="w-full h-24 px-4 py-2 border rounded-lg"
                        ></textarea>
                    </div>
                    <!-- Ключевые слова -->
                    <div>
                        <label for="keywords" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Ключевые слова (через запятую)</label>
                        <input
                                id="keywords"
                                v-model="form.keywords"
                                type="text"
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <!-- Год -->
                    <div>
                        <label for="year" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Год</label>
                        <input
                                id="year"
                                v-model.number="form.year"
                                type="number"
                                required
                                min="2000"
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <!-- Ревизия -->
                    <div>
                        <label for="revision" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Ревизия</label>
                        <input
                                id="revision"
                                v-model.number="form.revision"
                                type="number"
                                required
                                min="1"
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <!-- Actions -->
                    <div class="flex justify-end gap-2 pt-4 border-t">
                        <button
                                v-if="pool && formInitialized"
                                type="button"
                                @click="onDelete"
                                :disabled="loadingDelete"
                                class="py-2.5 px-5 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700"
                        >
                            {{ loadingDelete ? 'Удаление…' : 'Удалить' }}
                        </button>
                        <button type="button" @click="hide" class="py-2.5 px-5 text-sm font-medium bg-white border rounded-lg">Отмена</button>
                        <button
                                type="submit"
                                :disabled="loadingSave"
                                class="py-2.5 px-5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
                        >
                            {{ loadingSave ? 'Сохранение…' : (pool ? 'Сохранить' : 'Создать') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, watch, onMounted } from 'vue';
    import { Modal } from 'flowbite';

    const props = defineProps({
        modalId: { type: String, required: true },
        pool:    { type: Object, required: false, default: null }
    });
    const emit = defineEmits(['save','delete']);

    const form = ref({ name: '', description: '', keywords: '', year: new Date().getFullYear(), revision: 1 });
    const formInitialized = ref(false);
    const loadingSave   = ref(false);
    const loadingDelete = ref(false);
    let modalInstance = null;

    onMounted(() => {
        modalInstance = new Modal(document.getElementById(props.modalId), {
            placement: 'center',
            backdrop: 'dynamic'
        });
    });

    watch(
        () => props.pool,
        (p) => {
            if (p) {
                form.value = {
                    name:        p.name || '',
                    description: p.description || '',
                    keywords:    Array.isArray(p.keywords) ? p.keywords.join(', ') : (p.keywords || ''),
                    year:        p.year || new Date().getFullYear(),
                    revision:    p.revision || 1
                };
                formInitialized.value = true;
            } else {
                formInitialized.value = false;
                form.value = { name: '', description: '', keywords: '', year: new Date().getFullYear(), revision: 1 };
            }
        },
        { immediate: true }
    );

    function show() { modalInstance.show() }
    function hide() { modalInstance.hide() }

    async function onSave() {
        loadingSave.value = true;
        try {
            emit('save', {
                name:        form.value.name,
                description: form.value.description,
                keywords:    form.value.keywords,
                year:        form.value.year,
                revision:    form.value.revision
            });
        } finally {
            loadingSave.value = false;
            hide();
        }
    }

    async function onDelete() {
        if (!props.pool) return;
        loadingDelete.value = true;
        try {
            emit('delete');
        } finally {
            loadingDelete.value = false;
            hide();
        }
    }

    defineExpose({ show, hide });
</script>



