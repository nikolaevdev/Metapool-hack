<!-- SidebarPools.vue -->
<template>
    <aside class="w-64 bg-white dark:bg-gray-800 dark:border dark:border-gray-700 rounded-lg shadow-sm p-4 sticky top-24 h-fit">
        <div class="flex flex-col gap-4">
            <input
                    v-model="search"
                    placeholder="Поиск пулов..."
                    class="bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100 text-sm rounded-lg block w-full p-2.5 focus:ring-indigo-500 focus:border-indigo-500 transition"
            />
            <button
                    @click="emitCreate"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition"
            >Создать пул</button>
            <button
                    @click="emitSearchModal"
                    class="border border-gray-300 dark:border-gray-600 bg-transparent hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-800 dark:text-gray-200 px-4 py-2 rounded-lg font-medium transition"
            >Поиск пулов</button>
            <div class="border-t border-gray-200 dark:border-gray-700 pt-4">
                <h3 class="font-semibold text-gray-900 dark:text-gray-100 mb-3">Пулы данных</h3>
                <div class="space-y-2">
                    <div
                            v-for="pool in filteredPools"
                            :key="pool.id"
                            @click="emitSelect(pool)"
                            class="p-3 rounded-lg cursor-pointer transition-colors"
                            :class="selectedPool && selectedPool.id === pool.id
              ? 'bg-indigo-50 dark:bg-indigo-900/20 border-l-4 border-indigo-500'
              : 'hover:bg-gray-50 dark:hover:bg-gray-700'"
                    >
                        <h4 class="font-medium truncate text-gray-800 dark:text-gray-100">{{ pool.title ?? pool.name }}</h4>
                        <p class="text-xs text-gray-500 dark:text-gray-400 truncate">{{ pool.description }}</p>
                    </div>
                </div>
            </div>
        </div>
    </aside>
</template>
<script setup>
    import { ref, computed } from 'vue'

    const props = defineProps({
        pools: { type: Array, default: () => [] },
        selectedPool: { type: Object, default: null }
    })
    const emit = defineEmits(['selectPool', 'createPool', 'searchPools'])
    const search = ref('')
    const norm = (v) => (v ?? '').toString().toLowerCase()
    const filteredPools = computed(() => {
       const term = norm(search.value)
       const list = Array.isArray(props.pools) ? props.pools : []
       return list.filter(p => {
         const name = norm(p?.title ?? p?.name)
         const desc = norm(p?.description)
         const keys = norm(p?.keywords)
         return name.includes(term) || desc.includes(term) || keys.includes(term)
       })
    })
    function emitSelect(pool) { emit('selectPool', pool) }
    function emitCreate()      { emit('createPool') }
    function emitSearchModal(){ emit('searchPools') }
</script>
