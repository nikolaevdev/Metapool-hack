<!-- CategoryFormModal.vue -->
<template>
    <div
            :id="modalId"
            tabindex="-1"
            aria-hidden="true"
            class="fixed inset-0 z-50 hidden h-[calc(100%-1rem)] max-h-full w-full overflow-y-auto p-4"
    >
        <div class="relative mx-auto max-w-md">
            <div class="rounded-lg bg-white shadow-sm">
                <!-- Header -->
                <div class="flex items-center justify-between border-b p-5">
                    <h3 class="text-xl font-semibold">Создать категорию</h3>
                    <button @click="hide" class="text-gray-400 hover:bg-gray-200 rounded-lg p-1">✕</button>
                </div>
                <form @submit.prevent="onSave" class="p-6 space-y-4">
                    <div>
                        <label for="title" class="block mb-2 text-sm font-medium">Название категории</label>
                        <input
                                id="title"
                                v-model="form.title"
                                type="text"
                                required
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <div>
                        <label for="description" class="block mb-2 text-sm font-medium">Описание</label>
                        <textarea
                                id="description"
                                v-model="form.description"
                                class="w-full h-24 px-4 py-2 border rounded-lg"
                        ></textarea>
                    </div>
                    <div>
                        <label for="keywords" class="block mb-2 text-sm font-medium">Ключевые слова (через запятую)</label>
                        <input
                                id="keywords"
                                v-model="form.keywords"
                                type="text"
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <div class="text-sm text-gray-500">
                        <p>Путь сформируется автоматически как <code>{{ previewPath }}</code></p>
                    </div>
                    <div class="flex justify-end gap-2 pt-4 border-t">
                        <button type="submit" class="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                            Добавить
                        </button>
                        <button type="button" @click="hide" class="px-5 py-2.5 bg-white border rounded-lg hover:bg-gray-100">
                            Отмена
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed, onMounted } from 'vue';
    import { Modal } from 'flowbite';

    const props = defineProps({
        modalId: { type: String, required: true },
        parentCategory: { type: Object, default: null }  // null = корень
    });
    const emit = defineEmits(['save']);

    const form = ref({
        title: '',
        description: '',
        keywords: ''
    });

    let modalInstance = null;
    onMounted(() => {
        modalInstance = new Modal(
            document.getElementById(props.modalId),
            { placement: 'center', backdrop: 'dynamic' }
        );
    });

    function show() { modalInstance.show() }
    function hide() { modalInstance.hide() }

    // slugify с поддержкой любых букв Unicode (включая кириллицу) и цифр
    function slugify(str) {
        return str
            .toString()
            .trim()
            .toLowerCase()
        // заменяем все, кроме букв и цифр, на дефис
            .replace(/[^^\p{L}\p{N}]+/gu, '-')
        // убираем ведущие и конечные дефисы
            .replace(/^-+|-+$/g, '');
    }

    // Предварительный просмотр будущего path
    const previewPath = computed(() => {
        const slug = slugify(form.value.title || 'new');
        return props.parentCategory
        ? `${props.parentCategory.path}.${slug}`
        : slug;
    });

    function onSave() {
        const slug = slugify(form.value.title);
        const path = props.parentCategory
        ? `${props.parentCategory.path}.${slug}`
        : slug;
        emit('save', {
            title:       form.value.title,
            description: form.value.description,
            keywords:    form.value.keywords,
            path
        });
        hide();
    }

    defineExpose({ show, hide });
</script>


