<!-- AttachmentCard.vue -->
<template>
    <div class="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-white dark:bg-gray-800 shadow-sm transition-colors">
        <div class="flex justify-between items-start">
            <div>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">{{ item.description || 'Без описания' }}</p>
                <p class="text-xs text-gray-500 dark:text-gray-400 mt-1 truncate">{{ item.mime_type }} • {{ formattedDate }}</p>
                <div class="flex flex-wrap gap-1 mt-2">
          <span
                  v-for="(kw, idx) in keywordsArray"
                  :key="`kw-${idx}`"
                  class="px-2 py-1 text-xs font-medium bg-purple-200 dark:bg-purple-800 text-purple-800 dark:text-purple-200 rounded-full transition"
          >{{ kw }}</span>
                </div>
            </div>
            <div class="flex space-x-2">
                <button
                        @click="$emit('edit', item)"
                        class="p-1 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition rounded"
                >✎</button>
                <button
                        @click="$emit('delete', item)"
                        class="p-1 text-red-500 hover:text-red-700 transition rounded"
                >🗑️</button>
            </div>
        </div>
    </div>
<input type="file" @change="onFile" class="mt-2" />
</template>
<script setup>
    import { computed } from 'vue'
    import { format } from 'date-fns'

    const props = defineProps({ item: Object })
    const keywordsArray = computed(() =>
    props.item.keywords
    ? props.item.keywords.split(',').map(s => s.trim()).filter(Boolean)
    : []
    )
    const formattedDate = computed(() =>
    props.item.created_at ? format(new Date(props.item.created_at), 'dd.MM.yyyy HH:mm') : ''
    )
</script>