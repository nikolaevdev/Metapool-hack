<!-- src/components/DataManagement/DataFormModal.vue -->
<template>
    <div
            :id="modalId"
            tabindex="-1"
            aria-hidden="true"
            class="fixed inset-0 z-50 hidden h-[calc(100%-1rem)] w-full
           overflow-y-auto overflow-x-hidden p-4"
    >
        <!-- Контейнер модального окна -->
        <div class="relative mx-auto w-full max-w-2xl max-h-[90vh]">
            <div class="relative rounded-lg bg-white shadow-sm dark:bg-gray-700">
                <!-- ───── Header ───── -->
                <div
                        class="flex items-start justify-between rounded-t border-b p-5 dark:border-gray-600"
                >
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        Добавить данные
                    </h3>
                    <button
                            type="button"
                            @click="hide"
                            class="ms-auto inline-flex h-8 w-8 items-center justify-center
                   rounded-lg text-sm text-gray-400 hover:bg-gray-200 hover:text-gray-900
                   dark:hover:bg-gray-600 dark:hover:text-white"
                    >
                        ✕
                    </button>
                </div>

                <!-- ───── Форма ───── -->
                <form @submit.prevent="onSave" class="p-6 overflow-y-auto max-h-[78vh]">
                    <!-- Переключатель режима -->
                    <div class="mb-5">
                        <label class="mb-2 block text-sm font-medium text-gray-900 dark:text-white">
                            Тип данных
                        </label>
                        <div class="inline-flex rounded-md shadow-xs" role="group">
                            <button
                                    type="button"
                                    @click="mode = 'text'"
                                    :class="mode === 'text'
                  ? 'text-white bg-blue-700'
                  : 'text-gray-900 bg-white dark:bg-gray-800 dark:text-white/80'"
                                    class="px-4 py-2 text-sm font-medium border border-gray-200
                       focus:z-10 focus:ring-2 focus:ring-blue-700"
                            >
                                Текст
                            </button>
                            <button
                                    type="button"
                                    @click="mode = 'file'"
                                    :class="mode === 'file'
                  ? 'text-white bg-blue-700'
                  : 'text-gray-900 bg-white dark:bg-gray-800 dark:text-white/80'"
                                    class="px-4 py-2 text-sm font-medium border-y border-gray-200
                       focus:z-10 focus:ring-2 focus:ring-blue-700"
                            >
                                Файл
                            </button>
                        </div>
                    </div>

                    <!-- Поле ввода текста -->
                    <div v-if="mode === 'text'" class="mb-5">
                        <label
                                for="textContent"
                                class="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
                        >
                            Текст
                        </label>
                        <textarea
                                v-model="form.content"
                                id="textContent"
                                rows="12"
                                :disabled="!categoryId"
                                required
                                class="h-64 w-full resize-y rounded-lg border border-gray-300
                     bg-gray-50 p-2.5 text-gray-900
                     focus:border-blue-500 focus:ring-blue-500
                     dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                                placeholder="Введите текст..."
                        ></textarea>
                    </div>

                    <!-- Drop-zone для файла -->
                    <div v-else class="mb-5">
                        <label
                                for="dropzone-file"
                                class="flex h-64 w-full cursor-pointer flex-col items-center justify-center
                     rounded-lg border-2 border-dashed bg-gray-50 hover:bg-gray-100
                     dark:border-gray-600 dark:bg-gray-700 dark:hover:bg-gray-600"
                        >
                            <svg
                                    class="mb-4 h-8 w-8 text-gray-500 dark:text-gray-400"
                                    xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16"
                            >
                                <path
                                        stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5
                     5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5
                     a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                                />
                            </svg>
                            <p class="mb-2 text-sm text-gray-500 dark:text-gray-400">
                                <span class="font-semibold">Нажмите, чтобы загрузить</span> или перетащите сюда
                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400">
                                PDF, DOCX, JPG, PNG (макс. 50&nbsp;МБ)
                            </p>
                            <input
                                    id="dropzone-file"
                                    type="file"
                                    class="hidden"
                                    @change="onFileChange"
                                    :disabled="!categoryId"
                            />
                        </label>
                        <p v-if="error" class="mt-2 text-sm text-red-500">{{ error }}</p>

                        <div
                                v-if="form.file"
                                class="mt-3 text-gray-700 dark:text-gray-300"
                        >
                            <p>Выбран файл: {{ form.file.name }} ({{ fileSize }})</p>
                            <button
                                    type="button"
                                    @click="removeFile"
                                    class="mt-2 rounded-lg bg-red-600 px-4 py-2 text-white
                       hover:bg-red-700 focus:ring-4 focus:ring-red-300"
                            >
                                Сбросить файл
                            </button>
                        </div>
                    </div>

                    <!-- Описание -->
                    <div class="mb-5">
                        <label
                                for="description"
                                class="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
                        >
                            Описание
                        </label>
                        <input
                                v-model="form.description"
                                id="description"
                                type="text"
                                :disabled="!categoryId"
                                placeholder="Описание вложения"
                                class="w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-gray-900
                     focus:border-blue-500 focus:ring-blue-500
                     dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                        />
                    </div>

                    <!-- Ключевые слова -->
                    <div class="mb-5">
                        <label
                                for="keywords"
                                class="mb-2 block text-sm font-medium text-gray-900 dark:text-white"
                        >
                            Ключевые слова (через запятую)
                        </label>
                        <input
                                v-model="form.keywords"
                                id="keywords"
                                type="text"
                                :disabled="!categoryId"
                                placeholder="метка1, метка2"
                                class="w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-gray-900
                     focus:border-blue-500 focus:ring-blue-500
                     dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                        />
                    </div>

                    <!-- Кнопки -->
                    <div class="inline-flex rounded-md" role="group">
                        <button
                                type="submit"
                                :disabled="!categoryId"
                                class="rounded-l-lg bg-blue-700 px-5 py-2.5 text-sm font-medium text-white
                     hover:bg-blue-800 focus:ring-4 focus:ring-blue-300
                     disabled:cursor-not-allowed disabled:bg-blue-400
                     dark:bg-blue-600 dark:hover:bg-blue-700"
                        >
                            Добавить
                        </button>
                        <button
                                type="button"
                                @click="hide"
                                class="rounded-r-lg border border-gray-200 bg-white px-5 py-2.5 text-sm font-medium text-gray-900
                     hover:bg-gray-100 focus:ring-4 focus:ring-gray-100
                     dark:border-gray-600 dark:bg-gray-800 dark:text-gray-400"
                        >
                            Отмена
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed, onMounted } from 'vue'
    import { Modal }      from 'flowbite'
    import api            from '../../api/index.js';

    /* ---------- props / emits ---------- */
    const props = defineProps({
        modalId:    { type: String,           required: true },
        categoryId: { type: [Number, String], default: null }, // допускаем null
    })
    const emit = defineEmits(['saved'])

    /* ---------- state ---------- */
    const mode  = ref('text') // 'text' | 'file'
    const form  = ref({ content: '', file: null, description: '', keywords: '' })
    const error = ref('')

    /* ---------- file helpers ---------- */
    function onFileChange (e) {
        error.value = ''
        const f = e.target.files[0]
        if (!f) return
        if (f.size > 50 * 1024 * 1024) {
            error.value = 'Максимальный размер файла — 50 МБ'
            removeFile()
        } else {
            form.value.file = f
        }
    }
    function removeFile () {
        form.value.file = null
        const inp = document.getElementById('dropzone-file')
        if (inp) inp.value = ''
    }
    const fileSize = computed(() =>
    form.value.file ? (form.value.file.size / 1024 / 1024).toFixed(1) + ' МБ' : ''
    )

    /* ---------- modal ---------- */
    let modalInstance = null
    onMounted(() => {
        modalInstance = new Modal(document.getElementById(props.modalId), {
            placement: 'center',
            backdrop : 'dynamic',
        })
    })
    function show () { modalInstance?.show() }
    function hide () { modalInstance?.hide() }

    /* ---------- save ---------- */
    async function onSave () {
        error.value = ''

        if (mode.value === 'file' && !form.value.file) {
            error.value = 'Выберите файл'
            return
        }
        if (mode.value === 'text' && !form.value.content.trim()) {
            error.value = 'Введите текст'
            return
        }

        try {
            await api.uploadAttachment(props.categoryId, {
                file:        form.value.file,
                content:     form.value.content,
                description: form.value.description,
                keywords:    form.value.keywords,
            })
            emit('saved')
            hide()
            // сбрасываем форму
            form.value = { content: '', file: null, description: '', keywords: '' }
            mode.value = 'text'
        } catch (e) {
            error.value =
            'Не удалось сохранить: ' + (e.response?.data?.detail ?? e.message)
        }
    }

    /* ---------- expose ---------- */
    defineExpose({ show, hide })
</script>







