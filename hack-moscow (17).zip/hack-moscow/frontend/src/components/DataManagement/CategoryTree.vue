<!-- components/DataManagement/CategoryTree.vue -->
<template>
    <ul class="space-y-1">
        <li
                v-for="node in nodes"
                :key="node.id"
                class="group"
        >
            <div
                    @click="$emit('select', node)"
                    :class="[
          'flex items-center justify-between cursor-pointer py-2 px-4 rounded-lg transition-colors',
          node.id === selected?.id
            ? 'bg-blue-50 dark:bg-blue-900/50 font-semibold'
            : 'hover:bg-gray-100 dark:hover:bg-gray-800'
        ]"
            >
                <span class="text-gray-800 dark:text-gray-200">{{ node.title }}</span>
                <button
                        @click.stop="$emit('edit', node)"
                        title="Редактировать категорию"
                        class="flex items-center justify-center w-8 h-8 rounded-full transition-colors
                 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200
                 hover:bg-blue-200 dark:hover:bg-blue-800
                 focus:outline-none focus:ring-2 focus:ring-blue-300 dark:focus:ring-blue-600"
                >✎</button>
            </div>

            <!-- Рекурсивный вызов уже для готовой вложенности -->
            <CategoryTree
                    v-if="node.children?.length"
                    :nodes="node.children"
                    :selected="selected"
                    @select="$emit('select', $event)"
                    @edit ="$emit('edit',   $event)"
                    class="ml-6 border-l border-gray-200 dark:border-gray-700 pl-4"
            />
        </li>
    </ul>
</template>

<script setup>
    defineProps({
        nodes:    { type: Array, required: true },
        selected: { type: Object, default: null },
    });
    defineEmits(['select','edit']);

    import CategoryTree from './CategoryTree.vue';
</script>

<style scoped>
    ul { list-style: none; }
</style>
