<!-- Updated EditCategoryModal.vue -->
<template>
    <div
            :id="modalId"
            tabindex="-1"
            aria-hidden="true"
            class="fixed inset-0 z-50 hidden h-[calc(100%-1rem)] max-h-full w-full overflow-y-auto p-4"
    >
        <div class="relative mx-auto max-w-md">
            <div class="rounded-lg bg-white shadow-sm">
                <!-- Header -->
                <div class="flex items-center justify-between border-b p-5">
                    <h3 class="text-xl font-semibold">Редактировать категорию</h3>
                    <button @click="hide" class="text-gray-400 hover:bg-gray-200 rounded-lg p-1">✕</button>
                </div>
                <form @submit.prevent="onSave" class="p-6 space-y-4" v-if="formInitialized">
                    <div>
                        <label class="block mb-2 text-sm font-medium">Название категории</label>
                        <input
                                v-model="form.title"
                                type="text"
                                required
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <div>
                        <label class="block mb-2 text-sm font-medium">Описание</label>
                        <textarea
                                v-model="form.description"
                                class="w-full h-24 px-4 py-2 border rounded-lg"
                        ></textarea>
                    </div>
                    <div>
                        <label class="block mb-2 text-sm font-medium">Ключевые слова (через запятую)</label>
                        <input
                                v-model="form.keywords"
                                type="text"
                                class="w-full px-4 py-2 border rounded-lg"
                        />
                    </div>
                    <div class="text-sm text-gray-500">
                        <p>Путь (не редактируется): <code>{{ form.path }}</code></p>
                    </div>
                    <div class="flex justify-between pt-4 border-t">
                        <button type="button" @click="onDelete" class="px-5 py-2.5 bg-red-600 text-white rounded-lg">
                            Удалить
                        </button>
                        <div class="flex gap-2">
                            <button type="button" @click="hide" class="px-5 py-2.5 bg-white border rounded-lg">
                                Отмена
                            </button>
                            <button type="submit" class="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                                Сохранить
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, watch, onMounted } from 'vue';
    import { Modal } from 'flowbite';

    const props = defineProps({
        modalId: { type: String, required: true },
        category: { type: Object, required: false, default: null }
    });
    const emit = defineEmits(['save','delete']);

    const form = ref({ title: '', description: '', keywords: '', path: '' });
    const formInitialized = ref(false);
    let modalInstance = null;

    onMounted(() => {
        modalInstance = new Modal(document.getElementById(props.modalId), {
            placement: 'center',
            backdrop: 'dynamic'
        });
    });

    watch(
        () => props.category,
        (cat) => {
            if (cat) {
                form.value = {
                    title:       cat.title || '',
                    description: cat.description || '',
                    keywords:    Array.isArray(cat.keywords) ? cat.keywords.join(', ') : (cat.keywords || ''),
                    path:        cat.path || ''
                };
                formInitialized.value = true;
            } else {
                formInitialized.value = false;
            }
        },
        { immediate: true }
    );

    function show() { modalInstance.show() }
    function hide() { modalInstance.hide() }

    function onSave() {
        if (!props.category) return;
        emit('save', {
            title:       form.value.title,
            description: form.value.description,
            keywords:    form.value.keywords,
            path:        form.value.path
        });
        hide();
    }

    function onDelete() {
        if (!props.category) return;
        emit('delete');
        hide();
    }

    defineExpose({ show, hide });
</script>

