<!-- src/components/DataManagement/EditDataItemModal.vue -->
<template>
    <div
            :id="modalId"
            tabindex="-1"
            aria-hidden="true"
            class="fixed inset-0 z-50 hidden h-[calc(100%-1rem)] max-h-full w-full p-4 overflow-y-auto"
    >
        <div class="relative mx-auto max-w-md max-h-full w-full">
            <div class="rounded-lg bg-white shadow-sm dark:bg-gray-700">
                <!-- Header -->
                <div class="flex items-start justify-between border-b p-5 dark:border-gray-600">
                    <h3 class="text-xl font-semibold lg:text-2xl text-gray-900 dark:text-white">
                        Редактировать
                        {{ item?.mime_type.startsWith('text') ? 'текст' : 'файл' }}
                    </h3>
                    <button
                            type="button"
                            @click="hide"
                            class="inline-flex h-8 w-8 items-center justify-center rounded-lg text-gray-400
                   hover:bg-gray-200 dark:hover:bg-gray-600"
                    >✕</button>
                </div>

                <!-- Body / Form -->
                <form @submit.prevent="onSave" class="p-6 space-y-4" v-if="item">
                    <!-- Content or download link -->
                    <div>
                        <label v-if="item.mime_type.startsWith('text')" for="editContent"
                               class="block mb-1 text-sm font-medium text-gray-900 dark:text-white"
                        >
                            Текст
                        </label>
                        <textarea
                                v-if="item.mime_type.startsWith('text')"
                                id="editContent"
                                v-model="form.content"
                                rows="6"
                                class="w-full px-3 py-2 border rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100
                     focus:ring-blue-500 focus:border-blue-500"
                        ></textarea>
                        <div v-else>
                            <a :href="downloadUrl" target="_blank"
                               class="text-blue-600 dark:text-blue-400 underline"
                            >
                                Скачать файл
                            </a>
                        </div>
                    </div>

                    <!-- Description -->
                    <div>
                        <label for="editDescription"
                               class="block mb-1 text-sm font-medium text-gray-900 dark:text-white"
                        >
                            Описание
                        </label>
                        <input
                                id="editDescription"
                                v-model="form.description"
                                type="text"
                                class="w-full px-3 py-2 border rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100
                     focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>

                    <!-- Keywords -->
                    <div>
                        <label for="editKeywords"
                               class="block mb-1 text-sm font-medium text-gray-900 dark:text-white"
                        >
                            Ключевые слова (через запятую)
                        </label>
                        <input
                                id="editKeywords"
                                v-model="form.keywords"
                                type="text"
                                class="w-full px-3 py-2 border rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-gray-100
                     focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>

                    <!-- Footer Buttons -->
                    <div class="flex justify-end space-x-2 border-t pt-4">
                        <button
                                type="button"
                                @click="hide"
                                class="px-5 py-2.5 bg-gray-200 dark:bg-gray-600 text-gray-900 dark:text-gray-100 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-500 transition"
                        >
                            Отмена
                        </button>
                        <button
                                type="button"
                                @click="onDelete"
                                class="px-5 py-2.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
                        >
                            Удалить
                        </button>
                        <button
                                type="submit"
                                :disabled="loading"
                                class="px-5 py-2.5 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition disabled:opacity-50"
                        >
                            {{ loading ? 'Сохранение...' : 'Сохранить' }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, watch, onMounted, computed } from 'vue'
    import { Modal }           from 'flowbite'
    import api                  from '../../api/index.js';

    const props = defineProps({
        modalId: { type: String, required: true },
        item:    { type: Object, default: null },   // объект Attachment
    })
    const emit = defineEmits(['updated', 'deleted'])

    /* ---------- state ---------- */
    const form    = ref({ content: '', description: '', keywords: '', file: null })
    const loading = ref(false)
    const error   = ref('')

    /* ---------- реагируем на смену item ---------- */
    watch(
        () => props.item,
        (it) => {
            if (it) {
                form.value = {
                    content:     it.mime_type?.startsWith('text') ? it.content : '',
                    description: it.description ?? '',
                    keywords:    it.keywords    ?? '',
                    file:        null,           // новый файл (если нужен)
                }
            } else {
                form.value = { content: '', description: '', keywords: '', file: null }
            }
        },
        { immediate: true }
    )

    /* ---------- computed ---------- */
    const downloadUrl = computed(() =>
    props.item ? api.downloadAttachment(props.item.id) : '#'
    )

    /* ---------- modal ---------- */
    let modalInstance = null
    onMounted(() => {
        modalInstance = new Modal(document.getElementById(props.modalId), {
            placement: 'center',
            backdrop : 'dynamic',
        })
    })
    function show () { modalInstance.show() }
    function hide () { modalInstance.hide() }

    /* ---------- save ---------- */
    async function onSave () {
        if (!props.item) return
        loading.value = true
        error.value   = ''
        try {
            await api.updateAttachment(props.item.id, {
                content:     form.value.content,
                description: form.value.description,
                keywords:    form.value.keywords,
                file:        form.value.file,      // может быть null
            })
            emit('updated')
            hide()
        } catch (e) {
            error.value = 'Ошибка при сохранении: ' + (e.response?.data?.detail ?? e.message)
        } finally {
            loading.value = false
        }
    }

    /* ---------- delete ---------- */
    async function onDelete () {
        if (!props.item) return
        try {
            await api.deleteAttachment(props.item.id)
            emit('deleted')
            hide()
        } catch (e) {
            error.value = 'Не удалось удалить: ' + (e.response?.data?.detail ?? e.message)
        }
    }

    defineExpose({ show })
</script>



