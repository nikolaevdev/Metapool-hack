<!-- components/DataManagement/PoolDetail.vue -->
<template>
    <div class="flex-1 space-y-8">
        <!-- Блок 1: Информация о пуле -->
        <section class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <header class="flex justify-between items-center mb-6">
                <h2 class="text-2xl font-bold text-gray-900 dark:text-gray-100">{{ pool.name }}</h2>
                <div class="flex space-x-2">
                    <button
                            @click="$emit('editPool')"
                            class="px-3 py-1.5 bg-yellow-500 text-white rounded-lg shadow hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition dark:bg-yellow-400 dark:hover:bg-yellow-500"
                    >
                        ✎ Редактировать пул
                    </button>
                    <button
                            @click="$emit('back')"
                            class="px-3 py-1.5 bg-gray-200 text-gray-800 rounded-lg shadow hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400 transition dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600"
                    >
                        ← Назад
                    </button>
                </div>
            </header>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-blue-50 dark:bg-blue-900 p-4 rounded-lg">
                    <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200 mb-2">Описание пула</h3>
                    <p class="text-gray-600 dark:text-gray-300">{{ pool.description || '—' }}</p>
                </div>
                <div class="bg-purple-50 dark:bg-purple-900 p-4 rounded-lg">
                    <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200 mb-2">Ключевые слова</h3>
                    <div class="flex flex-wrap gap-2">
            <span
                    v-for="(kw, idx) in poolKeywords"
                    :key="`pool-kw-${idx}`"
                    class="text-xs bg-purple-200 text-purple-800 px-2 py-1 rounded-full dark:bg-purple-700 dark:text-purple-100"
            >
              {{ kw }}
            </span>
                        <span v-if="!poolKeywords.length" class="text-gray-500 dark:text-gray-400 text-sm">—</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Блок 2: Категории пула -->
        <section class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-gray-100">Категории пула</h3>
                <button
                        @click="$emit('addCategory')"
                        class="px-3 py-1.5 bg-green-500 text-white rounded-lg shadow hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-400 transition dark:bg-green-400 dark:hover:bg-green-500"
                >
                    + Категория
                </button>
            </div>
            <CategoryTree
                    :nodes="tree"
                    :selected="selectedCategory"
                    @select="$emit('selectCategory', $event)"
                    @edit ="$emit('editCategory',   $event)"
            />
        </section>

        <!-- Блок 3: Данные пула / выбранной категории -->
        <section class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-xl font-semibold text-gray-900 dark:text-gray-100">
                    {{ selectedCategory ? selectedCategory.title : 'Данные пула' }}
                </h3>
                <div class="flex space-x-2">
                    <button
                            @click="$emit('addCategory')"
                            class="px-3 py-1.5 bg-green-500 text-white rounded-lg shadow hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-400 transition dark:bg-green-400 dark:hover:bg-green-500"
                    >
                        + Категория
                    </button>
                    <button
                            @click="$emit('addData')"
                            class="px-3 py-1.5 bg-blue-500 text-white rounded-lg shadow hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition dark:bg-blue-400 dark:hover:bg-blue-500"
                    >
                        + Данные
                    </button>
                    <button
                            v-if="selectedCategory"
                            @click="$emit('editCategory', selectedCategory)"
                            class="px-3 py-1.5 bg-purple-500 text-white rounded-lg shadow hover:bg-purple-600 focus:outline-none focus:ring-2 focus:ring-purple-400 transition dark:bg-purple-400 dark:hover:bg-purple-500"
                    >
                        ✎ Редактировать
                    </button>
                </div>
            </div>

            <template v-if="!selectedCategory">
                <p class="text-gray-600 dark:text-gray-300">
                    Вы можете добавить новую категорию или данные в пул.
                </p>
            </template>

            <template v-else>
                <section class="border border-gray-200 dark:border-gray-700 rounded-lg p-6 space-y-4">
                    <section>
                        <h4 class="font-semibold text-sm uppercase text-gray-700 dark:text-gray-300 mb-2">Описание категории</h4>
                        <p class="text-gray-600 dark:text-gray-300">{{ selectedCategory.description || '—' }}</p>
                    </section>
                    <section>
                        <h4 class="font-semibold text-sm uppercase text-gray-700 dark:text-gray-300 mb-2">Ключевые слова категории</h4>
                        <div class="flex flex-wrap gap-2">
              <span
                      v-for="(kw, idx) in categoryKeywords"
                      :key="`cat-kw-${idx}`"
                      class="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded-full dark:bg-blue-700 dark:text-blue-100"
              >
                {{ kw }}
              </span>
                            <span v-if="!categoryKeywords.length" class="text-gray-500 dark:text-gray-400 text-sm">—</span>
                        </div>
                    </section>

                    <div v-if="categoryItems.length" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <AttachmentCard
                                v-for="att in categoryItems"
                                :key="att.id"
                                :item="att"
                                @edit="$emit('editData', att)"
                                @delete="$emit('deleteData', att)"
                        />
                    </div>
                    <p v-else class="text-center text-gray-500 dark:text-gray-400 py-8">
                        В этой категории пока нет данных. Нажмите «+ Данные», чтобы добавить.
                    </p>
                </section>
            </template>
        </section>
    </div>
</template>

<script setup>
    import { computed } from 'vue'
    import CategoryTree from './CategoryTree.vue'
    import AttachmentCard from './AttachmentCard.vue'

    const props = defineProps({
        pool: Object,
        categories: Array,
        selectedCategory: Object,
        dataItems: Array,
    })
    const emit = defineEmits([
        'back',
        'editPool',
        'selectCategory',
        'addCategory',
        'addData',
        'editCategory',
        'editData',
        'deleteData',
    ])

    const poolKeywords = computed(() =>
    props.pool.keywords
    ? props.pool.keywords.split(',').map(s => s.trim()).filter(Boolean)
    : []
    )

    const categoryKeywords = computed(() =>
    props.selectedCategory?.keywords
    ? props.selectedCategory.keywords.split(',').map(s => s.trim()).filter(Boolean)
    : []
    )

    // Функция для сборки дерева
    function buildTree(cats) {
        const map = {};
        cats.forEach(cat => {
            map[cat.path] = { ...cat, children: [] };
        });
        cats.forEach(cat => {
            const idx = cat.path.lastIndexOf('.');
            if (idx !== -1) {
                const parentPath = cat.path.slice(0, idx);
                map[parentPath]?.children.push(map[cat.path]);
            }
        });
        // корневые — те, у которых в path нет точки
        return Object.values(map).filter(node => !node.path.includes('.'));
    }

    const tree = computed(() => buildTree(props.categories));

    const categoryItems = computed(() =>
    props.dataItems.filter(it => it.category_id === props.selectedCategory?.id)
    )
</script>
