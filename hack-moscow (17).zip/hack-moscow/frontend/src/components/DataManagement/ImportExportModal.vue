<template>
    <div
            :id="modalId"
            tabindex="-1"
            aria-hidden="true"
            class="fixed inset-0 z-50 hidden h-[calc(100%-1rem)] max-h-full w-full
           overflow-y-auto overflow-x-hidden p-4 md:inset-0"
    >
        <div class="relative w-full max-w-lg max-h-full mx-auto">
            <div class="relative rounded-lg bg-white shadow-sm dark:bg-gray-700">

                <!-- Заголовок -->
                <div
                        class="flex items-start justify-between rounded-t border-b p-5
                 dark:border-gray-600"
                >
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        Импорт / Экспорт пула
                    </h3>
                    <button
                            type="button"
                            class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900
                   rounded-lg text-sm p-1.5 ml-auto inline-flex items-center
                   dark:hover:bg-gray-600 dark:hover:text-white"
                            @click="hide"
                            :disabled="loadingImport"
                    >
                        <svg
                                aria-hidden="true"
                                class="w-5 h-5"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                        >
                            <path
                                    fill-rule="evenodd"
                                    d="M4.293 4.293a1 1 0 011.414 0L10
                   8.586l4.293-4.293a1 1 0 111.414
                   1.414L11.414 10l4.293 4.293a1 1
                   0 01-1.414 1.414L10 11.414l-4.293
                   4.293a1 1 0 01-1.414-1.414L8.586
                   10 4.293 5.707a1 1 0 010-1.414z"
                                    clip-rule="evenodd"
                            />
                        </svg>
                        <span class="sr-only">Закрыть</span>
                    </button>
                </div>

                <div class="p-6 space-y-6 dark:text-white">

                    <!-- Режим: существующий или новый пул -->
                    <div class="mb-4">
                        <label class="inline-flex items-center mr-4">
                            <input type="radio" class="form-radio" value="existing" v-model="mode" />
                            <span class="ml-2">Существующий пул</span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" class="form-radio" value="new" v-model="mode" />
                            <span class="ml-2">Новый пул</span>
                        </label>
                    </div>

                    <!-- Выбор существующего пула -->
                    <div v-if="mode==='existing'" class="mb-4">
                        <label class="block mb-2 text-sm font-medium">Найти пул:</label>
                        <input
                                type="text"
                                v-model="searchTerm"
                                placeholder="Поиск по названию"
                                class="w-full p-2 border rounded"
                        />
                        <ul class="mt-2 max-h-32 overflow-y-auto border rounded">
                            <li
                                    v-for="p in filteredPools"
                                    :key="p.id"
                                    @click="selectPool(p)"
                                    :class="{
                  'bg-blue-100': selectedPool && selectedPool.id === p.id,
                  'cursor-pointer p-2': true
                }"
                            >
                                {{ p.name }}
                            </li>
                        </ul>
                    </div>

                    <!-- Ввод имени нового пула -->
                    <div v-else class="mb-4">
                        <label class="block mb-2 text-sm font-medium">Название нового пула:</label>
                        <input
                                type="text"
                                v-model="newPoolName"
                                class="w-full p-2 border rounded"
                        />
                    </div>

                    <!-- Экспорт существующего пула -->
                    <div v-if="mode==='existing'" class="mb-4">
                        <button
                                type="button"
                                :disabled="!selectedPool || loadingExport"
                                @click="doExport"
                                class="w-full flex justify-center items-center
                     text-white bg-green-600 hover:bg-green-700 focus:ring-4
                     focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5"
                        >
                            <svg
                                    v-if="loadingExport"
                                    class="w-5 h-5 mr-2 animate-spin text-white"
                                    viewBox="0 0 24 24"
                            >
                                <circle
                                        class="opacity-25"
                                        cx="12"
                                        cy="12"
                                        r="10"
                                        stroke="currentColor"
                                        stroke-width="4"
                                />
                                <path
                                        class="opacity-75"
                                        fill="currentColor"
                                        d="M4 12a8 8 0 018-8v8z"
                                />
                            </svg>
                            {{ loadingExport ? 'Скачиваю...' : 'Скачать пул' }}
                        </button>
                    </div>

                    <!-- Зона Drag-&-Drop + кнопка выбора файла -->
                    <div class="mb-4">
                        <label class="block mb-2 text-sm font-medium dark:text-white">
                            Файл ZIP пула:
                        </label>
                        <div
                                class="relative flex flex-col items-center justify-center w-full h-32
                     border-2 border-dashed rounded cursor-pointer
                     bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                                @drop.prevent="onFileDrop"
                                @dragover.prevent
                        >
                            <p class="text-gray-500 dark:text-gray-400">
                                Перетащите файл сюда или кликните для выбора
                            </p>
                            <input
                                    type="file"
                                    accept=".zip"
                                    @change="onImportChange"
                                    class="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                            />
                        </div>
                        <div v-if="error" class="mt-2 text-red-600 dark:text-red-400">
                            {{ error }}
                        </div>
                        <div v-if="importFile" class="mt-2 text-gray-700 dark:text-gray-300">
                            {{ importFile.name }} ({{ importSize }})
                            <button @click="clearImport" class="ml-2 text-sm text-red-600">✖</button>
                        </div>
                    </div>

                    <!-- Кнопка «Импортировать» -->
                    <div class="mb-4">
                        <button
                                type="button"
                                :disabled="!importFile || !(mode==='new'? newPoolName.trim(): selectedPool) || loadingImport"
                                @click="doImport"
                                class="w-full flex justify-center items-center
                     text-white bg-blue-700 hover:bg-blue-800 focus:ring-4
                     focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5"
                        >
                            <svg
                                    v-if="loadingImport"
                                    class="w-5 h-5 mr-2 animate-spin text-white"
                                    viewBox="0 0 24 24"
                            >
                                <circle
                                        class="opacity-25"
                                        cx="12"
                                        cy="12"
                                        r="10"
                                        stroke="currentColor"
                                        stroke-width="4"
                                />
                                <path
                                        class="opacity-75"
                                        fill="currentColor"
                                        d="M4 12a8 8 0 018-8v8z"
                                />
                            </svg>
                            {{ loadingImport ? 'Импортирую...' : 'Импортировать' }}
                        </button>
                    </div>

                    <!-- Индикатор прогресса -->
                    <div v-if="loadingImport" class="mb-4">
                        <progress :value="importProgress" max="100" class="w-full h-3 rounded"></progress>
                        <p class="text-center mt-1 dark:text-white">{{ importProgress }}%</p>
                    </div>

                    <!-- Сообщения об успешном/неудачном импорте -->
                    <div v-if="importSuccess" class="mb-2 text-green-600 dark:text-green-400">
                        ✅ Импорт завершён успешно.
                    </div>
                    <div v-if="importError" class="mb-2 text-red-600 dark:text-red-400">
                        ❌ Ошибка при импорте: {{ importError }}
                    </div>

                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
    import { ref, computed, onMounted } from "vue";
    import { Modal } from "flowbite";
    import api from "../../api/index.js";

    const props = defineProps({
        modalId: { type: String, required: true },
        pools:   { type: Array,  required: true },
    });

    const mode           = ref("existing");
    const searchTerm     = ref("");
    const selectedPool   = ref(null);
    const newPoolName    = ref("");
    const importFile     = ref(null);
    const error          = ref("");
    const importError    = ref("");
    const importSuccess  = ref(false);
    const loadingExport  = ref(false);
    const loadingImport  = ref(false);
    const importProgress = ref(0);

    const importSize = computed(() => {
        if (!importFile.value) return "";
        const mb = importFile.value.size / (1024 * 1024);
        return mb.toFixed(2) + " МБ";
    });

    const filteredPools = computed(() => {
        if (!searchTerm.value) return props.pools;
        return props.pools.filter(p =>
        p.name.toLowerCase().includes(searchTerm.value.toLowerCase())
        );
    });

    function selectPool(p) {
        selectedPool.value = p;
    }

    function clearImport() {
        importFile.value     = null;
        importProgress.value = 0;
        importError.value    = "";
        importSuccess.value  = false;
        error.value          = "";
    }

    function processImportFile(f) {
        error.value = "";
        if (!f) return;
        if (f.size > 50 * 1024 * 1024) {
            error.value = "Максимальный размер файла — 50 МБ";
            clearImport();
        } else {
            importFile.value = f;
        }
    }

    function onImportChange(e) {
        processImportFile(e.target.files?.[0]);
    }

    function onFileDrop(e) {
        processImportFile(e.dataTransfer.files[0]);
    }

    async function doExport() {
        if (!selectedPool.value) return;
        loadingExport.value = true;
        try {
            const resp = await api.exportPool(selectedPool.value.id);
            const blob = new Blob([resp.data], { type: "application/zip" });
            const url  = URL.createObjectURL(blob);
            const a    = document.createElement("a");
            a.href     = url;
            a.download = `pool_${selectedPool.value.id}.zip`;
            a.click();
            URL.revokeObjectURL(url);
        } finally {
            loadingExport.value = false;
        }
    }

    async function doImport() {
        if (!importFile.value) return;
        if (mode.value === "new" && !newPoolName.value.trim()) return;
        if (mode.value === "existing" && !selectedPool.value) return;

        loadingImport.value  = true;
        importProgress.value = 0;
        importError.value    = "";
        importSuccess.value  = false;

        const form = new FormData();
        form.append("file", importFile.value);
        if (mode.value === "existing") {
            form.append("pool_id", String(selectedPool.value.id));
        } else {
            form.append("poolName", newPoolName.value.trim());
        }

        try {
            await api.importPools(form, {
                onUploadProgress: ev => {
                    if (ev.lengthComputable) {
                        importProgress.value = Math.round((ev.loaded * 100) / ev.total);
                    }
                }
            });
            importSuccess.value = true;
            clearImport();
            hide();
        } catch (err) {
            importError.value = err.response?.data?.detail
            || err.response?.data?.message
            || err.message;
        } finally {
            loadingImport.value = false;
        }
    }

    let modalInst = null;
    onMounted(() => {
        modalInst = new Modal(
            document.getElementById(props.modalId),
            { placement: "center", backdrop: "dynamic" }
        );
    });

    function show() { modalInst.show(); }
    function hide() { modalInst.hide(); }
    defineExpose({ show, hide });
</script>

<style scoped>
    /* При необходимости добавьте стили для .dropzone или прогресс-бара */
</style>
