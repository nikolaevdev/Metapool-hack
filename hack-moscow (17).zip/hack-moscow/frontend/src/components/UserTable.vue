<template>
    <div class="bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden">
        <!-- Заголовок -->
        <div class="p-4 sm:p-6 border-b dark:border-gray-700 flex justify-between items-center">
            <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Список пользователей</h2>
            <button
                    v-if="canChangeUser"
                    @click="openModal(null)"
                    type="button"
                    class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:focus:ring-blue-800"
            >
                <PlusIcon class="h-5 w-5 inline-block mr-1 -ml-1" />
                Новый пользователь
            </button>
        </div>

        <!-- Состояние загрузки / пусто -->
        <div v-if="loading" class="p-6 text-center text-gray-500 dark:text-gray-400">
            Загрузка пользователей...
        </div>
        <div v-else-if="!users.length" class="p-6 text-center text-gray-500 dark:text-gray-400">
            Пользователи не найдены.
        </div>

        <!-- Таблица -->
        <div v-else class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th class="px-6 py-3">ID</th>
                    <th class="px-6 py-3">Email</th>
                    <th class="px-6 py-3">Логин</th>
                    <th class="px-6 py-3">Имя</th>
                    <th class="px-6 py-3">Фамилия</th>
                    <th class="px-6 py-3">Активен</th>
                    <th class="px-6 py-3">Заблокирован</th>
                    <th class="px-6 py-3">2FA</th>
                    <th class="px-6 py-3">Роли</th>
                    <th class="px-6 py-3 text-right">Действия</th>
                </tr>
                </thead>
                <tbody>
                <tr
                        v-for="u in users"
                        :key="u.id"
                        class="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                    <td class="px-6 py-4">{{ u.id }}</td>
                    <td class="px-6 py-4">{{ u.email }}</td>
                    <td class="px-6 py-4">{{ u.username }}</td>
                    <td class="px-6 py-4">{{ u.first_name || '-' }}</td>
                    <td class="px-6 py-4">{{ u.last_name || '-' }}</td>

                    <!-- Активен -->
                    <td class="px-6 py-4">
              <span
                      :class="u.is_active
                  ? 'inline-block px-2 py-0.5 text-xs font-medium text-green-800 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-300'
                  : 'inline-block px-2 py-0.5 text-xs font-medium text-red-800 bg-red-100 rounded-full dark:bg-red-900 dark:text-red-300'"
              >
                {{ u.is_active ? 'Да' : 'Нет' }}
              </span>
                    </td>

                    <!-- Заблокирован -->
                    <td class="px-6 py-4">
              <span
                      :class="!u.is_blocked
                  ? 'inline-block px-2 py-0.5 text-xs font-medium text-green-800 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-300'
                  : 'inline-block px-2 py-0.5 text-xs font-medium text-red-800 bg-red-100 rounded-full dark:bg-red-900 dark:text-red-300'"
              >
                {{ u.is_blocked ? 'Да' : 'Нет' }}
              </span>
                    </td>

                    <!-- 2FA -->
                    <td class="px-6 py-4">
              <span
                      :class="u.is_twofa_enabled
                  ? 'inline-block px-2 py-0.5 text-xs font-medium text-green-800 bg-green-100 rounded-full dark:bg-green-900 dark:text-green-300'
                  : 'inline-block px-2 py-0.5 text-xs font-medium text-red-800 bg-red-100 rounded-full dark:bg-red-900 dark:text-red-300'"
              >
                {{ u.is_twofa_enabled ? 'Вкл.' : 'Выкл.' }}
              </span>
                    </td>

                    <td class="px-6 py-4">
              <span
                      v-for="r in u.roles"
                      :key="r.id"
                      class="inline-block bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 text-xs px-2 py-1 rounded mr-1"
              >
                {{ r.name }}
              </span>
                    </td>
                    <td class="px-6 py-4 text-right space-x-2">
                        <button
                                v-if="canChangeUser"
                                @click="openModal(u)"
                                class="text-blue-600 hover:underline p-1"
                                type="button"
                        >
                            <PencilIcon class="h-5 w-5 inline" />
                        </button>
                        <button
                                v-if="canDeleteUser"
                                @click="confirmDelete(u.id)"
                                class="text-red-600 hover:underline p-1"
                                type="button"
                        >
                            <TrashIcon class="h-5 w-5 inline" />
                        </button>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>

        <!-- Модальное окно -->
        <div
                id="userModal"
                ref="modalEl"
                tabindex="-1"
                aria-hidden="true"
                class="fixed inset-0 z-50 hidden overflow-y-auto p-4"
        >
            <div class="relative mx-auto max-w-2xl h-full">
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
                    <!-- Заголовок -->
                    <div class="flex items-start justify-between p-5 border-b dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            {{ isEdit ? 'Редактировать пользователя' : 'Создать пользователя' }}
                        </h3>
                        <button
                                @click="hideModal"
                                type="button"
                                class="text-gray-400 hover:bg-gray-200 hover:text-gray-900 rounded-lg p-1.5 dark:hover:bg-gray-600 dark:hover:text-white"
                        >
                            <XMarkIcon class="w-5 h-5" />
                        </button>
                    </div>

                    <!-- Форма -->
                    <form @submit.prevent="save" class="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                        <!-- Email, логин, пароль -->
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Email *</label>
                            <input
                                    v-model="form.email"
                                    type="email"
                                    :disabled="isEdit"
                                    required
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            />
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Логин *</label>
                            <input
                                    v-model="form.username"
                                    type="text"
                                    :disabled="isEdit"
                                    required
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            />
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                                Пароль {{ isEdit ? '(необязательно)' : '*' }}
                            </label>
                            <input
                                    v-model="form.password"
                                    type="password"
                                    :required="!isEdit"
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            />
                        </div>

                        <!-- Имя и фамилия -->
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Имя</label>
                            <input
                                    v-model="form.first_name"
                                    type="text"
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            />
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Фамилия</label>
                            <input
                                    v-model="form.last_name"
                                    type="text"
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600"
                            />
                        </div>

                        <!-- Активен / Заблокирован -->
                        <div class="flex items-center space-x-6">
                            <div class="flex items-center">
                                <input
                                        id="is_active"
                                        type="checkbox"
                                        v-model="form.is_active"
                                        class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                                />
                                <label for="is_active" class="ml-2 text-sm text-gray-900 dark:text-gray-300">Активен</label>
                            </div>
                            <div class="flex items-center">
                                <input
                                        id="is_blocked"
                                        type="checkbox"
                                        v-model="form.is_blocked"
                                        class="w-4 h-4 text-red-600 bg-gray-100 border-gray-300 rounded focus:ring-red-500"
                                />
                                <label for="is_blocked" class="ml-2 text-sm text-gray-900 dark:text-gray-300">Заблокирован</label>
                            </div>
                        </div>

                        <!-- Отключить 2FA -->
                        <div v-if="isEdit && canDisable2FA" class="flex items-center">
                            <input
                                    id="disable_2fa"
                                    type="checkbox"
                                    v-model="form.disable_twofa"
                                    class="w-4 h-4 text-yellow-500 bg-gray-100 border-gray-300 rounded focus:ring-yellow-500"
                            />
                            <label for="disable_2fa" class="ml-2 text-sm text-gray-900 dark:text-gray-300">
                                Отключить двухфакторную аутентификацию
                            </label>
                        </div>

                        <!-- Роли -->
                        <fieldset class="pt-3 border-t dark:border-gray-700">
                            <legend class="sr-only">Роли</legend>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-2 max-h-48 overflow-y-auto border dark:border-gray-600 rounded-md">
                                <div v-for="r in allRoles" :key="r.id" class="flex items-center mb-4">
                                    <input
                                            type="checkbox"
                                            :id="'user_role_' + r.id"
                                            :value="r.id"
                                            v-model="form.roles"
                                            class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                                    />
                                    <label :for="'user_role_' + r.id" class="ml-2 text-sm text-gray-900 dark:text-gray-300">
                                        {{ r.name }}
                                    </label>
                                </div>
                            </div>
                        </fieldset>

                        <!-- Ошибка -->
                        <p v-if="error" class="text-red-500 text-sm">{{ error }}</p>

                        <!-- Кнопки -->
                        <div class="flex justify-end space-x-2 pt-4 border-t dark:border-gray-700">
                            <button
                                    @click="hideModal"
                                    type="button"
                                    class="px-4 py-2 text-sm font-medium text-gray-500 bg-white border rounded-lg hover:bg-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                            >
                                Отмена
                            </button>
                            <button
                                    type="submit"
                                    :disabled="saving"

                                    class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-75"
                            >
                                {{ saving ? 'Сохранение…' : (isEdit ? 'Сохранить' : 'Создать') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref, computed, onMounted } from 'vue';
    import { useStore } from 'vuex';
    import { initFlowbite, Modal, type ModalInterface, type ModalOptions } from 'flowbite';
    import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon } from '@heroicons/vue/24/outline';

    const store = useStore();

    const users = computed(() => store.getters['user/allUsers']);
    const loading = computed(() => store.getters['user/userStatus'] === 'loading' && !users.value.length);
    const allRoles = computed(() => store.getters['role/allRoles']);

    const canChangeUser = computed(() => store.getters['auth/hasPermission']('change_user'));
    const canDeleteUser = computed(() => store.getters['auth/hasPermission']('delete_user'));
    const canDisable2FA = computed(() => store.getters['auth/hasPermission']('disable_twofa'));

    const modalEl = ref<HTMLElement | null>(null);
    let modal: ModalInterface;

    const isEdit = ref(false);
    const saving = ref(false);
    const error = ref<string | null>(null);

    const defaultForm = {
    id: null as number | null,
    email: '',
    username: '',
    password: '',
    first_name: '',
    last_name: '',
    is_active: true,
    is_blocked: false,
    disable_twofa: false,
    roles: [] as number[],
    };
    const form = ref({ ...defaultForm });

    onMounted(async () => {
    initFlowbite();
    if (modalEl.value) {
    const opts: ModalOptions = { backdrop: 'dynamic', closable: true };
    modal = new Modal(modalEl.value, opts, { override: true });
    }
    await store.dispatch('role/fetchRoles');
    await store.dispatch('user/fetchUsers');
    });

    function openModal(u: any | null) {
    isEdit.value = !!u;
    error.value = null;
    if (u) {
    form.value = {
    id: u.id,
    email: u.email,
    username: u.username,
    password: '',
    first_name: u.first_name || '',
    last_name: u.last_name || '',
    is_active: u.is_active,
    is_blocked: u.is_blocked,
    disable_twofa: false,
    roles: u.roles.map((r: any) => r.id),
    };
    } else {
    Object.assign(form.value, defaultForm);
    }
    modal.show();
    }

    function hideModal() {
    modal.hide();
    }

    async function save() {
    saving.value = true;
    error.value = null;
    try {
    if (isEdit.value) {
    const payload: any = {
    first_name: form.value.first_name,
    last_name: form.value.last_name,
    is_active: form.value.is_active,
    is_blocked: form.value.is_blocked,
    roles: form.value.roles,
    };
    if (form.value.password) payload.password = form.value.password;
    if (form.value.disable_twofa) payload.disable_twofa = true;
    await store.dispatch('user/updateUser', { userId: form.value.id, userData: payload });
    } else {
    const payload: any = {
    email: form.value.email,
    username: form.value.username,
    password: form.value.password,
    first_name: form.value.first_name,
    last_name: form.value.last_name,
    is_active: form.value.is_active,
    is_blocked: form.value.is_blocked,
    roles: form.value.roles,
    };
    await store.dispatch('user/createUser', payload);
    }
    await store.dispatch('user/fetchUsers');
    hideModal();
    } catch {
    error.value = 'Не удалось сохранить пользователя.';
    } finally {
    saving.value = false;
    }
    }

    async function confirmDelete(id: number) {
    if (!confirm('Удалить пользователя?')) return;
    try {
    await store.dispatch('user/deleteUser', id);
    await store.dispatch('user/fetchUsers');
    } catch {
    alert('Не удалось удалить пользователя.');
    }
    }
</script>

<style scoped>
    /* дополнительные стили */
</style>
