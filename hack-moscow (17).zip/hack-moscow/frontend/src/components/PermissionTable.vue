<!-- src/components/PermissionTable.vue -->
<template>
    <div class="bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden">
        <div class="p-4 sm:p-6 border-b dark:border-gray-700 flex justify-between items-center">
            <h2 class="text-xl font-semibold text-gray-800 dark:text-white">Управление правами</h2>
            <button
                    v-if="canManagePerms"
                    @click="openCreatePermModal"
                    type="button"
                    class="text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:focus:ring-blue-800"
            >
                <PlusIcon class="h-5 w-5 inline-block mr-1 -ml-1" />
                Создать право
            </button>
        </div>

        <div v-if="loadingPerms" class="p-6 text-center text-gray-500 dark:text-gray-400">
            Загрузка прав...
        </div>
        <div v-else-if="!permissions.length" class="p-6 text-center text-gray-500 dark:text-gray-400">
            Права не найдены.
        </div>
        <div v-else class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th class="px-6 py-3">ID</th>
                    <th class="px-6 py-3">Название</th>
                    <th class="px-6 py-3">Codename</th>
                    <th class="px-6 py-3">Описание</th>
                    <th class="px-6 py-3 text-right">Действия</th>
                </tr>
                </thead>
                <tbody>
                <tr
                        v-for="p in permissions"
                        :key="p.id"
                        class="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                    <td class="px-6 py-4">{{ p.id }}</td>
                    <td class="px-6 py-4">{{ p.name }}</td>
                    <td class="px-6 py-4">{{ p.codename }}</td>
                    <td class="px-6 py-4">{{ p.description }}</td>
                    <td class="px-6 py-4 text-right space-x-2">
                        <button
                                v-if="canManagePerms"
                                @click="openEditPermModal(p)"
                                type="button"
                                class="text-blue-600 hover:underline p-1"
                        >
                            <PencilIcon class="h-5 w-5 inline" />
                        </button>
                        <button
                                v-if="canManagePerms"
                                @click="confirmDeletePerm(p.id)"
                                type="button"
                                class="text-red-600 hover:underline p-1"
                        >
                            <TrashIcon class="h-5 w-5 inline" />
                        </button>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>

        <div
                id="permModal"
                ref="modalEl"
                tabindex="-1"
                aria-hidden="true"
                class="fixed inset-0 z-50 hidden overflow-y-auto p-4"
        >
            <div class="relative p-4 w-full max-w-2xl max-h-full">
                <div class="relative bg-white rounded-lg shadow dark:bg-gray-800">
                    <div class="flex items-start justify-between p-5 border-b dark:border-gray-700">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            {{ isEditMode ? 'Редактировать право' : 'Создать право' }}
                        </h3>
                        <button
                                @click="hideModal"
                                type="button"
                                class="text-gray-400 hover:bg-gray-200 hover:text-gray-900 rounded-lg p-1.5 dark:hover:bg-gray-600 dark:hover:text-white"
                        >
                            <XMarkIcon class="w-5 h-5" />
                            <span class="sr-only">Закрыть</span>
                        </button>
                    </div>
                    <form @submit.prevent="savePerm" class="p-6 space-y-4">
                        <div v-if="!isEditMode">
                            <label
                                    for="perm_name"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                                Название *
                            </label>
                            <input
                                    id="perm_name"
                                    v-model="permForm.name"
                                    required
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                            />
                        </div>

                        <div v-if="!isEditMode">
                            <label
                                    for="perm_codename"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                                Codename *
                            </label>
                            <input
                                    id="perm_codename"
                                    v-model="permForm.codename"
                                    required
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                            />
                        </div>

                        <div>
                            <label
                                    for="perm_description"
                                    class="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                            >
                                Описание
                            </label>
                            <textarea
                                    id="perm_description"
                                    rows="3"
                                    v-model="permForm.description"
                                    class="block w-full p-2.5 text-sm rounded-lg border bg-gray-50 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white"
                            ></textarea>
                        </div>

                        <p v-if="errorMsg" class="text-red-500 text-sm">{{ errorMsg }}</p>

                        <div class="flex justify-end space-x-2 pt-4 border-t dark:border-gray-700">
                            <button
                                    @click="hideModal"
                                    type="button"
                                    class="px-4 py-2 text-sm font-medium text-gray-500 bg-white border rounded-lg hover:bg-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-300"
                            >
                                Отмена
                            </button>
                            <button
                                    type="submit"
                                    :disabled="saving"
                                    class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-300 disabled:opacity-75 dark:focus:ring-blue-800"
                            >
                                <span v-if="saving">Сохранение...</span>
                                <span v-else>{{ isEditMode ? 'Сохранить' : 'Создать' }}</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref, computed, onMounted } from 'vue';
    import { useStore } from 'vuex';
    import { initFlowbite, Modal, type ModalInterface, type ModalOptions } from 'flowbite';
    import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon } from '@heroicons/vue/24/outline';

    const store = useStore();

    const permissions = computed(() => store.getters['role/allSystemPermissions']);
    const loadingPerms = computed(
    () => store.getters['role/roleStatus'] === 'loading' && !permissions.value.length
    );

    const canManagePerms = computed(() =>
    store.getters['auth/hasPermission']('add_permission') &&
    store.getters['auth/hasPermission']('change_permission') &&
    store.getters['auth/hasPermission']('delete_permission')
    );

    const modalEl = ref<HTMLElement | null>(null);
    let modal: ModalInterface;

    const isEditMode = ref(false);
    const saving = ref(false);
    const errorMsg = ref('');

    const defaultForm = {
    id: null as number | null,
    name: '',
    codename: '',
    description: '',
    };
    const permForm = ref({ ...defaultForm });

    onMounted(async () => {
    initFlowbite();
    if (modalEl.value) {
    const opts: ModalOptions = { backdrop: 'dynamic', closable: true };
    modal = new Modal(modalEl.value, opts, { override: true });
    }
    await store.dispatch('role/fetchPermissions');
    });

    function openCreatePermModal() {
    isEditMode.value = false;
    Object.assign(permForm.value, defaultForm);
    errorMsg.value = '';
    modal.show();
    }

    function openEditPermModal(p: any) {
    isEditMode.value = true;
    permForm.value.id = p.id;
    permForm.value.name = p.name;
    permForm.value.codename = p.codename;
    permForm.value.description = p.description;
    errorMsg.value = '';
    modal.show();
    }

    function hideModal() {
    modal.hide();
    }

    async function savePerm() {
    saving.value = true;
    try {
    if (isEditMode.value) {
    await store.dispatch('role/updatePermission', {
    permissionId: permForm.value.id,
    permData: { description: permForm.value.description },
    });
    } else {
    await store.dispatch('role/createPermission', {
    name: permForm.value.name,
    codename: permForm.value.codename,
    description: permForm.value.description,
    });
    }
    await store.dispatch('role/fetchPermissions');
    hideModal();
    } catch {
    errorMsg.value = 'Не удалось сохранить право.';
    } finally {
    saving.value = false;
    }
    }

    async function confirmDeletePerm(id: number) {
    if (!confirm('Вы уверены, что хотите удалить право?')) return;
    try {
    await store.dispatch('role/deletePermission', id);
    await store.dispatch('role/fetchPermissions');
    } catch {
    alert('Не удалось удалить право.');
    }
    }
</script>

<style scoped>
    /* Дополнительные стили при необходимости */
</style>
