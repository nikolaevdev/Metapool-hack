<template>
    <div
            id="profileFormModal"
            ref="modalEl"
            tabindex="-1"
            aria-hidden="true"
            class="fixed left-0 right-0 top-0 z-50 hidden h-[calc(100%-1rem)] max-h-full w-full overflow-y-auto overflow-x-hidden p-4 md:inset-0"
    >
        <div class="relative max-h-full w-full max-w-2xl">
            <div class="relative rounded-lg bg-white shadow-sm dark:bg-gray-700">
                <!-- Header -->
                <div class="flex items-start justify-between rounded-t border-b p-5 dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white lg:text-2xl">
                        Редактирование профиля
                    </h3>
                    <button
                            type="button"
                            class="ms-auto inline-flex h-8 w-8 items-center justify-center rounded-lg bg-transparent text-sm text-gray-400 hover:bg-gray-200 hover:text-gray-900 dark:hover:bg-gray-600 dark:hover:text-white"
                            @click="hide()"
                    >
                        <XMarkIcon class="h-5 w-5" aria-hidden="true" />
                        <span class="sr-only">Закрыть</span>
                    </button>
                </div>

                <!-- Body -->
                <form @submit.prevent="submit" class="space-y-6 p-6">
                    <div>
                        <label for="first_name" class="mb-2 block text-sm font-medium text-gray-900 dark:text-white">Имя</label>
                        <input
                                v-model="local.firstName"
                                type="text"
                                id="first_name"
                                required
                                class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500"
                        />
                    </div>

                    <div>
                        <label for="last_name" class="mb-2 block text-sm font-medium text-gray-900 dark:text-white">Фамилия</label>
                        <input
                                v-model="local.lastName"
                                type="text"
                                id="last_name"
                                required
                                class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500"
                        />
                    </div>

                    <div>
                        <label for="email" class="mb-2 block text-sm font-medium text-gray-900 dark:text-white">E-mail</label>
                        <input
                                v-model="local.email"
                                type="email"
                                id="email"
                                required
                                class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500"
                        />
                    </div>

                    <!-- Footer -->
                    <div class="flex items-center space-x-2 rtl:space-x-reverse rounded-b border-t border-gray-200 pt-6 dark:border-gray-600">
                        <button
                                type="submit"
                                :disabled="saving"
                                class="rounded-lg bg-blue-700 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                        >
                            {{ saving ? 'Сохранение…' : 'Сохранить' }}
                        </button>
                        <button
                                type="button"
                                class="rounded-lg border border-gray-200 bg-white px-5 py-2.5 text-sm font-medium text-gray-500 hover:bg-gray-100 hover:text-gray-900 focus:z-10 focus:outline-none focus:ring-4 focus:ring-blue-300 dark:border-gray-500 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600 dark:hover:text-white"
                                @click="hide()"
                        >
                            Отмена
                        </button>
                    </div>

                    <!-- Временный вывод прав (можно убрать) -->
                    <div class="pt-2 text-xs text-gray-400" v-if="permissions?.length">
                        Права ({{ permissions.length }}): {{ permissions.join(', ') }}
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref, computed, watch, onMounted, defineProps, defineEmits, defineExpose } from 'vue';
    import { useStore } from 'vuex';
    import { initFlowbite, Modal, type ModalInterface, type ModalOptions } from 'flowbite';
    import { XMarkIcon } from '@heroicons/vue/24/outline';

    /* ----- Props & Emits ----- */
    const props = defineProps<{
    initialProfile: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    };
    }>();

    const emit = defineEmits<{
    (e: 'saved'): void;
    }>();

    /* ----- Store & Permissions ----- */
    const store = useStore();

    const permissions = computed<string[]>(() => store.getters['role/allSystemPermissions'] || []);

    // можно также опираться на auth-геттеры, если есть:
    // const hasPermission = (p: string) => store.getters['auth/hasPermission']?.(p) === true;

    /* ----- Локальное состояние формы ----- */
    const local = ref({ ...props.initialProfile });
    const saving = ref(false);

    watch(
    () => props.initialProfile,
    (v) => (local.value = { ...v })
    );

    /* ----- Flowbite Modal ----- */
    const modalEl = ref<HTMLElement | null>(null);
    let modal: ModalInterface | null = null;

    function show() { modal?.show(); }
    function hide() { modal?.hide(); }

    /* ----- Submit: только Vuex ----- */
    async function submit() {
    saving.value = true;
    try {
    await store.dispatch('auth/updateProfile', {
    first_name: local.value.firstName,
    last_name: local.value.lastName,
    email: local.value.email,
    });

    await store.dispatch('auth/loadMe');

    emit('saved');
    hide();
    } catch (e) {
    console.error('Ошибка при сохранении профиля', e);
    } finally {
    saving.value = false;
    }
    }

    onMounted(() => {
    initFlowbite();
    if (modalEl.value) {
    const options: ModalOptions = { backdrop: 'dynamic', closable: true };
    modal = new Modal(modalEl.value, options, { override: true });
    }
    });

    /* ----- Экспорт публичного API компонента ----- */
    defineExpose({ open: show, close: hide });
</script>




