<!-- ========== src/components/CategoryTree.vue ========== -->
<template>
    <ul class="pl-4 border-l border-gray-200 dark:border-gray-600">
        <li
                v-for="node in nodes"
                :key="node.id"
                class="mb-2">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between bg-white dark:bg-gray-700 rounded p-2">
                <div class="flex items-center">
                    <svg class="w-4 h-4 mr-2 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M6 6h8v2H6V6z"/>
                    </svg>
                    <span>{{ node.title }}</span>
                </div>
                <div class="mt-2 sm:mt-0 space-x-1">
                    <button
                            class="btn btn-blue btn-sm"
                            @click="$emit('add', node)">
                        Добавить
                    </button>
                    <button
                            class="btn btn-blue btn-sm"
                            @click="$emit('attach', node)">
                        Вложить файл
                    </button>
                    <button
                            class="btn btn-red btn-sm"
                            @click="$emit('delete', node)">
                        Удалить
                    </button>
                </div>
            </div>
            <!-- Рекурсия -->
            <CategoryTree
                    v-if="node.children?.length"
                    :nodes="node.children"
                    @add="$emit('add', $event)"
                    @attach="$emit('attach', $event)"
                    @delete="$emit('delete', $event)"
            />
        </li>
    </ul>
</template>

<script lang="ts">
    import { defineComponent, PropType } from "vue";
    export default defineComponent({
    name: "CategoryTree",
    props: {
        nodes: {
            type: Array as PropType<Array<any>>,
            default: () => [],
        },
    },
    });
</script>
