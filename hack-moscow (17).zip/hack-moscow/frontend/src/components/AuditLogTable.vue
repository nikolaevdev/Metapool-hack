<template>
    <div class="bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden">
        <div class="p-4 sm:p-6 border-b dark:border-gray-700">
            <h2 class="text-xl font-semibold text-gray-800 dark:text-white mb-4">Фильтры журнала аудита</h2>
            <form @submit.prevent="applyFilters" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
                <div>
                    <label for="filter_user_id" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">ID пользователя</label>
                    <input type="number" id="filter_user_id" v-model.number="localFilters.user_id" placeholder="Все пользователи" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white">
                </div>
                <div>
                    <label for="filter_action" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Действие (поиск)</label>
                    <input type="text" id="filter_action" v-model="localFilters.action" placeholder="Например, login, create_user" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white">
                </div>
                <div>
                    <label for="filter_date_from" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Дата С</label>
                    <input type="datetime-local" id="filter_date_from" v-model="localFilters.date_from" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white">
                </div>
                <div>
                    <label for="filter_date_to" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Дата ПО</label>
                    <input type="datetime-local" id="filter_date_to" v-model="localFilters.date_to" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white">
                </div>
                <div class="lg:col-span-4 flex flex-col sm:flex-row justify-end items-center gap-3 mt-4 sm:mt-0">
                    <button type="button" @click="resetFilters" class="w-full sm:w-auto text-gray-900 bg-white hover:bg-gray-100 border border-gray-300 focus:ring-4 focus:ring-gray-200 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-gray-700 dark:text-white dark:border-gray-600 dark:hover:bg-gray-600 dark:focus:ring-gray-700">
                        Сбросить
                    </button>
                    <button type="submit" class="w-full sm:w-auto text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 dark:bg-blue-500 dark:hover:bg-blue-600 focus:outline-none dark:focus:ring-blue-800">
                        Применить фильтры
                    </button>
                </div>
            </form>
        </div>

        <div v-if="loading" class="p-6 text-center text-gray-500 dark:text-gray-400">
            <svg aria-hidden="true" class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">...</svg>
            Загрузка журнала аудита...
        </div>
        <div v-else-if="!auditLogs.length" class="p-6 text-center text-gray-500 dark:text-gray-400">
            Записи аудита не найдены по заданным фильтрам.
        </div>
        <div v-else class="relative overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">Время</th>
                    <th scope="col" class="px-6 py-3">ID Пользователя</th>
                    <th scope="col" class="px-6 py-3">Действие</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="(log, index) in auditLogs" :key="index" class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 smooth-transition">
                    <td class="px-6 py-4 whitespace-nowrap">{{ formatTimestamp(log.timestamp) }}</td>
                    <td class="px-6 py-4">{{ log.user_id || 'Система' }}</td>
                    <td class="px-6 py-4">{{ log.action }}</td>
                </tr>
                </tbody>
            </table>
        </div>

        <nav v-if="pagination.totalPages > 1 && !loading" class="flex flex-col md:flex-row justify-between items-start md:items-center space-y-3 md:space-y-0 p-4" aria-label="Table navigation">
      <span class="text-sm font-normal text-gray-500 dark:text-gray-400">
        Показано <span class="font-semibold text-gray-900 dark:text-white">{{ Math.min((pagination.currentPage - 1) * pagination.perPage + 1, pagination.total) }}-{{ Math.min(pagination.currentPage * pagination.perPage, pagination.total) }}</span>
        из <span class="font-semibold text-gray-900 dark:text-white">{{ pagination.total }}</span>
      </span>
            <div class="flex items-center space-x-2">
                <select v-model.number="localFilters.limit" @change="changeLimit" class="text-sm p-2 border border-gray-300 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                    <option value="10">10 на стр.</option>
                    <option value="25">25 на стр.</option>
                    <option value="50">50 на стр.</option>
                    <option value="100">100 на стр.</option>
                </select>
                <ul class="inline-flex items-stretch -space-x-px">
                    <li>
                        <button @click="changePage(pagination.currentPage - 1)" :disabled="pagination.currentPage === 1"
                                class="flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white disabled:opacity-50">
                            <ChevronLeftIcon class="w-5 h-5" />
                        </button>
                    </li>
                    <li v-for="page in pageRange" :key="page">
                        <button @click="changePage(page)"
                                :class="page === pagination.currentPage ? 'text-blue-600 border-blue-300 bg-blue-50 hover:bg-blue-100 hover:text-blue-700 dark:border-gray-700 dark:bg-gray-700 dark:text-white' : 'text-gray-500 bg-white border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white'"
                                class="flex items-center justify-center text-sm py-2 px-3 leading-tight border">
                            {{ page }}
                        </button>
                    </li>
                    <li>
                        <button @click="changePage(pagination.currentPage + 1)" :disabled="pagination.currentPage === pagination.totalPages"
                                class="flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white disabled:opacity-50">
                            <ChevronRightIcon class="w-5 h-5" />
                        </button>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</template>

<script setup>
    import { ref, computed, onMounted, watch } from 'vue';
    import { useStore } from 'vuex';
    import { ChevronLeftIcon, ChevronRightIcon } from '@heroicons/vue/24/outline';

    const store = useStore();

    const initialFilters = {
        user_id: null,
        action: '',
        date_from: '', // YYYY-MM-DDTHH:MM
        date_to: '',   // YYYY-MM-DDTHH:MM
        skip: 0,
        limit: 25,
    };
    const localFilters = ref({ ...initialFilters });

    const loading = computed(() => store.getters['audit/auditStatus'] === 'loading');
    const auditLogs = computed(() => store.getters['audit/getAuditLogs']);
    const pagination = computed(() => store.getters['audit/auditPagination'] || { totalPages: 1, currentPage: 1, total: 0, perPage: 25 });


    const fetchLogs = async () => {
        // Преобразуем даты в ISOString, если они установлены, или null
        const filtersToDispatch = {
            ...localFilters.value,
            date_from: localFilters.value.date_from ? new Date(localFilters.value.date_from).toISOString() : null,
            date_to: localFilters.value.date_to ? new Date(localFilters.value.date_to).toISOString() : null,
            user_id: localFilters.value.user_id ? parseInt(localFilters.value.user_id, 10) : null,
        };
        // Удаляем пустые значения, чтобы не отправлять их как ''
        Object.keys(filtersToDispatch).forEach(key => {
            if (filtersToDispatch[key] === '' || filtersToDispatch[key] === null) {
                delete filtersToDispatch[key];
            }
        });
        // Убедимся, что limit всегда передается
        filtersToDispatch.limit = localFilters.value.limit;


        try {
            await store.dispatch('audit/fetchAuditLogs', filtersToDispatch);
        } catch (error) {
            console.error("Ошибка загрузки журнала аудита:", error);
        }
    };

    onMounted(() => {
        // Загружаем начальные фильтры из store, если они там есть (например, при возврате на страницу)
        const storeFilters = store.getters['audit/auditFilters'];
        localFilters.value = {
            ...initialFilters, // Сначала дефолтные
            ...storeFilters,  // Потом из стора (они могут содержать предыдущие значения)
            date_from: storeFilters.date_from ? storeFilters.date_from.substring(0, 16) : '', // Формат для datetime-local
            date_to: storeFilters.date_to ? storeFilters.date_to.substring(0, 16) : '',
        };
        fetchLogs();
    });

    const applyFilters = () => {
        localFilters.value.skip = 0; // Сбрасываем на первую страницу при применении новых фильтров
        fetchLogs();
    };

    const resetFilters = () => {
        localFilters.value = { ...initialFilters };
        fetchLogs();
    };

    const formatTimestamp = (timestamp) => {
        if (!timestamp) return '-';
        return new Date(timestamp).toLocaleString('ru-RU', {
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit'
        });
    };

    const changePage = (page) => {
        if (page > 0 && page <= pagination.value.totalPages) {
            localFilters.value.skip = (page - 1) * localFilters.value.limit;
            fetchLogs();
        }
    };

    const changeLimit = () => {
        localFilters.value.skip = 0; // Сброс на первую страницу при изменении лимита
        fetchLogs();
    };

    // Пагинация
    const pageRange = computed(() => {
        const current = pagination.value.currentPage;
        const total = pagination.value.totalPages;
        const range = [];
        const delta = 2;

        if (total <= 1) return [];

        for (let i = 1; i <= total; i++) {
            if (i === 1 || i === total || (i >= current - delta && i <= current + delta)) {
                range.push(i);
            }
        }
        // Убираем точки, Flowbite их не использует в стандартной пагинации
        return range;
    });


    // Следим за изменениями фильтров в store, если они могут меняться извне
    // watch(() => store.getters['audit/auditFilters'], (newFilters) => {
    //   localFilters.value = { ...newFilters };
    // }, { deep: true });

</script>
