<template>
    <!-- Модальное окно 2FA -->
    <div
            id="twoFAModal"
            ref="modalEl"
            tabindex="-1"
            aria-hidden="true"
            class="fixed left-0 right-0 top-0 z-50 hidden h-[cal...-h-full w-full overflow-y-auto overflow-x-hidden p-4 md:inset-0"
    >
        <div class="relative max-h-full w-full max-w-2xl">
            <div class="relative rounded-lg bg-white shadow-sm dark:bg-gray-700">
                <!-- Header -->
                <div class="flex items-start justify-between rounded-t border-b p-5 dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white lg:text-2xl">
                        Двухфакторная аутентификация
                    </h3>
                    <button
                            type="button"
                            class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white"
                            @click="hide"
                    >
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path
                                    fill-rule="evenodd"
                                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                    clip-rule="evenodd"
                            ></path>
                        </svg>
                    </button>
                </div>

                <!-- Body -->
                <div class="space-y-6 p-6">
                    <!-- Если 2FA выключена -->
                    <template v-if="!localEnabled">
                        <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                            Отсканируйте QR-код в приложении-аутентификаторе, затем введите одноразовый код.
                        </p>
                        <div v-if="qrCode" class="flex justify-center">
                            <img
                                    :src="qrCode"
                                    alt="QR-code"
                                    class="rounded border border-gray-200 p-2 dark:border-gray-600"
                            />
                        </div>
                        <div v-if="backupCodes.length" class="space-y-2">
                            <p class="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Резервные коды:
                            </p>
                            <ul class="list-disc list-inside text-sm text-gray-500 dark:text-gray-400">
                                <li v-for="c in backupCodes" :key="c">{{ c }}</li>
                            </ul>
                        </div>
                        <form @submit.prevent="verify" class="mx-auto mt-4 max-w-sm space-y-4">
                            <input
                                    v-model="code"
                                    type="text"
                                    inputmode="text"
                                    pattern="\d{6}"
                                    maxlength="6"
                                    placeholder="Например: 123456"
                                    title="Введите 6-значный код из аутентификатора"
                                    required
                                    class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                            />
                            <p v-if="error" class="text-sm text-red-600">{{ error }}</p>
                            <button
                                    type="submit"
                                    class="flex items-center justify-center w-full rounded-lg bg-blue-600 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 dark:focus:ring-blue-800"
                            >
                                <svg
                                        v-if="isLoading"
                                        class="animate-spin -ml-1 mr-3 h-5 w-5 opacity-75"
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                >
                                    <path
                                            fill-rule="evenodd"
                                            d="M4 12a8 8 0 018-8v8z"
                                            clip-rule="evenodd"
                                    ></path>
                                </svg>
                                {{ isLoading ? 'Активируем...' : 'Активировать' }}
                            </button>
                        </form>
                    </template>

                    <!-- Если 2FA включена -->
                    <template v-else>
                        <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                            Для отключения 2FA введите одноразовый код из приложения-аутентификатора или резервный код.
                        </p>
                        <form @submit.prevent="disable" class="mx-auto mt-4 max-w-sm space-y-4">
                            <!-- Галка для режима резервных кодов -->
                            <div class="flex items-center">
                                <input
                                        id="useBackup"
                                        type="checkbox"
                                        v-model="useBackup"
                                        class="h-4 w-4 text-blue-600 border-gray-300 rounded"
                                />
                                <label for="useBackup" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                                    У меня нет доступа к устройству
                                </label>
                            </div>

                            <!-- Поле для ввода TOTP-кода -->
                            <div v-if="!useBackup">
                                <input
                                        v-model="code"
                                        type="text"
                                        inputmode="text"
                                        pattern="\d{6}|[A-Za-z0-9]{8}"
                                        maxlength="8"
                                        placeholder="Например: 123456 или ABCD1234"
                                        title="Введите 6-значный код из аутентификатора или 8-символьный резервный код"
                                        required
                                        class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                                />
                            </div>
                            <!-- Поле для ввода резервного кода -->
                            <div v-else>
                                <input
                                        v-model="backupCodeInput"
                                        type="text"
                                        inputmode="text"
                                        maxlength="8"
                                        placeholder="Например: ABCD1234"
                                        title="Введите 8-символьный резервный код"
                                        required
                                        class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-600 dark:text-white dark:placeholder-gray-400"
                                />
                            </div>

                            <p v-if="error" class="text-sm text-red-600">{{ error }}</p>
                            <button
                                    type="submit"
                                    class="flex items-center justify-center w-full rounded-lg bg-red-600 px-5 py-2.5 text-center text-sm font-medium text-white hover:bg-red-700 focus:ring-4 focus:ring-red-300 dark:focus:ring-red-800"
                            >
                                <svg
                                        v-if="isLoading"
                                        class="animate-spin -ml-1 mr-3 h-5 w-5 opacity-75"
                                        fill="currentColor"
                                        viewBox="0 0 20 20"
                                >
                                    <path
                                            fill-rule="evenodd"
                                            d="M4 12a8 8 0 018-8v8z"
                                            clip-rule="evenodd"
                                    ></path>
                                </svg>
                                {{ isLoading ? 'Отключаем...' : 'Отключить 2FA' }}
                            </button>
                        </form>
                    </template>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
    import { ref, watch, onMounted } from 'vue';
    import { Modal, initFlowbite, type ModalInterface, type ModalOptions } from 'flowbite';
    import api from '../api';

    // Props и emits
    const props = defineProps({
    isEnabled: {
    type: Boolean,
    default: false
    }
    });
    const emit = defineEmits<{ (e: 'updated'): void }>();

    // Локальное состояние
    const localEnabled = ref<boolean>(props.isEnabled);
    watch(() => props.isEnabled, (val) => {
    localEnabled.value = val;
    });

    const modalEl = ref<HTMLElement | null>(null);
    let modal: ModalInterface | null = null;

    const code = ref<string>('');
    const qrCode = ref<string>('');
    const backupCodes = ref<string[]>([]);
    const isLoading = ref<boolean>(false);
    const error = ref<string | null>(null);

    // Новая функциональность: режим резервных кодов
    const useBackup = ref<boolean>(false);
    const backupCodeInput = ref<string>('');

    // Обрезка ввода TOTP-кода
    function onCodeInput(e: Event) {
    const raw = (e.target as HTMLInputElement).value;
    code.value = raw.replace(/\D/g, '').slice(0, 6);
    }

    // Показ/скрытие модального окна
    async function show() {
    if (!modal) return;
    code.value = '';
    backupCodeInput.value = '';
    useBackup.value = false;
    error.value = null;
    modal.show();
    if (!localEnabled.value) {
    await init2FA();
    }
    }
    function hide() {
    modal?.hide();
    }

    // Инициализация 2FA (получение QR и резервных кодов)
    async function init2FA() {
    try {
    const { data } = await api.enable2FA({});
    qrCode.value = data.qrCode;
    backupCodes.value = data.backupCodes;
    } catch (e: any) {
    console.error('Не удалось инициализировать 2FA', e);
    error.value = e.response?.data?.detail || 'Ошибка при инициализации 2FA';
    }
    }

    // Верификация TOTP-кода
    async function verify() {
    isLoading.value = true;
    error.value = null;
    try {
    await api.verify2FA({ totpCode: code.value });
    localEnabled.value = true;
    emit('updated');
    hide();
    } catch (e: any) {
    console.error('Ошибка верификации 2FA', e);
    error.value = e.response?.data?.detail || 'Неверный код аутентификатора';
    } finally {
    isLoading.value = false;
    }
    }

    // Отключение 2FA с поддержкой резервных кодов
    async function disable() {
    isLoading.value = true;
    error.value = null;
    try {
    const payload: any = {};
    if (useBackup.value) {
    payload.backupCode = backupCodeInput.value;
    } else {
    payload.totpCode = code.value;
    }
    await api.disable2FA(payload);
    localEnabled.value = false;
    emit('updated');
    hide();
    } catch (e: any) {
    console.error('Не удалось отключить 2FA', e);
    error.value = e.response?.data?.detail || 'Ошибка при отключении 2FA';
    } finally {
    isLoading.value = false;
    }
    }

    // Инициализация компонента
    onMounted(() => {
    initFlowbite();
    if (modalEl.value) {
    const options: ModalOptions = {
    closable: true,
    backdrop: 'dynamic',
    backdropClasses: 'bg-gray-900/50 dark:bg-gray-900/80 fixed inset-0 z-40'
    };
    modal = new Modal(modalEl.value, options, { override: true });
    }
    });

    // Экспонируем методы
    defineExpose({ open: show, close: hide });
</script>


