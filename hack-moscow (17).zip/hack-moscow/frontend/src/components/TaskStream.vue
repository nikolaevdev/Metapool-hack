<template>
  <div class="p-3 border rounded bg-white">
    <div class="flex items-center gap-2 mb-2">
      <button class="btn" @click="toggle">{{ connected ? 'Отключить' : 'Подключить' }}</button>
      <span class="text-sm text-gray-600">SSE: /api/tasks/stream</span>
    </div>
    <div class="h-48 overflow-auto text-xs bg-gray-50 border p-2 rounded">
      <div v-for="(m,i) in messages" :key="i">{{ m }}</div>
    </div>
  </div>
</template>
<script>
export default{
  name:'TaskStream',
  data(){ return { es:null, connected:false, messages:[] } },
  methods:{
    toggle(){
      if(this.connected) return this.disconnect()
      const url = (import.meta.env.VITE_API_URL || '/api').replace(/\/$/,'') + '/tasks/stream'
      this.es = new EventSource(url, { withCredentials:true })
      this.es.onmessage = e => { this.messages.unshift(e.data) ; this.messages = this.messages.slice(0,200) }
      this.es.onerror = () => { this.disconnect() }
      this.connected = true
    },
    disconnect(){
      try{ this.es && this.es.close() }catch{}
      this.es = null; this.connected=false
    }
  },
  beforeUnmount(){ this.disconnect() }
}
</script>
<style scoped>
.btn{ padding:.4rem .7rem; border:1px solid #e5e7eb; border-radius:.5rem; background:white }
</style>
