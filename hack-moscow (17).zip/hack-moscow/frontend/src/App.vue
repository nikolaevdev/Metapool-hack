<template>
  <router-view v-slot="{ Component }">
    <transition name="fade" mode="out-in">
      <component :is="Component" />
    </transition>
  </router-view>
  <notifications position="top-right" :duration="3000" />
</template>

<script setup>
  import { onMounted } from 'vue';
  import { initFlowbite } from 'flowbite';

  // Инициализация JS-компонентов Flowbite при монтировании App.vue.
  // Это гарантирует, что интерактивные элементы Flowbite (модальные окна, выпадающие списки и т.д.)
  // будут работать на всех страницах.
  onMounted(() => {
    initFlowbite();
  });
</script>

<style>
  /* Стили для анимации перехода между страницами */
  .fade-enter-active,
  .fade-leave-active {
    transition: opacity 0.2s ease-out;
  }

  .fade-enter-from,
  .fade-leave-to {
    opacity: 0;
  }
</style>
