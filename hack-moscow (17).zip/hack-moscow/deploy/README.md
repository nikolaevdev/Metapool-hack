# Fullstack Bundle (Ready)

Этот бандл включает:
- `backend/`
- `frontend/`
- `deploy/`

## Быстрый старт
```bash
cd deploy
cp .env.prod .env.prod.local || true   # при желании
# при необходимости отредактируйте .env.prod (секреты, домен для TLS)

make build
make up
make migrate
```

Откройте:
- SPA: http://localhost:8080/spa/
- API: http://localhost:8000/api/ (также доступен через фронтовой Nginx по `/api`)

### TLS (опционально)
В `deploy/.env.prod` укажите `DOMAIN` и `LETSENCRYPT_EMAIL` и выполните:
```bash
make tls-up
```
Доступ: `https://$DOMAIN/`

## Примечания
- Compose использует локальные пути `../backend` и `../frontend` (указаны в `.env.prod`). Если переместите каталоги — обновите переменные.
- Фронтенд Nginx проксирует `/api` → `api:8000`; SSE настроен корректно.
