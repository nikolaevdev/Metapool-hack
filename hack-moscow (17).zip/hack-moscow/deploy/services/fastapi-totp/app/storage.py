import json, os
from pathlib import Path
from typing import Optional

STORAGE_DIR = Path(os.getenv("TOTP_STORAGE", "/app/.data/secrets"))
STORAGE_DIR.mkdir(parents=True, exist_ok=True)

def secret_path(user_id: str) -> Path:
    safe = "".join(ch for ch in user_id if ch.isalnum() or ch in ("-", "_", "."))[:128]
    return STORAGE_DIR / f"{safe}.json"

def save_secret(user_id: str, secret: str, issuer: str, account: str, enabled: bool = True) -> None:
    path = secret_path(user_id)
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"user_id": user_id, "secret": secret, "issuer": issuer, "account": account, "enabled": enabled}, f)

def load_secret(user_id: str) -> Optional[dict]:
    path = secret_path(user_id)
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def delete_secret(user_id: str) -> None:
    path = secret_path(user_id)
    if path.exists():
        path.unlink()
