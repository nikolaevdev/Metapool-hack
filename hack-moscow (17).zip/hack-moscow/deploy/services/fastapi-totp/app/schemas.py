from pydantic import BaseModel, Field

class EnrollRequest(BaseModel):
    user_id: str = Field(..., min_length=1)

class EnrollResponse(BaseModel):
    provisioning_uri: str
    secret: str | None = None

class VerifyRequest(BaseModel):
    user_id: str
    code: str = Field(..., pattern=r"^\d{6}$")

class VerifyResponse(BaseModel):
    valid: bool
    drift: int | None = None
