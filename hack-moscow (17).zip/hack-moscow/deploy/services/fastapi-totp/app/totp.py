import os
import pyotp
from .storage import save_secret, load_secret, delete_secret

ISSUER = os.getenv("APP_NAME", "fastapi-totp")

def enroll(user_id: str, account_name: str | None = None) -> tuple[str, str]:
    secret = pyotp.random_base32()
    account = account_name or user_id
    uri = pyotp.totp.TOTP(secret).provisioning_uri(name=account, issuer_name=ISSUER)
    save_secret(user_id=user_id, secret=secret, issuer=ISSUER, account=account, enabled=True)
    return uri, secret

def verify(user_id: str, code: str, valid_window: int = 1) -> tuple[bool, int | None]:
    rec = load_secret(user_id)
    if not rec or not rec.get("enabled"):
        return False, None
    totp = pyotp.TOTP(rec["secret"])
    is_valid = totp.verify(code, valid_window=valid_window)
    if is_valid:
        return True, 0
    return False, None

def disable(user_id: str) -> None:
    delete_secret(user_id)
