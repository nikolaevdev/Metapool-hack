import os, io, pyotp, qrcode
from fastapi import FastAPI, HTTPException, Response, Query
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from .schemas import EnrollRequest, EnrollResponse, VerifyRequest, VerifyResponse
from . import totp
from .storage import load_secret

APP_ENV = os.getenv("APP_ENV", "development")
EXPOSE_TOTP_SECRET = os.getenv("EXPOSE_TOTP_SECRET", "false").lower() == "true"

app = FastAPI(title=os.getenv("APP_NAME", "fastapi-totp"))

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/auth/totp/enroll", response_model=EnrollResponse, tags=["TOTP"])
def enroll(req: EnrollRequest):
    uri, secret = totp.enroll(req.user_id)
    return EnrollResponse(
        provisioning_uri=uri,
        secret=secret if (EXPOSE_TOTP_SECRET or APP_ENV != "production") else None
    )

@app.get("/auth/totp/qrcode", tags=["TOTP"])
def qrcode_png(user_id: str = Query(...)):
    rec = load_secret(user_id)
    if not rec:
        raise HTTPException(status_code=404, detail="TOTP secret not found. Enroll first.")
    uri = pyotp.totp.TOTP(rec["secret"]).provisioning_uri(name=rec["account"], issuer_name=rec["issuer"])
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return Response(content=buf.getvalue(), media_type="image/png")

@app.post("/auth/totp/verify", response_model=VerifyResponse, tags=["TOTP"])
def verify(req: VerifyRequest):
    valid, drift = totp.verify(req.user_id, req.code)
    return VerifyResponse(valid=valid, drift=drift)

@app.delete("/auth/totp/disable", tags=["TOTP"])
def disable(user_id: str):
    totp.disable(user_id)
    return JSONResponse({"ok": True})
