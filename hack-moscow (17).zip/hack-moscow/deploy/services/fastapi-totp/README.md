# FastAPI + TOTP service (injected)
Dev:
  docker compose -f ../docker-compose.dev.yml -f ../docker-compose.dev.fastapi.yml up --build
Prod:
  docker compose -f ../docker-compose.yml -f ../docker-compose.fastapi.yml up --build -d
