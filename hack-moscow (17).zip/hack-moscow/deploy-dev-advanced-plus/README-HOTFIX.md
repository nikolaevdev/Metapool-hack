# Dev proxy & Frontend API hotfix
- Use relative API base in frontend: `VITE_API_URL=/api` (done in `.env.dev` and `frontend/.env`)
- `proxy` service healthcheck uses `wget -q -O /dev/null http://localhost/spa/`
- `frontend` service healthcheck uses `wget -q -O /dev/null http://localhost:5173/`
- `proxy` depends on `backend` and `frontend` with `profiles: ["dev"]`.

## Start
```bash
cd deploy-dev-advanced-plus
docker compose --profile dev --env-file .env.dev -f docker-compose.devqa.yml up -d --build
# open http://dev.localhost:8081/spa/
```
